#ifndef  _SSI_H_
#define  _SSI_H_
 
#include "stm32f4xx.h"
#include "stm32f4xx_spi.h"
//1.SDO��MISO,ָ��������������,�������������;SDI��MOSI,ָ�������������,�������������롣
/************************** SPI �����������Ŷ���********************************/
#define      macSPIx                                     SPI1
#define      macSPI_APBxClock_FUN                        RCC_APB2PeriphClockCmd
#define      macSPI_CLK                                  RCC_APB2Periph_SPI1

#define      macSPI_CS_APBxClock_FUN                     RCC_AHB1PeriphClockCmd
#define      macSPI_CS_CLK                               RCC_AHB1Periph_GPIOA   
#define      macSPI_CS_PORT                              GPIOA
#define      macSPI_CS_PIN                               GPIO_Pin_4

#define      macSPI_SCK_APBxClock_FUN                    RCC_AHB1PeriphClockCmd
#define      macSPI_SCK_CLK                              RCC_AHB1Periph_GPIOA   
#define      macSPI_SCK_PORT                             GPIOA   
#define      macSPI_SCK_PIN                              GPIO_Pin_5

#define      macSPI_MISO_APBxClock_FUN                   RCC_AHB1PeriphClockCmd
#define      macSPI_MISO_CLK                             RCC_AHB1Periph_GPIOA    
#define      macSPI_MISO_PORT                            GPIOA 
#define      macSPI_MISO_PIN                             GPIO_Pin_6

#define      macSPI_MOSI_APBxClock_FUN                   RCC_AHB1PeriphClockCmd
#define      macSPI_MOSI_CLK                             RCC_AHB1Periph_GPIOA    
#define      macSPI_MOSI_PORT                            GPIOA 
#define      macSPI_MOSI_PIN                             GPIO_Pin_7

#define      macSPI_RES_APBxClock_FUN                   RCC_AHB1PeriphClockCmd
#define      macSPI_RES_CLK                             RCC_AHB1Periph_GPIOB    
#define      macSPI_RES_PORT                            GPIOB 
#define      macSPI_RES_PIN                             GPIO_Pin_12

#define      macSPI_SDC_APBxClock_FUN                   RCC_AHB1PeriphClockCmd
#define      macSPI_SDC_CLK                             RCC_AHB1Periph_GPIOB    
#define      macSPI_SDC_PORT                            GPIOB 
#define      macSPI_SDC_PIN                             GPIO_Pin_13
/************************** SPI �����궨��********************************/

#define      macSPIx_CS_ENABLE()                       GPIO_ResetBits( macSPI_CS_PORT, macSPI_CS_PIN )
#define      macSPIx_CS_DISABLE()                      GPIO_SetBits( macSPI_CS_PORT, macSPI_CS_PIN )

#define  macSPIx_RES_ENABLE()   GPIO_SetBits(GPIOB,  GPIO_Pin_12) 
#define  macSPIx_RES_DISABLE()   GPIO_ResetBits(GPIOB,  GPIO_Pin_12)

#define  macSPIx_SDC_COMMAND_ENABLE()   GPIO_ResetBits(GPIOB,  GPIO_Pin_13) 
#define  macSPIx_SDC_DATA_ENABLE()      GPIO_SetBits(GPIOB,  GPIO_Pin_13)

//LCD ��Ƶ��ʾ����������LCD��ͬ����
#define SSD2828_LCD_VBPD		 12  
#define SSD2828_LCD_VFPD	 	 16
#define SSD2828_LCD_VSPW		 4

#define SSD2828_LCD_HBPD		 48
#define SSD2828_LCD_HFPD		 16
#define SSD2828_LCD_HSPW	   16

#define SSD2828_LCD_XSIZE_TFT    800 
#define SSD2828_LCD_YSIZE_TFT    1280

void SPI1_Init(void);
void SSD2828_Init(void);
u16 SSD2828_ReadID(void);
#endif
