#include "./others/show.h"
#include "./lcd/bsp_lcd.h"
#include "./showstring/showstring.h"
#include "picture.h"

int wave1[] = {1,2,3,4,56,5,3,2,4,8,4,6,5,4,2,3,5,5,5,5,6,6,3,5,5,5,5,5,5};

//����ָ���ǻ�������
void GUI_Init_my_chart()
{
	printf("enter������ĳ�ʼ��");
	u16 x,y,x_r,y_r;
  /*****������ 40,125*****/
	//��ߵĸ���
	for(x=40;x<680;x+=25)
		for(y=70;y<640;y+=5)
	{
		Lcd_Draw_Point(x,y,LCD_COLOR565_BLACK);
	}
	/****������*****/
	for(y=70;y<640;y+=25*2)
		for(x=40;x<680;x+=5)
	{
		Lcd_Draw_Point(x,y,LCD_COLOR565_BLACK);
	}
	
	//�ұߵĸ���
	for( x_r=40;x_r<680;x_r+=25)
		for( y_r=710;y_r<1280;y_r+=5)
	{
		Lcd_Draw_Point(x_r,y_r,LCD_COLOR565_BLACK);
	}
	/****������*****/
	for(y_r=710;y_r<1280;y_r+=25*2)
		for(x_r=40;x_r<680;x_r+=5)
	{
		Lcd_Draw_Point(x_r,y_r,LCD_COLOR565_BLACK);
	}
	
	//��8��ͨ���ĺ���
		for(int i=0;i<5;i++)
	{
		Draw_ColorLine_Vertical(40+i*80*2,0,1280,LCD_COLOR565_BLACK);		
	}
	//Draw_ColorLine_Vertical(0,125,1280,LCD_COLOR565_BLACK);	
 //LCD_DrawLine(25, 800,line_length,LCD_DIR_HORIZONTAL);
	/*��ˮƽ�ߺ���ֱ��*/
  Draw_ColorLine_Horizontal(40,70,680,LCD_COLOR565_BLACK);
	Draw_ColorLine_Horizontal(40,640,680,LCD_COLOR565_BLACK);
	Draw_ColorLine_Horizontal(40,710,680,LCD_COLOR565_BLACK);
	//Draw_ColorLine_Vertical(35,125,1280,LCD_COLOR565_BLACK);//ˮƽ��
}



void GUI_Init_my_chart_4()
{
	u16 x,y;
	for(x=40;x<640;x+=25*2)
		for(y=125;y<1280;y+=5)
	{
		Lcd_Draw_Point(x,y,LCD_COLOR565_BLACK);
	}
	/****������*****/
	for(y=125;y<1280;y+=25*2)
		for(x=40;x<640;x+=5)
	{
		Lcd_Draw_Point(x,y,LCD_COLOR565_BLACK);
	}
	//��4��ͨ���ĺ���
		for(int i=0;i<5;i++)
	{
		Draw_ColorLine_Vertical(i*150+40,0,1280,LCD_COLOR565_BLACK);		
	}
	/*��ˮƽ�ߺ���ֱ��*/
  Draw_ColorLine_Horizontal(40,125,640,LCD_COLOR565_BLACK);
	//Draw_ColorLine_Vertical(600,0,1280,LCD_COLOR565_BLACK);//ˮƽ��
}

//���겼��
void coordinate()
{
	//�������
	move_Image_Asm_565(4,110-55,30,30,position_0+2);
	move_Image_Asm_565(4,210-55,30,30,position_100+2);
	move_Image_Asm_565(4,310-55,30,30,position_200+2);
	move_Image_Asm_565(4,410-55,30,30,position_300+2);
	move_Image_Asm_565(4,510-55,30,30,position_400+2);
	move_Image_Asm_565(4,610-55,30,30,position_500+2);
	move_Image_Asm_565(3,610-55+35,30,30,ms+2);

	//�ұ�����
	move_Image_Asm_565(4,710-15,30,30,position_0+2);
	move_Image_Asm_565(4,810-15,30,30,position_100+2);
	move_Image_Asm_565(4,910-15,30,30,position_200+2);
	move_Image_Asm_565(4,1010-15,30,30,position_300+2);
	move_Image_Asm_565(4,1110-15,30,30,position_400+2);
	move_Image_Asm_565(4,1210-15,30,30,position_500+2);
	move_Image_Asm_565(3,1230,30,30,ms+2);
	//move_Image_Asm_565(4,1210,30,30,position_1100+2);
	//move_Image_Asm_565(4,1310,30,30,position_1200+2);
}
//����������겼��
void coordinate_con()
{	
	//�������
		move_Image_Asm_565(2,110-55,37,40,position_1025+2);
	move_Image_Asm_565(2,210-55,37,40,position_1125+2);
	move_Image_Asm_565(2,310-55,37,40,position_1225+2);
	move_Image_Asm_565(2,410-55,37,40,position_1325+2);
	move_Image_Asm_565(2,510-55,37,40,position_1425+2);
	move_Image_Asm_565(2,610-55,37,40,position_1525+2);
	move_Image_Asm_565(4,610-55+35+10,30,30,ms+2);
	//�ұ�����
	move_Image_Asm_565(2,710-15,37,40,position_1025+2);
	move_Image_Asm_565(2,810-15,37,40,position_1125+2);
	move_Image_Asm_565(2,910-15,37,40,position_1225+2);
	move_Image_Asm_565(2,1010-15,37,40,position_1325+2);
	move_Image_Asm_565(2,1110-15,37,40,position_1425+2);
	move_Image_Asm_565(2,1210-15,37,40,position_1525+2);
	move_Image_Asm_565(4,1230+10,30,30,ms+2);
}
//���ͼ��
void clear_line()
{
	Draw_ColorRect(280+320,127,78,1025,LCD_COLOR565_WHITE);//125,80
	Draw_ColorRect(280+240,127,78,1025,LCD_COLOR565_WHITE);
	Draw_ColorRect(280+160,127,78,1025,LCD_COLOR565_WHITE);
	Draw_ColorRect(280+80,127,78,1025,LCD_COLOR565_WHITE);
	Draw_ColorRect(280,127,78,1025,LCD_COLOR565_WHITE);
	Draw_ColorRect(200,127,78,1025,LCD_COLOR565_WHITE);
	Draw_ColorRect(120,127,78,1025,LCD_COLOR565_WHITE);
	Draw_ColorRect(40,127,78,1025,LCD_COLOR565_WHITE);
}
