#include "picture.h"

uint16_t num1[15*27+2]__attribute__((at(0xD0500000+0*0x4B4)));//�����ڽ��յ����ݶ�λ��0xD0400000+0*0x4B4��
uint16_t num2[15*27+2]__attribute__((at(0xD0500000+1*0x4B4)));
uint16_t num3[15*27+2]__attribute__((at(0xD0500000+2*0x4B4)));
uint16_t num4[15*27+2]__attribute__((at(0xD0500000+3*0x4B4)));
uint16_t num5[15*27+2]__attribute__((at(0xD0500000+4*0x4B4)));
uint16_t num6[15*27+2]__attribute__((at(0xD0500000+5*0x4B4)));
uint16_t num7[15*27+2]__attribute__((at(0xD0500000+6*0x4B4)));
uint16_t num8[15*27+2]__attribute__((at(0xD0500000+7*0x4B4)));
uint16_t num9[15*27+2]__attribute__((at(0xD0500000+8*0x4B4)));
uint16_t num0[15*27+2]__attribute__((at(0xD0500000+9*0x4B4)));
uint16_t info[140*70+2]__attribute__((at(0xD0500000+10*0x4B4)));

uint16_t beginsend[40*160+2]__attribute__((at(0xD0800000+1*0x3400)));
uint16_t stopsend[40*160+2]__attribute__((at(0xD0800000+3*0x3400)));
uint16_t resetsend[40*160+2]__attribute__((at(0xD0800000+4*0x3400)));
uint16_t uploadsend[40*160+2]__attribute__((at(0xD0800000+5*0x3400)));
uint16_t one[40*160+2]__attribute__((at(0xD0800000+6*0x3400)));
uint16_t two[40*160+2]__attribute__((at(0xD0800000+7*0x3400)));
uint16_t three[40*160+2]__attribute__((at(0xD0800000+8*0x3400)));

uint16_t position_0[30*30+2]__attribute__((at(0xD0900000+0*0x800)));
uint16_t position_100[30*30+2]__attribute__((at(0xD0900000+1*0x800)));
uint16_t position_200[30*30+2]__attribute__((at(0xD0900000+2*0x800)));
uint16_t position_300[30*30+2]__attribute__((at(0xD0900000+3*0x800)));
uint16_t position_400[30*30+2]__attribute__((at(0xD0900000+4*0x800)));
uint16_t position_500[30*30+2]__attribute__((at(0xD0900000+5*0x800)));
uint16_t position_600[30*30+2]__attribute__((at(0xD0900000+6*0x800)));
uint16_t position_700[30*30+2]__attribute__((at(0xD0900000+7*0x800)));
uint16_t position_800[30*30+2]__attribute__((at(0xD0900000+8*0x800)));
uint16_t position_900[30*30+2]__attribute__((at(0xD0900000+9*0x800)));
uint16_t position_1000[37*40+2]__attribute__((at(0xD0900000+10*0x800)));
uint16_t position_1025[37*40+2]__attribute__((at(0xD0900000+10*0x800+0x1728)));//�����������
uint16_t position_1125[37*40+2]__attribute__((at(0xD0900000+10*0x800+0x1728*2)));
uint16_t position_1225[37*40+2]__attribute__((at(0xD0900000+10*0x800+0x1728*3)));
uint16_t position_1325[37*40+2]__attribute__((at(0xD0900000+10*0x800+0x1728*4)));
uint16_t position_1425[37*40+2]__attribute__((at(0xD0900000+10*0x800+0x1728*5)));
uint16_t position_1525[37*40+2]__attribute__((at(0xD0900000+10*0x800+0x1728*6)));
uint16_t position_1625[37*40+2]__attribute__((at(0xD0900000+10*0x800+0x1728*7)));
uint16_t position_1725[37*40+2]__attribute__((at(0xD0900000+10*0x800+0x1728*8)));
uint16_t position_1825[37*40+2]__attribute__((at(0xD0900000+10*0x800+0x1728*9)));
uint16_t position_1925[37*40+2]__attribute__((at(0xD0900000+10*0x800+0x1728*10)));
uint16_t position_2025[37*40+2]__attribute__((at(0xD0900000+10*0x800+0x1728*11)));


/*****��ʼ*******/
uint16_t begin_0[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+0*0x264C)));
uint16_t begin_1[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+1*0x264C)));
/*****��ͣ*******/
uint16_t halt_0[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+2*0x264C)));
uint16_t halt_1[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+3*0x264C)));
/*****��λ*******/
uint16_t reset_0[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+4*0x264C)));
uint16_t reset_1[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+5*0x264C)));
/*****�ϴ�*******/
uint16_t upload_0[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+6*0x264C)));
uint16_t upload_1[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+7*0x264C)));
/*****����*******/
uint16_t clear_0[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+8*0x264C)));
uint16_t clear_1[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+9*0x264C)));
/*****����*******/
uint16_t emit_0[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+10*0x264C)));
uint16_t emit_1[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+11*0x264C)));
/*****����*******/
uint16_t rec_0[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+12*0x264C)));
uint16_t rec_1[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+13*0x264C)));
/*****����*******/
uint16_t heart_0[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+14*0x264C)));
uint16_t heart_1[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+15*0x264C)));
/****ͨ��4*******/
uint16_t channel4_0[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+16*0x264C)));
uint16_t channel4_1[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+17*0x264C)));
/*******����********/
uint16_t play_0[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+18*0x264C)));
uint16_t play_1[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+19*0x264C)));
//����
uint16_t enter_0[70*70+2]__attribute__((at(0xD0400000+18*0x4B4+20*0x264C)));

uint16_t background[1280*800+2]__attribute__((at(0xD0F00000)));

uint16_t bg[1280*800+2]__attribute__((at(0xD0A00000)));

uint16_t channelMode[1280*800+2]__attribute__((at(0xD0C00000)));
uint16_t left_0[100*80+2]__attribute__((at(0xD0300000)));
uint16_t select_0[70*70+2]__attribute__((at(0xD0300000+0x7D08)));
uint16_t select_1[70*70+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*1)));
uint16_t again_0[70*70+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*2)));
uint16_t again_1[70*70+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*3)));
uint16_t mode4[70*70+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*4)));
uint16_t mode8[70*70+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*5)));
uint16_t load_0[70*70+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*6)));
uint16_t load_1[70*70+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*7)));
uint16_t rec_finished[160*40+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*8)));
uint16_t show_0[70*70+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*8+0x6480)));
uint16_t show_1[70*70+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*8+0x6480+0x4C98*1)));
uint16_t order_0[70*70+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*8+0x6480+0x4C98*2)));
uint16_t order_1[70*70+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*8+0x6480+0x4C98*3)));
uint16_t con_0[70*70+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*8+0x6480+0x4C98*4)));
uint16_t con_1[70*70+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*8+0x6480+0x4C98*5)));
uint16_t file_0[70*70+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*8+0x6480+0x4C98*6)));
uint16_t file_1[70*70+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*8+0x6480+0x4C98*7)));
uint16_t ms[30*30+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*8+0x6480+0x4C98*8)));
uint16_t pre_play_0[45*45+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*8+0x6480+0x4C98*8+0xE18)));
uint16_t pre_play_1[45*45+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*8+0x6480+0x4C98*8+0xE18+0x1FAC*1)));
uint16_t con_play_0[45*45+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*8+0x6480+0x4C98*8+0xE18+0x1FAC*2)));
uint16_t con_play_1[45*45+2]__attribute__((at(0xD0300000+0x7D08+0x4C98*8+0x6480+0x4C98*8+0xE18+0x1FAC*3)));

void picture_initial()
{	
	printf("enter pictureinitial");
	//Get_BMP_565("0:/test.bmp",map);
	
	Get_BMP_565_16("0:/PICTURE_PULSE/begin_0.bmp",begin_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/begin_1.bmp",begin_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/halt_0.bmp",halt_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/halt_1.bmp",halt_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/reset_0.bmp",reset_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/reset_1.bmp",reset_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/upload_0.bmp",upload_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/upload_1.bmp",upload_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/clear_0.bmp",clear_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/clear_1.bmp",clear_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/emit_0.bmp",emit_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/emit_1.bmp",emit_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/rec_0.bmp",rec_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/rec_1.bmp",rec_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/heart_0.bmp",heart_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/heart_1.bmp",heart_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/channel4_0.bmp",channel4_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/channel4_1.bmp",channel4_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/play_0.bmp",play_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/play_1.bmp",play_1);
	
	Get_BMP_565_16("0:/PICTURE_PULSE/background_pulse.bmp",background);
	//Get_BMP_565_16("0:/PICTURE_PULSE/background.bmp",background);//�������б���
	Get_BMP_565_16("0:/PICTURE_PULSE/bg.bmp",bg);//���ÿ�������
	Get_BMP_565_16("0:/PICTURE_PULSE/enter.bmp",enter_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/beginsend.bmp",beginsend);
	Get_BMP_565_16("0:/PICTURE_PULSE/stopsend.bmp",stopsend);
	Get_BMP_565_16("0:/PICTURE_PULSE/resetsend.bmp",resetsend);
	Get_BMP_565_16("0:/PICTURE_PULSE/uploadsend.bmp",uploadsend);
	Get_BMP_565_16("0:/PICTURE_PULSE/one.bmp",one);
	Get_BMP_565_16("0:/PICTURE_PULSE/two.bmp",two);
	Get_BMP_565_16("0:/PICTURE_PULSE/three.bmp",three);
	Get_BMP_565_16("0:/PICTURE_PULSE/0.bmp",position_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/100.bmp",position_100);
	Get_BMP_565_16("0:/PICTURE_PULSE/200.bmp",position_200);
	Get_BMP_565_16("0:/PICTURE_PULSE/300.bmp",position_300);
	Get_BMP_565_16("0:/PICTURE_PULSE/400.bmp",position_400);
	Get_BMP_565_16("0:/PICTURE_PULSE/500.bmp",position_500);
	Get_BMP_565_16("0:/PICTURE_PULSE/600.bmp",position_600);
	Get_BMP_565_16("0:/PICTURE_PULSE/700.bmp",position_700);
	Get_BMP_565_16("0:/PICTURE_PULSE/800.bmp",position_800);
	Get_BMP_565_16("0:/PICTURE_PULSE/900.bmp",position_900);
	Get_BMP_565_16("0:/PICTURE_PULSE/1000.bmp",position_1000);
	Get_BMP_565_16("0:/PICTURE_PULSE/channelMode.bmp",channelMode);
	Get_BMP_565_16("0:/PICTURE_PULSE/left_0.bmp",left_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/info.bmp",info);
	Get_BMP_565_16("0:/PICTURE_PULSE/1.bmp",num1);
	Get_BMP_565_16("0:/PICTURE_PULSE/2.bmp",num2);
	Get_BMP_565_16("0:/PICTURE_PULSE/3.bmp",num3);
	Get_BMP_565_16("0:/PICTURE_PULSE/4.bmp",num4);
	Get_BMP_565_16("0:/PICTURE_PULSE/5.bmp",num5);
	Get_BMP_565_16("0:/PICTURE_PULSE/6.bmp",num6);
	Get_BMP_565_16("0:/PICTURE_PULSE/7.bmp",num7);
	Get_BMP_565_16("0:/PICTURE_PULSE/8.bmp",num8);
	Get_BMP_565_16("0:/PICTURE_PULSE/select_0.bmp",select_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/select_1.bmp",select_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/again_0.bmp",again_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/again_1.bmp",again_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/mode4.bmp",mode4);
	Get_BMP_565_16("0:/PICTURE_PULSE/mode8.bmp",mode8);
	Get_BMP_565_16("0:/PICTURE_PULSE/load_0.bmp",load_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/load_1.bmp",load_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/show_0.bmp",show_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/show_1.bmp",show_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/order_0.bmp",order_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/order_1.bmp",order_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/con_0.bmp",con_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/con_1.bmp",con_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/file_0.bmp",file_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/file_1.bmp",file_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/rec_finished.bmp",rec_finished);
	Get_BMP_565_16("0:/PICTURE_PULSE/file_1.bmp",file_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/ms.bmp",ms);
	Get_BMP_565_16("0:/PICTURE_PULSE/1025.bmp",position_1025);
	Get_BMP_565_16("0:/PICTURE_PULSE/1125.bmp",position_1125);
	Get_BMP_565_16("0:/PICTURE_PULSE/1225.bmp",position_1225);
	Get_BMP_565_16("0:/PICTURE_PULSE/1325.bmp",position_1325);
	Get_BMP_565_16("0:/PICTURE_PULSE/1425.bmp",position_1425);
	Get_BMP_565_16("0:/PICTURE_PULSE/1525.bmp",position_1525);
	Get_BMP_565_16("0:/PICTURE_PULSE/1625.bmp",position_1625);
	Get_BMP_565_16("0:/PICTURE_PULSE/1725.bmp",position_1725);
	Get_BMP_565_16("0:/PICTURE_PULSE/1825.bmp",position_1825);
	Get_BMP_565_16("0:/PICTURE_PULSE/1925.bmp",position_1925);
	Get_BMP_565_16("0:/PICTURE_PULSE/2025.bmp",position_2025);
	Get_BMP_565_16("0:/PICTURE_PULSE/pre_play_0.bmp",pre_play_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/pre_play_1.bmp",pre_play_1);
	Get_BMP_565_16("0:/PICTURE_PULSE/con_play_0.bmp",con_play_0);
	Get_BMP_565_16("0:/PICTURE_PULSE/con_play_1.bmp",con_play_1);
	//Get_BMP_565_16("0:/PICTURE_PULSE/ASCII.bmp",ASCII);
}