#include "./showstring/showstring.h"
#include "string.h"
#include "ff.h"
#include "./lcd/bsp_lcd.h"
#include "picture.h"

#define BTDISPLAY_BASE_X_STEP   20
#define BTDISPLAY_BASE_Y_STEP   30
uint16_t ASCII[20*2756+2]__attribute__((at(0xD3000000)));

void KeyBoard_Init()
{ 
	Get_BMP_565_16("0:/PICTURE/ASCII.bmp",ASCII);//�ַ�ͼ��
}

uint16_t *BT_Mapping(char chr)
{
	if(chr<32||chr>126) chr = 32; //��֧�ֵ��ַ������⴦��
	return &ASCII[20*29*(chr-32)];  //���ص�ַָ��
}

void DisplayString(int x_pos, int y_pos, char *string)
{
	u8 length = strlen(string);
	for(int k=0; k<length; k++)  //����ַ���,ӳ�䵽��ӦͼƬ
	{
		move_Image_Asm_565(x_pos,y_pos+BTDISPLAY_BASE_Y_STEP*k,BTDISPLAY_BASE_X_STEP,BTDISPLAY_BASE_Y_STEP,BT_Mapping(string[k]));		
	}
}