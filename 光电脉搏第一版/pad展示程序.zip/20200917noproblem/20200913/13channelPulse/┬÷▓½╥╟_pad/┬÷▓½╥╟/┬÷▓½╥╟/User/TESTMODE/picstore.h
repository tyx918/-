#ifndef __PICSTORE_H
#define __PICSTORE_H

extern const unsigned char gImage_loading[132080];

#endif