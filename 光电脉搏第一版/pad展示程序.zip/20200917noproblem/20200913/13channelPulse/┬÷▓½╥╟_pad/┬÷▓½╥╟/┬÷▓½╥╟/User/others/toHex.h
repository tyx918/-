#ifndef __TOHEX_H
#define __TOHEX_H

char* getHex(int num);

#endif