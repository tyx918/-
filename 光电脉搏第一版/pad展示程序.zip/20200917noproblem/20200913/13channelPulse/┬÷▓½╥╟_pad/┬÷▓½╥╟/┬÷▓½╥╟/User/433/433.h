#ifndef __433_H
#define __433_H
#include "stm32f4xx.h"
//#include "./music/musicPlayer.h"

#define PAD_ID 1

#define Icon433_x 50
#define Icon433_y 550
extern uint8_t Mode_433;
extern uint8_t Broadcast_Status;
extern uint8_t ZC_Flag;
extern uint8_t Connected433;
extern uint16_t Icon433_Connecting[48*48+2]__attribute__((at(0xD0300000)));;
extern uint16_t Icon433_Connected[48*48+2]__attribute__((at(0xD0300000+0x1204)));;
extern uint16_t HowMany_433Connected;  //�������433�ӻ��Ѿ�����
extern uint8_t Receive_433;  //�յ�433��־

typedef struct {
	uint8_t Status;
	char Description[20];
}Received433_Buf;

extern Received433_Buf Cmd_Received433_Buf_C[26];
extern Received433_Buf Cmd_Received433_Buf_S[26];

void MD_Init(void);
void GetIMEI(void);
void Connect_433_Config(void);
char* Rev433Cmd(void);
uint8_t send433Cmd(char * command);
void Mapping_Table_Init(void);
void Mapping_Table(void);
int simple_atoi(char *source);

#endif

















