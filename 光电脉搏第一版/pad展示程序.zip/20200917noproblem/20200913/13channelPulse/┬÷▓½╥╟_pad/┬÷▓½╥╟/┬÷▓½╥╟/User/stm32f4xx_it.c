/**
  ******************************************************************************
  * @file    Project/STM32F4xx_StdPeriph_Templates/stm32f4xx_it.c 
  * @author  MCD Application Team
  * @version V1.5.0
  * @date    06-March-2015
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2015 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_it.h"
#include "./usart/bsp_debug_usart.h"
#include "./Bsp/systick/bsp_SysTick.h"

#include "dateReceive.h"

#include <string.h>

extern uint8_t USART2_RX_BUF[SENDBUFF_SIZE];
extern uint8_t USART2_RX_lenth;
extern uint8_t USART2_RX_Status;


void kk(void)
{
		uint16_t i;

		if(DATA_Config(USART2_RX_BUF,USART2_RX_lenth))//��֤�Ƿ��֡ͷ��ͬʱ����֡β
		{
				if(BUG_USART_ENABLE)
					printf("\r\n������ȷ��������\r\n");		
				
				//��ӡ��������
				for (i = 0 ; i < USART2_RX_lenth ; i ++)
				{
						//printf("%02x ",TX_Buff[i]);
						//printf("%c",TX_Buff[i]);					
					//data_receive[i]=TX_Buff[i];
				}
			  //display();
				
				DMA_Write_buf(64);	//��spi-dma��CPLD��������
		}
		else
		{
				if(BUG_USART_ENABLE)
				printf("\r\n���ݴ��󣡣�����\r\n");
		}
		USART2_RX_lenth=0;USART2_RX_Status=0;	//����
		
}
/** @addtogroup STM32F429I_DISCOVERY_Examples
  * @{
  */

/** @addtogroup FMC_SDRAM
  * @{
  */ 

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M4 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
	printf("hardfault!!!\n");
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}
/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {}
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {}
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {}
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{}

/**
  * @brief  This function handles PendSV_Handler exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */

/******************************************************************************/
/*                 STM32F4xx Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f429_439xx.s).                         */
/******************************************************************************/
	
	
/***************************
		���������жϽ���
***************************/	
void DEBUG_USART1_IRQHandler(void)
{
		uint8_t ucTemp;
		if(USART_GetITStatus(DEBUG_USART1,USART_IT_RXNE)!=RESET)
		{		
//		ucTemp = USART_ReceiveData( DEBUG_USART1 );	//�����յ�һ���ַ�
//    USART_SendData(DEBUG_USART2,ucTemp);    		//�����ڷ�һ���ַ�
		}	 
}


/**
  * @brief  ����2���յ����ݶ����ݴ����Լ���ӡ����ʾ��Ϣ
  * @param  None
  * @retval None
  */
void USART2_DATA_ConfigandPrintf(void)
{
	  uint16_t i;
    if(BUG_USART_ENABLE)	/* �����жϽ������� */
		{
				printf("  STM32����2������ : ");	/* ���� */
				for(i=0;i<USART2_RX_lenth;i++)
				{
//						printf("%02x ",USART2_RX_BUF[i]);	/* ��ʾ16������ */
						printf("%c",USART2_RX_BUF[i]);			/* ��ʾ�ַ� */
				}	
				printf("���ݳ��� : %d\r\n",USART2_RX_lenth);
		}
			
		
		//����֡ͷ,������֡β
		if(DATA_Config(USART2_RX_BUF,USART2_RX_lenth))
		{			
				
				if (USART2_RX_BUF[0]=='#')	/* ���յ� [����] �� [����] */
				{
						if(BUG_USART_ENABLE) 
								printf("֡ͷ������ȷ������ \r\n");	
						
						switch(USART2_RX_BUF[1])
						{
								case 'W':	if (USART2_RX_BUF[2] == '0')	
															linsi_status=1;	/* WiFi�ϴ� */
													else if (USART2_RX_BUF[2] == '1')	
															linsi_status=2;	/* WiFi���� */
													break;	/* WiFi��� */
							
								case 'B': if (USART2_RX_BUF[2] == '0')	linsi_status=0;	/* ����... */
													else if (USART2_RX_BUF[2] == '1')	linsi_status=3;	/* �����Ÿ� */
													//else	DMA_Write_buf(64);	//����ָ��
													break;/* ������� */
								
								case '4':
													break;/* 443��� */
								
								default:DMA_Write_buf(64);	
													break; /* ������� */
						}
				} 
				else if(USART2_RX_BUF[0]=='$'){
						
						DMA_Write_buf(64);				
				
				
				}
		}
		else
		{ 
				if(BUG_USART_ENABLE)
						printf("\r\n���ݴ��󣡣�����\r\n");
		}
		USART2_RX_lenth=0;	/* ���ý��ܻ���->���� */
		USART2_RX_Status=0;	/* ���ܻ���->״̬���� */
		return ;
}



/***************************
		stm32
***************************/
void DEBUG_USART2_IRQHandler(void)
{
	uint8_t i;
  uint8_t ucTemp;
	static uint8_t conpt;
	static uint8_t buty;
			
	if(BUG_USART_ENABLE)	//��BUG_USART_ENABLEΪ1ʱ�� ����2���ڵ��� 
	{
				if(USART_GetITStatus(DEBUG_USART2,USART_IT_RXNE)!=RESET)
				{		
					ucTemp = USART_ReceiveData( DEBUG_USART2 );	//�жϽ��ܴ���2����
					if(USART2_RX_Status!=1)
					{  
							USART2_RX_BUF[conpt] = ucTemp;conpt++;	//�����ܵ����ݴ�����ܻ���
							if( (USART2_RX_BUF[conpt-1]==0x0a)&&(USART2_RX_BUF[conpt-2]==0x0d))	//�����ܵ�����Ϊ\r\n(��������)
							{								
									USART2_RX_lenth=conpt;	//��ȡ�������ݵĳ���
									conpt=0;	//����
									USART2_RX_Status=1;		//״ֵ̬
									buty=1;
									USART2_DATA_ConfigandPrintf();
									//kk();	//���Ժ���
									return ;
							}									
					}
				}	
				else if(USART_GetITStatus(DEBUG_USART2,USART_IT_IDLE)!=RESET)
				{ 
							if(buty){buty=0;}
							else{
									USART2_RX_lenth=conpt;	
									USART2_RX_Status=1;conpt=0;					
									ucTemp=USART2->SR;
									ucTemp=USART2->DR;		
									kk();								
							}			
							ucTemp=USART2->SR;
							ucTemp=USART2->DR;
				}
	}
	else if(USART_GetITStatus(DEBUG_USART2,USART_IT_RXNE)!=RESET)
	{		
		ucTemp = USART_ReceiveData( DEBUG_USART2 );
    USART_SendData(DEBUG_USART2,ucTemp);    
	}	 
			
}

/***************************
		wifi�����жϽ���
***************************/
void DEBUG_UART4_IRQHandler(void)
{
  uint8_t ucTemp;
	if(USART_GetITStatus(DEBUG_UART4,USART_IT_RXNE)!=RESET)
	{		
//		ucTemp = USART_ReceiveData( DEBUG_UART4 );
//    USART_SendData(DEBUG_UART4,ucTemp);    
	}	 
}	

/***************************
		433�����жϽ���
***************************/
void DEBUG_USART6_IRQHandler(void)
{
  uint8_t ucTemp;
	if(USART_GetITStatus(DEBUG_USART6,USART_IT_RXNE)!=RESET)
	{		
//		ucTemp = USART_ReceiveData( DEBUG_USART6 );
//    USART_SendData(DEBUG_USART2,ucTemp); 
USART_ClearITPendingBit(DEBUG_USART2,USART_IT_RXNE);	
	}	
}

void SysTick_Handler(void)
{
	TimingDelay_Decrement();
}

/**
  * @}
  */ 

/**
  * @}
  */ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

