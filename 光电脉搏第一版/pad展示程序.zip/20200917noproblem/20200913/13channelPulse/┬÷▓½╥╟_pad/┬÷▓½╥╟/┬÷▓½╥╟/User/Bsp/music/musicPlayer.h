#ifndef __MUSICPLAYER_H__
#define __MUSICPLAYER_H__

#include <inttypes.h>
#include "stm32f4xx.h"


/* ״̬ */
enum
{
	STA_IDLE = 0,	/* ����״̬ */
	STA_RECORDING,	/* ¼��״̬ */
	STA_PLAYING,	/* ����״̬ */
	STA_ERR,			/*  error  */
};

extern u16 wifidata_lens;  
void wav_Player(const char *filename);
void W_download_SD(void);
void W_uploading_SD(const char *filename);


#endif  /* __MUSICPLAYER_H__   */
