#include "./others/toHex.h"
char* getHex(int num)
{
	char* res = "";
	switch (num)
	{
	case 1:
		res = "1";
		break;
	case 2:
		res = "2";
		break;
	case 3:
		res = "3";
		break;
	case 4:
		res = "4";
		break;
	case 5:
		res = "5";
		break;
	case 6:
		res = "6";
		break;
	case 7:
		res = "7";
		break;
	case 8:
		res = "8";
		break;
	case 9:
		res = "9";
		break;
	case 10:
		res = "A";
		break;
	case 11:
		res = "B";
		break;
	case 12:
		res = "C";
		break;
	case 13:
		res = "D";
		break;
	case 14:
		res = "E"; 
		break;
	case 15:
		res = "F";
		break;
	default:
		break;
	}
	return res;
}