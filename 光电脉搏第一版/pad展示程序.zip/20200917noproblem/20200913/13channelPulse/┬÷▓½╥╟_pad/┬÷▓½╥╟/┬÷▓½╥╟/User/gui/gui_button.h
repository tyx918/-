#ifndef _GUI_BUTTON_H_
#define _GUI_BUTTON_H_

#include "stdio.h"
#include "stdlib.h"
#include "gui_touch.h"
#include "gui_touch_deal.h"
#include "lcd_conf.h"
#include "song_select_deal.h"

#define BUTTON_WEDEG_FLAG 9              //��ť�ؼ���־�����ڴ��������Ϣ

int OnTouch_Button(GUI_PID_DATA pData);
void Show_Button_Dowm(unsigned short x,unsigned short y,unsigned short Xsize,unsigned short Ysize,unsigned char Mode,unsigned short SetColor);
void Show_Button_Up(unsigned short x,unsigned short y,unsigned short Xsize,unsigned short Ysize,unsigned char Mode,unsigned short SetColor);




#endif
