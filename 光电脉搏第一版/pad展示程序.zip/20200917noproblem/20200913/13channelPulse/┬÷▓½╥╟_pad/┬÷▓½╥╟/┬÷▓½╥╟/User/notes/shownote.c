#include "shownote.h"
#include "xpt.h"
#include "./lcd/bsp_lcd.h"
#include "./bmp/bsp_bmp.h"
#include "touch_conf.h"

 u8  Lyrics_Song_Switch_Flag = 0;       //0:��ʼ״̬--�����ģʽ��1:����ģʽ��
 u8  Ci_First_Page_Loading_done = 1;
 u8  Qu_First_Page_Loading_done = 1;
 u8  Ci_Loading_done = 1;
 u8  Qu_Loading_done = 1;
 
 u16 Line_index = 0;  //LINE(Line_index)
 
 int song_total_page;
 
 char *song_name_bar;
 
 char *Music_Score_1[50];
 char *Music_Score_2[50];
 char *Music_Score_3[50];
 char *Music_Lyrics_3[50];
 
 /***************����֮��**********************/
 char *Pearl_of_East_1[32] = {
																						Pearl_of_East_Music_Score_1_0,
																						Pearl_of_East_Music_Score_1_1,
																						Pearl_of_East_Music_Score_1_2,
																						Pearl_of_East_Music_Score_1_3,
																						Pearl_of_East_Music_Score_1_4,
																						Pearl_of_East_Music_Score_1_5,
																						Pearl_of_East_Music_Score_1_6,
																						Pearl_of_East_Music_Score_1_7,
																						Pearl_of_East_Music_Score_1_8,
																						Pearl_of_East_Music_Score_1_9,
																						Pearl_of_East_Music_Score_1_10,
																						Pearl_of_East_Music_Score_1_11,
																						Pearl_of_East_Music_Score_1_12,
																						Pearl_of_East_Music_Score_1_13,
																						Pearl_of_East_Music_Score_1_14,
																						Pearl_of_East_Music_Score_1_15,
																						Pearl_of_East_Music_Score_1_16,
																						Pearl_of_East_Music_Score_1_17,
																						Pearl_of_East_Music_Score_1_18,
																						Pearl_of_East_Music_Score_1_19,
																						Pearl_of_East_Music_Score_1_20,
																						Pearl_of_East_Music_Score_1_21,
																						Pearl_of_East_Music_Score_1_22,
																						Pearl_of_East_Music_Score_1_23,
																						Pearl_of_East_Music_Score_1_24,
																						Pearl_of_East_Music_Score_1_25,
																						Pearl_of_East_Music_Score_1_26,
																						Pearl_of_East_Music_Score_1_27,
																						Pearl_of_East_Music_Score_1_28,
																						Pearl_of_East_Music_Score_1_29,
																						Pearl_of_East_Music_Score_1_30,
																						Pearl_of_East_Music_Score_1_31
                                   };
 char *Pearl_of_East_2[32] = {
																						Pearl_of_East_Music_Score_2_0,
																						Pearl_of_East_Music_Score_2_1,	 
																						Pearl_of_East_Music_Score_2_2,
																						Pearl_of_East_Music_Score_2_3,
																						Pearl_of_East_Music_Score_2_4,
																						Pearl_of_East_Music_Score_2_5,
																						Pearl_of_East_Music_Score_2_6,
																						Pearl_of_East_Music_Score_2_7,
																						Pearl_of_East_Music_Score_2_8,
																						Pearl_of_East_Music_Score_2_9,
																						Pearl_of_East_Music_Score_2_10,
																						Pearl_of_East_Music_Score_2_11,
																						Pearl_of_East_Music_Score_2_12,
																						Pearl_of_East_Music_Score_2_13,
																						Pearl_of_East_Music_Score_2_14,
																						Pearl_of_East_Music_Score_2_15,
																						Pearl_of_East_Music_Score_2_16,
																						Pearl_of_East_Music_Score_2_17,
																						Pearl_of_East_Music_Score_2_18,
																						Pearl_of_East_Music_Score_2_19,
																						Pearl_of_East_Music_Score_2_20,
																						Pearl_of_East_Music_Score_2_21,
																						Pearl_of_East_Music_Score_2_22,
																						Pearl_of_East_Music_Score_2_23,
																						Pearl_of_East_Music_Score_2_24,
																						Pearl_of_East_Music_Score_2_25,
																						Pearl_of_East_Music_Score_2_26,
																						Pearl_of_East_Music_Score_2_27,
																						Pearl_of_East_Music_Score_2_28,
																						Pearl_of_East_Music_Score_2_29,
																						Pearl_of_East_Music_Score_2_30,
																						Pearl_of_East_Music_Score_2_31
                                      };
 char *Pearl_of_East_qu_3[32] = {
																						Pearl_of_East_Music_Score_3_0,
																						Pearl_of_East_Music_Score_3_1,
																						Pearl_of_East_Music_Score_3_2,
																						Pearl_of_East_Music_Score_3_3,
																						Pearl_of_East_Music_Score_3_4,
																						Pearl_of_East_Music_Score_3_5,
																						Pearl_of_East_Music_Score_3_6,
																						Pearl_of_East_Music_Score_3_7,
																						Pearl_of_East_Music_Score_3_8,
																						Pearl_of_East_Music_Score_3_9,
																						Pearl_of_East_Music_Score_3_10,
																						Pearl_of_East_Music_Score_3_11,
																						Pearl_of_East_Music_Score_3_12,
																						Pearl_of_East_Music_Score_3_13,
																						Pearl_of_East_Music_Score_3_14,
																						Pearl_of_East_Music_Score_3_15,
																						Pearl_of_East_Music_Score_3_16,
																						Pearl_of_East_Music_Score_3_17,
																						Pearl_of_East_Music_Score_3_18,
																						Pearl_of_East_Music_Score_3_19,
																						Pearl_of_East_Music_Score_3_20,
																						Pearl_of_East_Music_Score_3_21,
																						Pearl_of_East_Music_Score_3_22,
																						Pearl_of_East_Music_Score_3_23,
																						Pearl_of_East_Music_Score_3_24,
																						Pearl_of_East_Music_Score_3_25,
																						Pearl_of_East_Music_Score_3_26,
																						Pearl_of_East_Music_Score_3_27,
																						Pearl_of_East_Music_Score_3_28,
																						Pearl_of_East_Music_Score_3_29,
																						Pearl_of_East_Music_Score_3_30,
																						Pearl_of_East_Music_Score_3_31
                                      };
 char *Pearl_of_East_ci_3[32] = {
																						Pearl_of_East_Music_Lyrics_3_0,
																						Pearl_of_East_Music_Lyrics_3_1,
																						Pearl_of_East_Music_Lyrics_3_2,
																						Pearl_of_East_Music_Lyrics_3_3,
																						Pearl_of_East_Music_Lyrics_3_4,
																						Pearl_of_East_Music_Lyrics_3_5,
																						Pearl_of_East_Music_Lyrics_3_6,
																						Pearl_of_East_Music_Lyrics_3_7,
																						Pearl_of_East_Music_Lyrics_3_8,
																						Pearl_of_East_Music_Lyrics_3_9,
																						Pearl_of_East_Music_Lyrics_3_10,
																						Pearl_of_East_Music_Lyrics_3_11,
																						Pearl_of_East_Music_Lyrics_3_12,
																						Pearl_of_East_Music_Lyrics_3_13,
																						Pearl_of_East_Music_Lyrics_3_14,
																						Pearl_of_East_Music_Lyrics_3_15,
																						Pearl_of_East_Music_Lyrics_3_16,
																						Pearl_of_East_Music_Lyrics_3_17,
																						Pearl_of_East_Music_Lyrics_3_18,
																						Pearl_of_East_Music_Lyrics_3_19,
																						Pearl_of_East_Music_Lyrics_3_20,
																						Pearl_of_East_Music_Lyrics_3_21,
																						Pearl_of_East_Music_Lyrics_3_22,
																						Pearl_of_East_Music_Lyrics_3_23,
																						Pearl_of_East_Music_Lyrics_3_24,
																						Pearl_of_East_Music_Lyrics_3_25,
																						Pearl_of_East_Music_Lyrics_3_26,
																						Pearl_of_East_Music_Lyrics_3_27,
																						Pearl_of_East_Music_Lyrics_3_28,
																						Pearl_of_East_Music_Lyrics_3_29,
																						Pearl_of_East_Music_Lyrics_3_30,
																						Pearl_of_East_Music_Lyrics_3_31 
                                       };
 
  /***************�Һ��ҵ����**********************/
 char *Me_and_My_Motherland_1[44] = {
																						Me_and_My_Motherland_Music_Score_1_0,
																						Me_and_My_Motherland_Music_Score_1_1,
																						Me_and_My_Motherland_Music_Score_1_2,
																						Me_and_My_Motherland_Music_Score_1_3,
																						Me_and_My_Motherland_Music_Score_1_4,
																						Me_and_My_Motherland_Music_Score_1_5,
																						Me_and_My_Motherland_Music_Score_1_6,
																						Me_and_My_Motherland_Music_Score_1_7,
																						Me_and_My_Motherland_Music_Score_1_8,
																						Me_and_My_Motherland_Music_Score_1_9,
																						Me_and_My_Motherland_Music_Score_1_10,
																						Me_and_My_Motherland_Music_Score_1_11,
																						Me_and_My_Motherland_Music_Score_1_12,
																						Me_and_My_Motherland_Music_Score_1_13,
																						Me_and_My_Motherland_Music_Score_1_14,
																						Me_and_My_Motherland_Music_Score_1_15,
																						Me_and_My_Motherland_Music_Score_1_16,
																						Me_and_My_Motherland_Music_Score_1_17,
																						Me_and_My_Motherland_Music_Score_1_18,
																						Me_and_My_Motherland_Music_Score_1_19,
																						Me_and_My_Motherland_Music_Score_1_20,
																						Me_and_My_Motherland_Music_Score_1_21,
																						Me_and_My_Motherland_Music_Score_1_22,
																						Me_and_My_Motherland_Music_Score_1_23,
																						Me_and_My_Motherland_Music_Score_1_24,
																						Me_and_My_Motherland_Music_Score_1_25,
																						Me_and_My_Motherland_Music_Score_1_26,
																						Me_and_My_Motherland_Music_Score_1_27,
																						Me_and_My_Motherland_Music_Score_1_28,
																						Me_and_My_Motherland_Music_Score_1_29,
																						Me_and_My_Motherland_Music_Score_1_30,
																						Me_and_My_Motherland_Music_Score_1_31,
																						Me_and_My_Motherland_Music_Score_1_32,
																						Me_and_My_Motherland_Music_Score_1_33,
																						Me_and_My_Motherland_Music_Score_1_34,
																						Me_and_My_Motherland_Music_Score_1_35,
																						Me_and_My_Motherland_Music_Score_1_36,
																						Me_and_My_Motherland_Music_Score_1_37,
																						Me_and_My_Motherland_Music_Score_1_38,
																						Me_and_My_Motherland_Music_Score_1_39,
																						Me_and_My_Motherland_Music_Score_1_40,
																						Me_and_My_Motherland_Music_Score_1_41,
																						Me_and_My_Motherland_Music_Score_1_42,
																						Me_and_My_Motherland_Music_Score_1_43                                     
                                     };
 char *Me_and_My_Motherland_2[44] = {
																						Me_and_My_Motherland_Music_Score_2_0,
																						Me_and_My_Motherland_Music_Score_2_1,
																						Me_and_My_Motherland_Music_Score_2_2,
																						Me_and_My_Motherland_Music_Score_2_3,
																						Me_and_My_Motherland_Music_Score_2_4,
																						Me_and_My_Motherland_Music_Score_2_5,
																						Me_and_My_Motherland_Music_Score_2_6,
																						Me_and_My_Motherland_Music_Score_2_7,
																						Me_and_My_Motherland_Music_Score_2_8,
																						Me_and_My_Motherland_Music_Score_2_9,
																						Me_and_My_Motherland_Music_Score_2_10,
																						Me_and_My_Motherland_Music_Score_2_11,
																						Me_and_My_Motherland_Music_Score_2_12,
																						Me_and_My_Motherland_Music_Score_2_13,
																						Me_and_My_Motherland_Music_Score_2_14,
																						Me_and_My_Motherland_Music_Score_2_15,
																						Me_and_My_Motherland_Music_Score_2_16,
																						Me_and_My_Motherland_Music_Score_2_17,
																						Me_and_My_Motherland_Music_Score_2_18,
																						Me_and_My_Motherland_Music_Score_2_19,
																						Me_and_My_Motherland_Music_Score_2_20,
																						Me_and_My_Motherland_Music_Score_2_21,
																						Me_and_My_Motherland_Music_Score_2_22,
																						Me_and_My_Motherland_Music_Score_2_23,
																						Me_and_My_Motherland_Music_Score_2_24,
																						Me_and_My_Motherland_Music_Score_2_25,
																						Me_and_My_Motherland_Music_Score_2_26,
																						Me_and_My_Motherland_Music_Score_2_27,
																						Me_and_My_Motherland_Music_Score_2_28,
																						Me_and_My_Motherland_Music_Score_2_29,
																						Me_and_My_Motherland_Music_Score_2_30,
																						Me_and_My_Motherland_Music_Score_2_31,
																						Me_and_My_Motherland_Music_Score_2_32,
																						Me_and_My_Motherland_Music_Score_2_33,
																						Me_and_My_Motherland_Music_Score_2_34,
																						Me_and_My_Motherland_Music_Score_2_35,
																						Me_and_My_Motherland_Music_Score_2_36,
																						Me_and_My_Motherland_Music_Score_2_37,
																						Me_and_My_Motherland_Music_Score_2_38,
																						Me_and_My_Motherland_Music_Score_2_39,
																						Me_and_My_Motherland_Music_Score_2_40,
																						Me_and_My_Motherland_Music_Score_2_41,
																						Me_and_My_Motherland_Music_Score_2_42,
																						Me_and_My_Motherland_Music_Score_2_43
                                     };
 char *Me_and_My_Motherland_qu_3[44] = {
																						Me_and_My_Motherland_Music_Score_3_0,
																						Me_and_My_Motherland_Music_Score_3_1,
																						Me_and_My_Motherland_Music_Score_3_2,
																						Me_and_My_Motherland_Music_Score_3_3,
																						Me_and_My_Motherland_Music_Score_3_4,
																						Me_and_My_Motherland_Music_Score_3_5,
																						Me_and_My_Motherland_Music_Score_3_6,
																						Me_and_My_Motherland_Music_Score_3_7,
																						Me_and_My_Motherland_Music_Score_3_8,
																						Me_and_My_Motherland_Music_Score_3_9,
																						Me_and_My_Motherland_Music_Score_3_10,
																						Me_and_My_Motherland_Music_Score_3_11,
																						Me_and_My_Motherland_Music_Score_3_12,
																						Me_and_My_Motherland_Music_Score_3_13,
																						Me_and_My_Motherland_Music_Score_3_14,
																						Me_and_My_Motherland_Music_Score_3_15,
																						Me_and_My_Motherland_Music_Score_3_16,
																						Me_and_My_Motherland_Music_Score_3_17,
																						Me_and_My_Motherland_Music_Score_3_18,
																						Me_and_My_Motherland_Music_Score_3_19,
																						Me_and_My_Motherland_Music_Score_3_20,
																						Me_and_My_Motherland_Music_Score_3_21,
																						Me_and_My_Motherland_Music_Score_3_22,
																						Me_and_My_Motherland_Music_Score_3_23,
																						Me_and_My_Motherland_Music_Score_3_24,
																						Me_and_My_Motherland_Music_Score_3_25,
																						Me_and_My_Motherland_Music_Score_3_26,
																						Me_and_My_Motherland_Music_Score_3_27,
																						Me_and_My_Motherland_Music_Score_3_28,
																						Me_and_My_Motherland_Music_Score_3_29,
																						Me_and_My_Motherland_Music_Score_3_30,
																						Me_and_My_Motherland_Music_Score_3_31,
																						Me_and_My_Motherland_Music_Score_3_32,
																						Me_and_My_Motherland_Music_Score_3_33,
																						Me_and_My_Motherland_Music_Score_3_34,
																						Me_and_My_Motherland_Music_Score_3_35,
																						Me_and_My_Motherland_Music_Score_3_36,
																						Me_and_My_Motherland_Music_Score_3_37,
																						Me_and_My_Motherland_Music_Score_3_38,
																						Me_and_My_Motherland_Music_Score_3_39,
																						Me_and_My_Motherland_Music_Score_3_40,
																						Me_and_My_Motherland_Music_Score_3_41,
																						Me_and_My_Motherland_Music_Score_3_42,
																						Me_and_My_Motherland_Music_Score_3_43
                                        };
 char *Me_and_My_Motherland_ci_3[44] = {
																						Me_and_My_Motherland_Music_Lyrics_3_0,
																						Me_and_My_Motherland_Music_Lyrics_3_1,
																						Me_and_My_Motherland_Music_Lyrics_3_2,
																						Me_and_My_Motherland_Music_Lyrics_3_3,
																						Me_and_My_Motherland_Music_Lyrics_3_4,
																						Me_and_My_Motherland_Music_Lyrics_3_5,
																						Me_and_My_Motherland_Music_Lyrics_3_6,
																						Me_and_My_Motherland_Music_Lyrics_3_7,
																						Me_and_My_Motherland_Music_Lyrics_3_8,
																						Me_and_My_Motherland_Music_Lyrics_3_9,
																						Me_and_My_Motherland_Music_Lyrics_3_10,
																						Me_and_My_Motherland_Music_Lyrics_3_11,
																						Me_and_My_Motherland_Music_Lyrics_3_12,
																						Me_and_My_Motherland_Music_Lyrics_3_13,
																						Me_and_My_Motherland_Music_Lyrics_3_14,
																						Me_and_My_Motherland_Music_Lyrics_3_15,
																						Me_and_My_Motherland_Music_Lyrics_3_16,
																						Me_and_My_Motherland_Music_Lyrics_3_17,
																						Me_and_My_Motherland_Music_Lyrics_3_18,
																						Me_and_My_Motherland_Music_Lyrics_3_19,
																						Me_and_My_Motherland_Music_Lyrics_3_20,
																						Me_and_My_Motherland_Music_Lyrics_3_21,
																						Me_and_My_Motherland_Music_Lyrics_3_22,
																						Me_and_My_Motherland_Music_Lyrics_3_23,
																						Me_and_My_Motherland_Music_Lyrics_3_24,
																						Me_and_My_Motherland_Music_Lyrics_3_25,
																						Me_and_My_Motherland_Music_Lyrics_3_26,
																						Me_and_My_Motherland_Music_Lyrics_3_27,
																						Me_and_My_Motherland_Music_Lyrics_3_28,
																						Me_and_My_Motherland_Music_Lyrics_3_29,
																						Me_and_My_Motherland_Music_Lyrics_3_30,
																						Me_and_My_Motherland_Music_Lyrics_3_31,
																						Me_and_My_Motherland_Music_Lyrics_3_32,
																						Me_and_My_Motherland_Music_Lyrics_3_33,
																						Me_and_My_Motherland_Music_Lyrics_3_34,
																						Me_and_My_Motherland_Music_Lyrics_3_35,
																						Me_and_My_Motherland_Music_Lyrics_3_36,
																						Me_and_My_Motherland_Music_Lyrics_3_37,
																						Me_and_My_Motherland_Music_Lyrics_3_38,
																						Me_and_My_Motherland_Music_Lyrics_3_39,
																						Me_and_My_Motherland_Music_Lyrics_3_40,
																						Me_and_My_Motherland_Music_Lyrics_3_41,
																						Me_and_My_Motherland_Music_Lyrics_3_42,
																						Me_and_My_Motherland_Music_Lyrics_3_43 
                                        };
 
  /*****************�ҵ����************************/																 
 char *My_Country_1[38] = {
 																		My_Country_Music_Score_1_0,
																		My_Country_Music_Score_1_1,
 																		My_Country_Music_Score_1_2,
																		My_Country_Music_Score_1_3,
                                    My_Country_Music_Score_1_4,
																		My_Country_Music_Score_1_5,
                                    My_Country_Music_Score_1_6,
																		My_Country_Music_Score_1_7,
                                    My_Country_Music_Score_1_8,
																		My_Country_Music_Score_1_9,
                                    My_Country_Music_Score_1_10,
																		My_Country_Music_Score_1_11,
                                    My_Country_Music_Score_1_12,
																		My_Country_Music_Score_1_13,
                                    My_Country_Music_Score_1_14,
																		My_Country_Music_Score_1_15,
                                    My_Country_Music_Score_1_16,
																		My_Country_Music_Score_1_17,
                                    My_Country_Music_Score_1_18,
																		My_Country_Music_Score_1_19,
                                    My_Country_Music_Score_1_20,
																		My_Country_Music_Score_1_21,
                                    My_Country_Music_Score_1_22,
																		My_Country_Music_Score_1_23,
                                    My_Country_Music_Score_1_24,
																		My_Country_Music_Score_1_25,
                                    My_Country_Music_Score_1_26,
																		My_Country_Music_Score_1_27,
																		My_Country_Music_Score_1_28,
																		My_Country_Music_Score_1_29,
																		My_Country_Music_Score_1_30,
																		My_Country_Music_Score_1_31,
																		My_Country_Music_Score_1_32,
																		My_Country_Music_Score_1_33,
                                    My_Country_Music_Score_1_34,
																		My_Country_Music_Score_1_35,
                                    My_Country_Music_Score_1_36,
																		My_Country_Music_Score_1_37																		
                           };
 char *My_Country_2[38] = {
																		My_Country_Music_Score_2_0,
																		My_Country_Music_Score_2_1,
																		My_Country_Music_Score_2_2,
																		My_Country_Music_Score_2_3,
                                    My_Country_Music_Score_2_4,
																		My_Country_Music_Score_2_5,
                                    My_Country_Music_Score_2_6,
																		My_Country_Music_Score_2_7,
                                    My_Country_Music_Score_2_8,
																		My_Country_Music_Score_2_9,
                                    My_Country_Music_Score_2_10,
																		My_Country_Music_Score_2_11,
                                    My_Country_Music_Score_2_12,
																		My_Country_Music_Score_2_13,
                                    My_Country_Music_Score_2_14,
																		My_Country_Music_Score_2_15,
                                    My_Country_Music_Score_2_16,
																		My_Country_Music_Score_2_17,
                                    My_Country_Music_Score_2_18,
																		My_Country_Music_Score_2_19,
                                    My_Country_Music_Score_2_20,
																		My_Country_Music_Score_2_21,
                                    My_Country_Music_Score_2_22,
																		My_Country_Music_Score_2_23,
                                    My_Country_Music_Score_2_24,
																		My_Country_Music_Score_2_25,
                                    My_Country_Music_Score_2_26,
																		My_Country_Music_Score_2_27,
																		My_Country_Music_Score_2_28,
																		My_Country_Music_Score_2_29,
																		My_Country_Music_Score_2_30,
																		My_Country_Music_Score_2_31,
																		My_Country_Music_Score_2_32,
																		My_Country_Music_Score_2_33,
                                    My_Country_Music_Score_2_34,
																		My_Country_Music_Score_2_35,
                                    My_Country_Music_Score_2_36,
																		My_Country_Music_Score_2_37                            
                           };
 char *My_Country_qu_3[38] = {
 																	  My_Country_Music_Score_3_0,
																		My_Country_Music_Score_3_1,
 																	  My_Country_Music_Score_3_2,
																		My_Country_Music_Score_3_3,
                                    My_Country_Music_Score_3_4,
																		My_Country_Music_Score_3_5,
                                    My_Country_Music_Score_3_6,
																		My_Country_Music_Score_3_7,
                                    My_Country_Music_Score_3_8,
																		My_Country_Music_Score_3_9,
                                    My_Country_Music_Score_3_10,
																		My_Country_Music_Score_3_11,
                                    My_Country_Music_Score_3_12,
																		My_Country_Music_Score_3_13,
                                    My_Country_Music_Score_3_14,
																		My_Country_Music_Score_3_15,
                                    My_Country_Music_Score_3_16,
																		My_Country_Music_Score_3_17,
                                    My_Country_Music_Score_3_18,
																		My_Country_Music_Score_3_19,
                                    My_Country_Music_Score_3_20,
																		My_Country_Music_Score_3_21,
                                    My_Country_Music_Score_3_22,
																		My_Country_Music_Score_3_23,
                                    My_Country_Music_Score_3_24,
																		My_Country_Music_Score_3_25,
                                    My_Country_Music_Score_3_26,
																		My_Country_Music_Score_3_27,
																		My_Country_Music_Score_3_28,
																		My_Country_Music_Score_3_29,
																		My_Country_Music_Score_3_30,
																		My_Country_Music_Score_3_31,
																		My_Country_Music_Score_3_32,
																		My_Country_Music_Score_3_33,
                                    My_Country_Music_Score_3_34,
																		My_Country_Music_Score_3_35,
                                    My_Country_Music_Score_3_36,
																		My_Country_Music_Score_3_37	                             
                              };
 char *My_Country_ci_3[38] = {
																		My_Country_Music_Lyrics_3_0,
																		My_Country_Music_Lyrics_3_1,
																		My_Country_Music_Lyrics_3_2,
																		My_Country_Music_Lyrics_3_3,
                                    My_Country_Music_Lyrics_3_4,
																		My_Country_Music_Lyrics_3_5,
                                    My_Country_Music_Lyrics_3_6,
																		My_Country_Music_Lyrics_3_7,
                                    My_Country_Music_Lyrics_3_8,
																		My_Country_Music_Lyrics_3_9,
                                    My_Country_Music_Lyrics_3_10,
																		My_Country_Music_Lyrics_3_11,
                                    My_Country_Music_Lyrics_3_12,
																		My_Country_Music_Lyrics_3_13,
                                    My_Country_Music_Lyrics_3_14,
																		My_Country_Music_Lyrics_3_15,
                                    My_Country_Music_Lyrics_3_16,
																		My_Country_Music_Lyrics_3_17,
                                    My_Country_Music_Lyrics_3_18,
																		My_Country_Music_Lyrics_3_19,
                                    My_Country_Music_Lyrics_3_20,
																		My_Country_Music_Lyrics_3_21,
                                    My_Country_Music_Lyrics_3_22,
																		My_Country_Music_Lyrics_3_23,
                                    My_Country_Music_Lyrics_3_24,
																		My_Country_Music_Lyrics_3_25,
                                    My_Country_Music_Lyrics_3_26,
																		My_Country_Music_Lyrics_3_27,
																		My_Country_Music_Lyrics_3_28,
																		My_Country_Music_Lyrics_3_29,
																		My_Country_Music_Lyrics_3_30,
																		My_Country_Music_Lyrics_3_31,
																		My_Country_Music_Lyrics_3_32,
																		My_Country_Music_Lyrics_3_33,
                                    My_Country_Music_Lyrics_3_34,
																		My_Country_Music_Lyrics_3_35,
                                    My_Country_Music_Lyrics_3_36,
																		My_Country_Music_Lyrics_3_37	 
                              };
 
  /******************ѩ�޻�*************************/																 
 char *Edelweiss_1[30] = {
 																		Edelweiss_Music_Score_1_0,
																		Edelweiss_Music_Score_1_1,
 																		Edelweiss_Music_Score_1_2,
																		Edelweiss_Music_Score_1_3,
                                    Edelweiss_Music_Score_1_4,
																		Edelweiss_Music_Score_1_5,
                                    Edelweiss_Music_Score_1_6,
																		Edelweiss_Music_Score_1_7,
                                    Edelweiss_Music_Score_1_8,
																		Edelweiss_Music_Score_1_9,
                                    Edelweiss_Music_Score_1_10,
																		Edelweiss_Music_Score_1_11,
                                    Edelweiss_Music_Score_1_12,
																		Edelweiss_Music_Score_1_13,
                                    Edelweiss_Music_Score_1_14,
																		Edelweiss_Music_Score_1_15,
                                    Edelweiss_Music_Score_1_16,
																		Edelweiss_Music_Score_1_17,
                                    Edelweiss_Music_Score_1_18,
																		Edelweiss_Music_Score_1_19,
                                    Edelweiss_Music_Score_1_20,
																		Edelweiss_Music_Score_1_21,
                                    Edelweiss_Music_Score_1_22,
																		Edelweiss_Music_Score_1_23,
                                    Edelweiss_Music_Score_1_24,
																		Edelweiss_Music_Score_1_25,
                                    Edelweiss_Music_Score_1_26,
																		Edelweiss_Music_Score_1_27                         
                           };
 char *Edelweiss_2[30]= {
																		Edelweiss_Music_Score_2_0,
																		Edelweiss_Music_Score_2_1,
																		Edelweiss_Music_Score_2_2,
																		Edelweiss_Music_Score_2_3,
                                    Edelweiss_Music_Score_2_4,
																		Edelweiss_Music_Score_2_5,
                                    Edelweiss_Music_Score_2_6,
																		Edelweiss_Music_Score_2_7,
                                    Edelweiss_Music_Score_2_8,
																		Edelweiss_Music_Score_2_9,
                                    Edelweiss_Music_Score_2_10,
																		Edelweiss_Music_Score_2_11,
                                    Edelweiss_Music_Score_2_12,
																		Edelweiss_Music_Score_2_13,
                                    Edelweiss_Music_Score_2_14,
																		Edelweiss_Music_Score_2_15,
                                    Edelweiss_Music_Score_2_16,
																		Edelweiss_Music_Score_2_17,
                                    Edelweiss_Music_Score_2_18,
																		Edelweiss_Music_Score_2_19,
                                    Edelweiss_Music_Score_2_20,
																		Edelweiss_Music_Score_2_21,
                                    Edelweiss_Music_Score_2_22,
																		Edelweiss_Music_Score_2_23,
                                    Edelweiss_Music_Score_2_24,
																		Edelweiss_Music_Score_2_25,
                                    Edelweiss_Music_Score_2_26,
																		Edelweiss_Music_Score_2_27                        
                           };
 char *Edelweiss_qu_3[30] = {
 																	  Edelweiss_Music_Score_3_0,
																		Edelweiss_Music_Score_3_1,
 																	  Edelweiss_Music_Score_3_2,
																		Edelweiss_Music_Score_3_3,
                                    Edelweiss_Music_Score_3_4,
																		Edelweiss_Music_Score_3_5,
                                    Edelweiss_Music_Score_3_6,
																		Edelweiss_Music_Score_3_7,
                                    Edelweiss_Music_Score_3_8,
																		Edelweiss_Music_Score_3_9,
                                    Edelweiss_Music_Score_3_10,
																		Edelweiss_Music_Score_3_11,
                                    Edelweiss_Music_Score_3_12,
																		Edelweiss_Music_Score_3_13,
                                    Edelweiss_Music_Score_3_14,
																		Edelweiss_Music_Score_3_15,
                                    Edelweiss_Music_Score_3_16,
																		Edelweiss_Music_Score_3_17,
                                    Edelweiss_Music_Score_3_18,
																		Edelweiss_Music_Score_3_19,
                                    Edelweiss_Music_Score_3_20,
																		Edelweiss_Music_Score_3_21,
                                    Edelweiss_Music_Score_3_22,
																		Edelweiss_Music_Score_3_23,
                                    Edelweiss_Music_Score_3_24,
																		Edelweiss_Music_Score_3_25,
                                    Edelweiss_Music_Score_3_26,
																		Edelweiss_Music_Score_3_27	                             
                              };
 char *Edelweiss_ci_3[30]= {
																		Edelweiss_Music_Lyrics_3_0,
																		Edelweiss_Music_Lyrics_3_1,
																		Edelweiss_Music_Lyrics_3_2,
																		Edelweiss_Music_Lyrics_3_3,
                                    Edelweiss_Music_Lyrics_3_4,
																		Edelweiss_Music_Lyrics_3_5,
                                    Edelweiss_Music_Lyrics_3_6,
																		Edelweiss_Music_Lyrics_3_7,
                                    Edelweiss_Music_Lyrics_3_8,
																		Edelweiss_Music_Lyrics_3_9,
                                    Edelweiss_Music_Lyrics_3_10,
																		Edelweiss_Music_Lyrics_3_11,
                                    Edelweiss_Music_Lyrics_3_12,
																		Edelweiss_Music_Lyrics_3_13,
                                    Edelweiss_Music_Lyrics_3_14,
																		Edelweiss_Music_Lyrics_3_15,
                                    Edelweiss_Music_Lyrics_3_16,
																		Edelweiss_Music_Lyrics_3_17,
                                    Edelweiss_Music_Lyrics_3_18,
																		Edelweiss_Music_Lyrics_3_19,
                                    Edelweiss_Music_Lyrics_3_20,
																		Edelweiss_Music_Lyrics_3_21,
                                    Edelweiss_Music_Lyrics_3_22,
																		Edelweiss_Music_Lyrics_3_23,
                                    Edelweiss_Music_Lyrics_3_24,
																		Edelweiss_Music_Lyrics_3_25,
                                    Edelweiss_Music_Lyrics_3_26,
																		Edelweiss_Music_Lyrics_3_27
                              };
 
																 
//�����ڴ�
/**********************108����***************************/
 uint16_t BmpData_1[36*36+2]__attribute__((at(0xD0400000+0*0xA24)));      //�������� һ������ͼƬռ 0xA24
 uint16_t BmpData_2[36*36+2]__attribute__((at(0xD0400000+1*0xA24)));      
 uint16_t BmpData_3[36*36+2]__attribute__((at(0xD0400000+2*0xA24)));    
 uint16_t BmpData_4[36*36+2]__attribute__((at(0xD0400000+3*0xA24)));     
 uint16_t BmpData_5[36*36+2]__attribute__((at(0xD0400000+4*0xA24)));      
 uint16_t BmpData_6[36*36+2]__attribute__((at(0xD0400000+5*0xA24)));    
 uint16_t BmpData_7[36*36+2]__attribute__((at(0xD0400000+6*0xA24)));                  
 uint16_t BmpData_8[36*36+2]__attribute__((at(0xD0400000+7*0xA24)));     
 uint16_t BmpData_9[36*36+2]__attribute__((at(0xD0400000+8*0xA24)));     
 uint16_t BmpData_10[36*36+2]__attribute__((at(0xD0400000+9*0xA24)));    
 uint16_t BmpData_11[36*36+2]__attribute__((at(0xD0400000+10*0xA24)));     
 uint16_t BmpData_12[36*36+2]__attribute__((at(0xD0400000+11*0xA24)));    
 uint16_t BmpData_13[36*36+2]__attribute__((at(0xD0400000+12*0xA24)));       
 uint16_t BmpData_14[36*36+2]__attribute__((at(0xD0400000+13*0xA24)));     
 uint16_t BmpData_15[36*36+2]__attribute__((at(0xD0400000+14*0xA24)));     
 uint16_t BmpData_16[36*36+2]__attribute__((at(0xD0400000+15*0xA24)));     
 uint16_t BmpData_17[36*36+2]__attribute__((at(0xD0400000+16*0xA24)));   
 uint16_t BmpData_18[36*36+2]__attribute__((at(0xD0400000+17*0xA24)));     
 uint16_t BmpData_19[36*36+2]__attribute__((at(0xD0400000+18*0xA24)));    
 uint16_t BmpData_20[36*36+2]__attribute__((at(0xD0400000+19*0xA24)));    
 uint16_t BmpData_21[36*36+2]__attribute__((at(0xD0400000+20*0xA24)));	
 uint16_t BmpData_22[36*36+2]__attribute__((at(0xD0400000+21*0xA24)));			
 uint16_t BmpData_23[36*36+2]__attribute__((at(0xD0400000+22*0xA24)));    
 uint16_t BmpData_24[36*36+2]__attribute__((at(0xD0400000+23*0xA24)));    
 uint16_t BmpData_25[36*36+2]__attribute__((at(0xD0400000+24*0xA24)));    
 uint16_t BmpData_26[36*36+2]__attribute__((at(0xD0400000+25*0xA24)));   
 uint16_t BmpData_27[36*36+2]__attribute__((at(0xD0400000+26*0xA24)));    
 uint16_t BmpData_28[36*36+2]__attribute__((at(0xD0400000+27*0xA24)));    
 uint16_t BmpData_29[36*36+2]__attribute__((at(0xD0400000+28*0xA24)));     
 uint16_t BmpData_30[36*36+2]__attribute__((at(0xD0400000+29*0xA24)));    
 uint16_t BmpData_31[36*36+2]__attribute__((at(0xD0400000+30*0xA24)));       
 uint16_t BmpData_32[36*36+2]__attribute__((at(0xD0400000+31*0xA24)));     
 uint16_t BmpData_33[36*36+2]__attribute__((at(0xD0400000+32*0xA24)));     
 uint16_t BmpData_34[36*36+2]__attribute__((at(0xD0400000+33*0xA24)));     
 uint16_t BmpData_35[36*36+2]__attribute__((at(0xD0400000+34*0xA24)));    
 uint16_t BmpData_36[36*36+2]__attribute__((at(0xD0400000+35*0xA24)));   
 uint16_t BmpData_37[36*36+2]__attribute__((at(0xD0400000+36*0xA24)));   
 uint16_t BmpData_38[36*36+2]__attribute__((at(0xD0400000+37*0xA24)));   
 uint16_t BmpData_39[36*36+2]__attribute__((at(0xD0400000+38*0xA24)));  
 uint16_t BmpData_40[36*36+2]__attribute__((at(0xD0400000+39*0xA24))); 
 uint16_t BmpData_41[36*36+2]__attribute__((at(0xD0400000+40*0xA24)));   
 uint16_t BmpData_42[36*36+2]__attribute__((at(0xD0400000+41*0xA24)));   
 uint16_t BmpData_43[36*36+2]__attribute__((at(0xD0400000+42*0xA24)));     
 uint16_t BmpData_44[36*36+2]__attribute__((at(0xD0400000+43*0xA24)));  
 uint16_t BmpData_45[36*36+2]__attribute__((at(0xD0400000+44*0xA24)));  
 uint16_t BmpData_46[36*36+2]__attribute__((at(0xD0400000+45*0xA24)));  
 uint16_t BmpData_47[36*36+2]__attribute__((at(0xD0400000+46*0xA24)));  
 uint16_t BmpData_48[36*36+2]__attribute__((at(0xD0400000+47*0xA24)));  
 uint16_t BmpData_49[36*36+2]__attribute__((at(0xD0400000+48*0xA24)));  
 uint16_t BmpData_50[36*36+2]__attribute__((at(0xD0400000+49*0xA24)));   
 uint16_t BmpData_51[36*36+2]__attribute__((at(0xD0400000+50*0xA24)));  
 uint16_t BmpData_52[36*36+2]__attribute__((at(0xD0400000+51*0xA24)));  
 uint16_t BmpData_53[36*36+2]__attribute__((at(0xD0400000+52*0xA24)));   
 uint16_t BmpData_54[36*36+2]__attribute__((at(0xD0400000+53*0xA24)));  
 uint16_t BmpData_55[36*36+2]__attribute__((at(0xD0400000+54*0xA24)));   
 uint16_t BmpData_56[36*36+2]__attribute__((at(0xD0400000+55*0xA24)));  
 uint16_t BmpData_57[36*36+2]__attribute__((at(0xD0400000+56*0xA24)));  
 uint16_t BmpData_58[36*36+2]__attribute__((at(0xD0400000+57*0xA24)));  
 uint16_t BmpData_59[36*36+2]__attribute__((at(0xD0400000+58*0xA24)));  
 uint16_t BmpData_60[36*36+2]__attribute__((at(0xD0400000+59*0xA24)));  
 uint16_t BmpData_61[36*36+2]__attribute__((at(0xD0400000+60*0xA24)));  
 uint16_t BmpData_62[36*36+2]__attribute__((at(0xD0400000+61*0xA24))); 
 uint16_t BmpData_63[36*36+2]__attribute__((at(0xD0400000+62*0xA24)));  
 uint16_t BmpData_64[36*36+2]__attribute__((at(0xD0400000+63*0xA24))); 
 uint16_t BmpData_65[36*36+2]__attribute__((at(0xD0400000+64*0xA24))); 
 uint16_t BmpData_66[36*36+2]__attribute__((at(0xD0400000+65*0xA24)));  
 uint16_t BmpData_67[36*36+2]__attribute__((at(0xD0400000+66*0xA24)));    
 uint16_t BmpData_68[36*36+2]__attribute__((at(0xD0400000+67*0xA24))); 
 uint16_t BmpData_69[36*36+2]__attribute__((at(0xD0400000+68*0xA24)));   
 uint16_t BmpData_70[36*36+2]__attribute__((at(0xD0400000+69*0xA24)));  
 uint16_t BmpData_71[36*36+2]__attribute__((at(0xD0400000+70*0xA24)));   
 uint16_t BmpData_72[36*36+2]__attribute__((at(0xD0400000+71*0xA24)));      
 uint16_t BmpData_73[36*36+2]__attribute__((at(0xD0400000+72*0xA24)));   
 uint16_t BmpData_74[36*36+2]__attribute__((at(0xD0400000+73*0xA24)));  
 uint16_t BmpData_75[36*36+2]__attribute__((at(0xD0400000+74*0xA24)));   
 uint16_t BmpData_76[36*36+2]__attribute__((at(0xD0400000+75*0xA24)));  
 uint16_t BmpData_77[36*36+2]__attribute__((at(0xD0400000+76*0xA24)));  
 uint16_t BmpData_78[36*36+2]__attribute__((at(0xD0400000+77*0xA24)));  
 uint16_t BmpData_79[36*36+2]__attribute__((at(0xD0400000+78*0xA24)));            
 uint16_t BmpData_80[36*36+2]__attribute__((at(0xD0400000+79*0xA24)));    
 uint16_t BmpData_81[36*36+2]__attribute__((at(0xD0400000+80*0xA24))); 
 uint16_t BmpData_82[36*36+2]__attribute__((at(0xD0400000+81*0xA24)));    
 uint16_t BmpData_83[36*36+2]__attribute__((at(0xD0400000+82*0xA24)));  
 uint16_t BmpData_84[36*36+2]__attribute__((at(0xD0400000+83*0xA24)));  
 uint16_t BmpData_85[36*36+2]__attribute__((at(0xD0400000+84*0xA24)));        
 uint16_t BmpData_86[36*36+2]__attribute__((at(0xD0400000+85*0xA24)));   
 uint16_t BmpData_87[36*36+2]__attribute__((at(0xD0400000+86*0xA24)));     
 uint16_t BmpData_88[36*36+2]__attribute__((at(0xD0400000+87*0xA24)));     
 uint16_t BmpData_89[36*36+2]__attribute__((at(0xD0400000+88*0xA24)));     
 uint16_t BmpData_90[36*36+2]__attribute__((at(0xD0400000+89*0xA24)));     
 uint16_t BmpData_91[36*36+2]__attribute__((at(0xD0400000+90*0xA24)));   
 uint16_t BmpData_92[36*36+2]__attribute__((at(0xD0400000+91*0xA24)));    
 uint16_t BmpData_93[36*36+2]__attribute__((at(0xD0400000+92*0xA24)));   
 uint16_t BmpData_94[36*36+2]__attribute__((at(0xD0400000+93*0xA24)));     
 uint16_t BmpData_95[36*36+2]__attribute__((at(0xD0400000+94*0xA24)));     
 uint16_t BmpData_96[36*36+2]__attribute__((at(0xD0400000+95*0xA24)));    
 uint16_t BmpData_97[36*36+2]__attribute__((at(0xD0400000+96*0xA24)));    
 uint16_t BmpData_98[36*36+2]__attribute__((at(0xD0400000+97*0xA24)));    
 uint16_t BmpData_99[36*36+2]__attribute__((at(0xD0400000+98*0xA24)));     
 uint16_t BmpData_100[36*36+2]__attribute__((at(0xD0400000+99*0xA24)));   
 uint16_t BmpData_101[36*36+2]__attribute__((at(0xD0400000+100*0xA24)));  
 uint16_t BmpData_102[36*36+2]__attribute__((at(0xD0400000+101*0xA24)));   
 uint16_t BmpData_103[36*36+2]__attribute__((at(0xD0400000+102*0xA24)));     
 uint16_t BmpData_104[36*36+2]__attribute__((at(0xD0400000+103*0xA24)));   
 uint16_t BmpData_105[36*36+2]__attribute__((at(0xD0400000+104*0xA24)));    
 uint16_t BmpData_106[36*36+2]__attribute__((at(0xD0400000+105*0xA24)));    
 uint16_t BmpData_107[36*36+2]__attribute__((at(0xD0400000+106*0xA24)));   
 uint16_t BmpData_108[36*36+2]__attribute__((at(0xD0400000+107*0xA24)));    
 
/************************ˢ��***************************/
 uint16_t BmpData_06[36*36+2]__attribute__((at(0xD0400000+108*0xA24)));               //ˢ��ͼƬ��С0xA24 
 
/************************����������ָ+��ָ����***************************/
 uint16_t BmpData_L1a[100*110+2]__attribute__((at(0xD0400000+109*0xA24+0*0x55F4)));   //��ָ��С0x55F4
 uint16_t BmpData_L1b[100*110+2]__attribute__((at(0xD0400000+109*0xA24+1*0x55F4)));
 uint16_t BmpData_L2a[100*110+2]__attribute__((at(0xD0400000+109*0xA24+2*0x55F4)));
 uint16_t BmpData_L2b[100*110+2]__attribute__((at(0xD0400000+109*0xA24+3*0x55F4)));
 uint16_t BmpData_L3a[100*110+2]__attribute__((at(0xD0400000+109*0xA24+4*0x55F4)));
 uint16_t BmpData_L3b[100*110+2]__attribute__((at(0xD0400000+109*0xA24+5*0x55F4)));
 uint16_t BmpData_L4a[100*110+2]__attribute__((at(0xD0400000+109*0xA24+6*0x55F4)));
 uint16_t BmpData_L4b[100*110+2]__attribute__((at(0xD0400000+109*0xA24+7*0x55F4)));
 uint16_t BmpData_L5a[100*110+2]__attribute__((at(0xD0400000+109*0xA24+8*0x55F4)));
 uint16_t BmpData_L5b[100*110+2]__attribute__((at(0xD0400000+109*0xA24+9*0x55F4)));
/************************����������ָ+��ָ����***************************/
 uint16_t BmpData_R1a[100*110+2]__attribute__((at(0xD0400000+109*0xA24+10*0x55F4)));  //��ָ��С0x55F4
 uint16_t BmpData_R1b[100*110+2]__attribute__((at(0xD0400000+109*0xA24+11*0x55F4)));
 uint16_t BmpData_R2a[100*110+2]__attribute__((at(0xD0400000+109*0xA24+12*0x55F4)));
 uint16_t BmpData_R2b[100*110+2]__attribute__((at(0xD0400000+109*0xA24+13*0x55F4)));
 uint16_t BmpData_R3a[100*110+2]__attribute__((at(0xD0400000+109*0xA24+14*0x55F4)));
 uint16_t BmpData_R3b[100*110+2]__attribute__((at(0xD0400000+109*0xA24+15*0x55F4)));
 uint16_t BmpData_R4a[100*110+2]__attribute__((at(0xD0400000+109*0xA24+16*0x55F4)));
 uint16_t BmpData_R4b[100*110+2]__attribute__((at(0xD0400000+109*0xA24+17*0x55F4)));
 uint16_t BmpData_R5a[100*110+2]__attribute__((at(0xD0400000+109*0xA24+18*0x55F4)));
 uint16_t BmpData_R5b[100*110+2]__attribute__((at(0xD0400000+109*0xA24+19*0x55F4)));
 /*************************��ָ���¸���ͼ��*****************************/
 uint16_t BmpData_M1[50*50+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+0*0x138C)));   //ʳָͼ���С0x138C
 uint16_t BmpData_M2[50*50+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+1*0x138C)));   //��ָͼ���С0x138C
 uint16_t BmpData_M3[50*50+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+2*0x138C)));   //����ָͼ���С0x138C
 uint16_t BmpData_M4[50*50+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+3*0x138C)));   //βָͼ���С0x138C
 /****************************����������********************************/
 uint16_t BmpData_Lefthand[200*300+2] __attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+0*0x1D4C4)));   //һ��ͼƬ��С0x1D4C4
 uint16_t BmpData_Righthand[200*300+2] __attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+1*0x1D4C4)));	 //һ��ͼƬ��С0x1D4C4

/*************************ͼ��**************************/ 
uint16_t BmpData_Icon[1280*60+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+0*0x25804)));   //ͼ���С0x25804

uint16_t BmpData_ctrl_circulate[96*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+0*0x1EC4)));   //ѭ��ͼ���С0x1EC4
uint16_t BmpData_ctrl_cancle_circulate[96*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+1*0x1EC4))); //ȡ��ѭ��ͼ���С0x1EC4
uint16_t BmpData_breakpointA[41*30+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+0*0x09A0)));   //�ϵ�ͼ���С0x09A0
uint16_t BmpData_breakpointB[41*30+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+1*0x09A0)));   //�ϵ�ͼ���С0x09A0

uint16_t BmpData_ctrl_move[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+0*0xF64)));   //����ͼ���С0xF64
uint16_t BmpData_ctrl_stop[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+1*0xF64)));   //����ͼ���С0xF64  
uint16_t BmpData_ctrl_hand[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+2*0xF64)));   //����ͼ���С0xF64
uint16_t BmpData_ctrl_cancel_hand[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+3*0xF64)));   //ȡ������ͼ���С0xF64
uint16_t BmpData_ctrl_sound[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+4*0xF64)));   //����ͼ���С0xF64
uint16_t BmpData_ctrl_sound1[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+5*0xF64)));   //����ͼ���С0xF64
uint16_t BmpData_ctrl_sound2[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+6*0xF64)));   //����ͼ���С0xF64
uint16_t BmpData_ctrl_sound3[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+7*0xF64)));   //����ͼ���С0xF64
uint16_t BmpData_ctrl_sound4[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+8*0xF64)));   //����ͼ���С0xF64
uint16_t BmpData_ctrl_sound5[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+9*0xF64)));   //����ͼ���С0xF64

uint16_t BmpData_quick1[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+10*0xF64)));   //���ͼ���С0xF64
uint16_t BmpData_quick2[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+11*0xF64)));   //���ͼ���С0xF64
uint16_t BmpData_quick3[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+12*0xF64)));   //���ͼ���С0xF64
uint16_t BmpData_quick4[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+13*0xF64)));  //���ͼ���С0xF64
uint16_t BmpData_quick5[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+14*0xF64)));  //���ͼ���С0xF64
uint16_t BmpData_quick6[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+15*0xF64)));  //���ͼ���С0xF64
uint16_t BmpData_quick7[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+16*0xF64)));  //���ͼ���С0xF64

uint16_t BmpData_slow1[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+17*0xF64)));   //����ͼ���С0xF64
uint16_t BmpData_slow2[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+18*0xF64)));   //����ͼ���С0xF64
uint16_t BmpData_slow3[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+19*0xF64)));   //����ͼ���С0xF64
uint16_t BmpData_slow4[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+20*0xF64)));   //����ͼ���С0xF64
uint16_t BmpData_slow5[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+21*0xF64)));   //����ͼ���С0xF64
uint16_t BmpData_slow6[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+22*0xF64)));   //����ͼ���С0xF64
uint16_t BmpData_slow7[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+23*0xF64)));   //����ͼ���С0xF64
uint16_t BmpData_normal[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+24*0xF64)));   //����ͼ���С0xF64

uint16_t BmpData_ci[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+25*0xF64)));   //��ͼ���С0xF64
uint16_t BmpData_qu[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+26*0xF64)));   //��ͼ���С0xF64
uint16_t BmpData_zhi[48*41+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+27*0xF64)));   //��ͼ���С0xF64

/************************����***************************/
uint16_t BmpData_ropper[480*30+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+28*0xF64+1*0x8CA4+0*0x7084)));  //�����С0x7084

/*************************************����ʱ*******************************************/
uint16_t BmpData_count_down_number0[30*30+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+28*0xF64+1*0x8CA4+1*0x7084+0*0x70C)));	//����ʱͼƬ ��С0x70C
uint16_t BmpData_count_down_number1[30*30+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+28*0xF64+1*0x8CA4+1*0x7084+1*0x70C)));	//����ʱͼƬ ��С0x70C
uint16_t BmpData_count_down_number2[30*30+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+28*0xF64+1*0x8CA4+1*0x7084+2*0x70C)));	//����ʱͼƬ ��С0x70C
uint16_t BmpData_count_down_number3[30*30+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+28*0xF64+1*0x8CA4+1*0x7084+3*0x70C)));	//����ʱͼƬ ��С0x70C
uint16_t BmpData_count_down_number4[30*30+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+28*0xF64+1*0x8CA4+1*0x7084+4*0x70C)));	//����ʱͼƬ ��С0x70C
uint16_t BmpData_count_down_number5[30*30+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+28*0xF64+1*0x8CA4+1*0x7084+5*0x70C)));	//����ʱͼƬ ��С0x70C
uint16_t BmpData_count_down_number6[30*30+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+28*0xF64+1*0x8CA4+1*0x7084+6*0x70C)));	//����ʱͼƬ ��С0x70C
uint16_t BmpData_count_down_number7[30*30+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+28*0xF64+1*0x8CA4+1*0x7084+7*0x70C)));	//����ʱͼƬ ��С0x70C
uint16_t BmpData_count_down_number8[30*30+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+28*0xF64+1*0x8CA4+1*0x7084+8*0x70C)));	//����ʱͼƬ ��С0x70C
uint16_t BmpData_count_down_number9[30*30+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+28*0xF64+1*0x8CA4+1*0x7084+9*0x70C)));	//����ʱͼƬ ��С0x70C
uint16_t BmpData_count_down_numberz[30*30+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+28*0xF64+1*0x8CA4+1*0x7084+10*0x70C)));//����ʱͼƬ ��С0x70C
uint16_t BmpData_count_down_numberM[30*30+2]__attribute__((at(0xD0400000+109*0xA24+20*0x55F4+4*0x138C+2*0x1D4C4+1*0x25804+2*0x1EC4+2*0x09A0+28*0xF64+1*0x8CA4+1*0x7084+11*0x70C)));//����ʱͼƬ ��С0x70C

/************************����***************************/
yuepu13 BmpData_pu1[50]__attribute__((at(0xD05F0000+45*0x3004+1*0x25804+0*0xD5DEC8)));               //�����ϰ벿�ִ�С0xD5DEC8
yuepu2  BmpData_pu2[50]__attribute__((at(0xD05F0000+45*0x3004+1*0x25804+1*0xD5DEC8+0*0x2904C8)));     //�����м��С0x2904C8
yuepu13 BmpData_pu3[50]__attribute__((at(0xD05F0000+45*0x3004+1*0x25804+1*0xD5DEC8+1*0x2904C8)));     //�����°벿�ִ�С0xD5DEC8

///*************************������**************************///
uint16_t BmpData_song_name[1280*60+2]__attribute__((at(0xD05F0000+45*0x3004+1*0x25804+2*0xD5DEC8+1*0x2904C8+0*0x25804)));   //ͼ���С0x25804


void Get_BMP_Proc(void)
{	
/*********************��ȡ����ͼ******************/
	
    /**********************��ȡ������******************************/
	  Get_BMP_565_16(song_name_bar,BmpData_song_name);	

		/*******************���ص�һ������*****************************/
	  static int loading_page;
																
    for(loading_page=0;loading_page<2;loading_page++)
    {
         Get_BMP_565_16(Music_Score_1[loading_page],BmpData_pu1[loading_page].BmpData_P);
         Get_BMP_565_16(Music_Score_2[loading_page],BmpData_pu2[loading_page].BmpData_P);
    }	
	
		if(Lyrics_Song_Switch_Flag == 0)
		{
		     Get_BMP_Proc_For_Ci();
			   Ci_First_Page_Loading_done = 1;
         Ci_Loading_done = 0;
		}		
//    else if(Lyrics_Song_Switch_Flag == 1)
//    {
//         Get_BMP_Proc_For_Qu();	
//			   Qu_First_Page_Loading_done = 1;
//			   Qu_Loading_done = 0;
//		}			
	
/********************������������********************/
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Left_Hand/����ָ��.bmp",BmpData_Lefthand);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Left_Hand/����1-p1.bmp",BmpData_L1a);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Left_Hand/����2-p1.bmp",BmpData_L2a);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Left_Hand/����3-p1.bmp",BmpData_L3a);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Left_Hand/����4-p1.bmp",BmpData_L4a);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Left_Hand/����5-p1.bmp",BmpData_L5a);
/********************������������********************/
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Right_Hand/����ָ��.bmp",BmpData_Righthand);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Right_Hand/����1-p1.bmp",BmpData_R1a);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Right_Hand/����2-p1.bmp",BmpData_R2a);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Right_Hand/����3-p1.bmp",BmpData_R3a);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Right_Hand/����4-p1.bmp",BmpData_R4a);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Right_Hand/����5-p1.bmp",BmpData_R5a);
/**********************��ȡͼ��******************************/
  	Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/control.bmp",BmpData_Icon);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/��.bmp",BmpData_ci);
//	  Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/��.bmp",BmpData_qu);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/ָ.bmp",BmpData_zhi);
}


void Get_BMP_Proc1(void)
{
/**********************************��ȡͼ��***************************************************/
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/��ʼ.bmp",BmpData_ctrl_move);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/��ͣ.bmp",BmpData_ctrl_stop);	  
	
/*****************************��ȡ����ʱͼƬ**************************************************/
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Count_Down/Z.bmp",BmpData_count_down_numberz);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Count_Down/9.bmp",BmpData_count_down_number9);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Count_Down/8.bmp",BmpData_count_down_number8);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Count_Down/7.bmp",BmpData_count_down_number7);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Count_Down/6.bmp",BmpData_count_down_number6);				
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Count_Down/5.bmp",BmpData_count_down_number5);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Count_Down/4.bmp",BmpData_count_down_number4);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Count_Down/3.bmp",BmpData_count_down_number3);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Count_Down/2.bmp",BmpData_count_down_number2);
    Get_BMP_565_16("0:/STM32/Landscape_Mode/Count_Down/1.bmp",BmpData_count_down_number1);
    Get_BMP_565_16("0:/STM32/Landscape_Mode/Count_Down/0.bmp",BmpData_count_down_number0);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Count_Down/M.bmp",BmpData_count_down_numberM);	
	
	  Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/��ʾ��ָ.bmp",BmpData_ctrl_hand);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/����ʾ��ָ.bmp",BmpData_ctrl_cancel_hand);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/������.bmp",BmpData_ctrl_sound);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/��������.bmp",BmpData_ctrl_sound1);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/�ر�������.bmp",BmpData_ctrl_sound2);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/������.bmp",BmpData_ctrl_sound3);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/��������.bmp",BmpData_ctrl_sound4);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/�ر�������.bmp",BmpData_ctrl_sound5);
		
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/ѭ��.bmp",BmpData_ctrl_circulate);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/ȡ��ѭ��.bmp",BmpData_ctrl_cancle_circulate);	
		
	  Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/1dian1.bmp",BmpData_quick1);    //���
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/1dian2.bmp",BmpData_quick2);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/1dian3.bmp",BmpData_quick3);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/1dian5.bmp",BmpData_quick4);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/2dian0.bmp",BmpData_quick5);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/4dian0.bmp",BmpData_quick6);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/8dian0.bmp",BmpData_quick7);
		
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/0dian9.bmp",BmpData_slow1);     //����
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/0dian8.bmp",BmpData_slow2);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/0dian7.bmp",BmpData_slow3);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/0dian5.bmp",BmpData_slow4);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/0dian3.bmp",BmpData_slow5);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/0dian2.bmp",BmpData_slow6);
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/0dian1.bmp",BmpData_slow7);
		
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/1dian0.bmp",BmpData_normal);
		
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/A.bmp",BmpData_breakpointA);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Key_Ctrl/B.bmp",BmpData_breakpointB);
/*****************************��ȡ���µ�������ָ����******************************************/
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Left_Hand/����1-p2.bmp",BmpData_L1b);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Left_Hand/����2-p2.bmp",BmpData_L2b);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Left_Hand/����3-p2.bmp",BmpData_L3b);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Left_Hand/����4-p2.bmp",BmpData_L4b);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Left_Hand/����5-p2.bmp",BmpData_L5b);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Right_Hand/����1-p2.bmp",BmpData_R1b);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Right_Hand/����2-p2.bmp",BmpData_R2b);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Right_Hand/����3-p2.bmp",BmpData_R3b);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Right_Hand/����4-p2.bmp",BmpData_R4b);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Right_Hand/����5-p2.bmp",BmpData_R5b);
///********************************��ȡ����ͼ��*************************************************/
//    Get_BMP_565_16("0:/STM32/Landscape_Mode/mask layer/ʳָ����.bmp",BmpData_M1);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/mask layer/��ָ����.bmp",BmpData_M2);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/mask layer/����ָ����.bmp",BmpData_M3);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/mask layer/Сָ����.bmp",BmpData_M4);
///******************************��ȡ����**********************************/
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/1.bmp",BmpData_1);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/2.bmp",BmpData_2);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/3.bmp",BmpData_3);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/4.bmp",BmpData_4);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/5.bmp",BmpData_5);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/6.bmp",BmpData_6);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/7.bmp",BmpData_7);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/8.bmp",BmpData_8);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/9.bmp",BmpData_9);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/10.bmp",BmpData_10);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/11.bmp",BmpData_11);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/12.bmp",BmpData_12);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/13.bmp",BmpData_13);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/14.bmp",BmpData_14);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/15.bmp",BmpData_15);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/16.bmp",BmpData_16);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/17.bmp",BmpData_17);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/18.bmp",BmpData_18);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/19.bmp",BmpData_19);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/20.bmp",BmpData_20);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/21.bmp",BmpData_21);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/22.bmp",BmpData_22);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/23.bmp",BmpData_23);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/24.bmp",BmpData_24);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/25.bmp",BmpData_25);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/26.bmp",BmpData_26);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/27.bmp",BmpData_27);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/28.bmp",BmpData_28);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/29.bmp",BmpData_29);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/30.bmp",BmpData_30);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/31.bmp",BmpData_31);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/32.bmp",BmpData_32);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/33.bmp",BmpData_33);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/34.bmp",BmpData_34);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/35.bmp",BmpData_35);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/36.bmp",BmpData_36);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/37.bmp",BmpData_37);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/38.bmp",BmpData_38);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/39.bmp",BmpData_39);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/40.bmp",BmpData_40);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/41.bmp",BmpData_41);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/42.bmp",BmpData_42);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/43.bmp",BmpData_43);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/44.bmp",BmpData_44);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/45.bmp",BmpData_45);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/46.bmp",BmpData_46);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/47.bmp",BmpData_47);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/48.bmp",BmpData_48);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/49.bmp",BmpData_49);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/50.bmp",BmpData_50);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/51.bmp",BmpData_51);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/52.bmp",BmpData_52);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/53.bmp",BmpData_53);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/54.bmp",BmpData_54);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/55.bmp",BmpData_55);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/56.bmp",BmpData_56);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/57.bmp",BmpData_57);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/58.bmp",BmpData_58);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/59.bmp",BmpData_59);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/60.bmp",BmpData_60);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/61.bmp",BmpData_61);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/62.bmp",BmpData_62);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/63.bmp",BmpData_63);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/64.bmp",BmpData_64);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/65.bmp",BmpData_65);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/66.bmp",BmpData_66);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/67.bmp",BmpData_67);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/68.bmp",BmpData_68);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/69.bmp",BmpData_69);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/70.bmp",BmpData_70);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/71.bmp",BmpData_71);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/72.bmp",BmpData_72);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/73.bmp",BmpData_73);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/74.bmp",BmpData_74);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/75.bmp",BmpData_75);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/76.bmp",BmpData_76);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/77.bmp",BmpData_77);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/78.bmp",BmpData_78);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/79.bmp",BmpData_79);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/80.bmp",BmpData_80);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/81.bmp",BmpData_81);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/82.bmp",BmpData_82);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/83.bmp",BmpData_83);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/84.bmp",BmpData_84);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/85.bmp",BmpData_85);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/86.bmp",BmpData_86);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/87.bmp",BmpData_87);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/88.bmp",BmpData_88);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/89.bmp",BmpData_89);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/90.bmp",BmpData_90);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/91.bmp",BmpData_91);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/92.bmp",BmpData_92);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/93.bmp",BmpData_93);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/94.bmp",BmpData_94);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/95.bmp",BmpData_95);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/96.bmp",BmpData_96);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/97.bmp",BmpData_97);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/98.bmp",BmpData_98);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/99.bmp",BmpData_99);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/100.bmp",BmpData_100);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/101.bmp",BmpData_101);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/102.bmp",BmpData_102);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/103.bmp",BmpData_103);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/104.bmp",BmpData_104);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/105.bmp",BmpData_105);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/106.bmp",BmpData_106);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/107.bmp",BmpData_107);
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/108.bmp",BmpData_108);	
///*********************************��ȡ�������ͼƬ******************************************/		
//		Get_BMP_565_16("0:/STM32/Landscape_Mode/Notes/6x36.bmp",BmpData_06);
/*******************************����*************************************/
		Get_BMP_565_16("0:/STM32/Landscape_Mode/Scroll/scroll.bmp",BmpData_ropper);	
}


void Get_BMP_Proc_For_Qu(void)
{
/*************************************����1����*************************************************/
		Get_BMP_565_16(Music_Score_3[0],BmpData_pu3[0].BmpData_P);	

/*************************************����2����*************************************************/
		Get_BMP_565_16(Music_Score_3[1],BmpData_pu3[1].BmpData_P);
}


void Get_BMP_Proc_For_Ci(void)
{
/*************************************����1����*************************************************/
		Get_BMP_565_16(Music_Lyrics_3[0],BmpData_pu3[0].BmpData_P);	
	
/*************************************����2����*************************************************/
		Get_BMP_565_16(Music_Lyrics_3[1],BmpData_pu3[1].BmpData_P);
}


void Get_BMP_Proc2()    //����ʣ��ҳ
{
//		if(Lyrics_Song_Switch_Flag == 0 && Ci_First_Page_Loading_done == 0)
//		{
//		     Get_BMP_Proc_For_Ci();
//				 Show_Fingure_For_Ci_or_Qu();
//			   Ci_First_Page_Loading_done = 1;
//         Ci_Loading_done = 0;
//		}		
//    else if(Lyrics_Song_Switch_Flag == 1 && Qu_First_Page_Loading_done == 0)
//    {
//         Get_BMP_Proc_For_Qu();	
//				 Show_Fingure_For_Ci_or_Qu();
//			   Qu_First_Page_Loading_done = 1;
//			   Qu_Loading_done = 0;
//		}			
		
		static int ci_page;
//		static int qu_page;	
		
    /**********************��ʼ״̬(Ĭ�ϸ����)***************************/																
//    for(ci_page=2;ci_page<song_total_page && Lyrics_Song_Switch_Flag == 0 && Allow_Switch_Ci_or_Qu_Flag == 0 && Ci_Loading_done == 0;ci_page++)
//    {
		for(ci_page=2;ci_page<song_total_page && Lyrics_Song_Switch_Flag == 0 && Ci_Loading_done == 0;ci_page++)
    {
         Get_BMP_565_16(Music_Score_1[ci_page],BmpData_pu1[ci_page].BmpData_P);
         Get_BMP_565_16(Music_Score_2[ci_page],BmpData_pu2[ci_page].BmpData_P);
         Get_BMP_565_16(Music_Lyrics_3[ci_page],BmpData_pu3[ci_page].BmpData_P);
    }
		
		/**********************������״̬************************************/														
//    for(qu_page=2;qu_page<song_total_page && Lyrics_Song_Switch_Flag== 1 && Allow_Switch_Ci_or_Qu_Flag == 0 && Qu_Loading_done == 0;qu_page++)
//    {
//         Get_BMP_565_16(Music_Score_1[qu_page],BmpData_pu1[qu_page].BmpData_P);
//         Get_BMP_565_16(Music_Score_2[qu_page],BmpData_pu2[qu_page].BmpData_P);
//         Get_BMP_565_16(Music_Score_3[qu_page],BmpData_pu3[qu_page].BmpData_P);
//    }
	
    if(ci_page==song_total_page) 
		{	
			Ci_Loading_done = 1;
      printf("** ����׻������ ** \r\n");	
    }
		
//		if(qu_page==song_total_page) 
//		{	
//			Qu_Loading_done = 1;
//      printf("** �����׻������ ** \r\n");	
//    }
}

/************************���������� ��ʾ �ָ� �Ӻ���***************************/
/**
  * @brief  ����������ʾ����
  * @param  LSN ��ָ
	* @param  x_event ����
  */
void  L_Show_Note(uint16_t LSN,uint16_t x_event)
{
	uint16_t x=80-20,y=290-64;
	uint16_t m,n;
	if(LSN==1)       //βָ������ʾ
	{
		m=107;
		n=42;
		if(x_event==1) move_Image_Asm_565(x+m,y+n,36,36,BmpData_1);
		if(x_event==2) move_Image_Asm_565(x+m,y+n,36,36,BmpData_2);
		if(x_event==3) move_Image_Asm_565(x+m,y+n,36,36,BmpData_3);
		if(x_event==4) move_Image_Asm_565(x+m,y+n,36,36,BmpData_4);
		if(x_event==5) move_Image_Asm_565(x+m,y+n,36,36,BmpData_5);
		if(x_event==6) move_Image_Asm_565(x+m,y+n,36,36,BmpData_6);
		if(x_event==7) move_Image_Asm_565(x+m,y+n,36,36,BmpData_7);
		if(x_event==8) move_Image_Asm_565(x+m,y+n,36,36,BmpData_8);
		if(x_event==9) move_Image_Asm_565(x+m,y+n,36,36,BmpData_9);
		if(x_event==10) move_Image_Asm_565(x+m,y+n,36,36,BmpData_10);
		if(x_event==11) move_Image_Asm_565(x+m,y+n,36,36,BmpData_11);
		if(x_event==12) move_Image_Asm_565(x+m,y+n,36,36,BmpData_12);
		if(x_event==13) move_Image_Asm_565(x+m,y+n,36,36,BmpData_13);
		if(x_event==14) move_Image_Asm_565(x+m,y+n,36,36,BmpData_14);
		if(x_event==15) move_Image_Asm_565(x+m,y+n,36,36,BmpData_15);
		if(x_event==16) move_Image_Asm_565(x+m,y+n,36,36,BmpData_16);
		if(x_event==17) move_Image_Asm_565(x+m,y+n,36,36,BmpData_17);
		if(x_event==18) move_Image_Asm_565(x+m,y+n,36,36,BmpData_18);
		if(x_event==19) move_Image_Asm_565(x+m,y+n,36,36,BmpData_19);
		if(x_event==20) move_Image_Asm_565(x+m,y+n,36,36,BmpData_20);
		if(x_event==21) move_Image_Asm_565(x+m,y+n,36,36,BmpData_21);
		if(x_event==22) move_Image_Asm_565(x+m,y+n,36,36,BmpData_22);
		if(x_event==23) move_Image_Asm_565(x+m,y+n,36,36,BmpData_23);
		if(x_event==24) move_Image_Asm_565(x+m,y+n,36,36,BmpData_24);
		if(x_event==25) move_Image_Asm_565(x+m,y+n,36,36,BmpData_25);
		if(x_event==26) move_Image_Asm_565(x+m,y+n,36,36,BmpData_26);
		if(x_event==27) move_Image_Asm_565(x+m,y+n,36,36,BmpData_27);
		if(x_event==28) move_Image_Asm_565(x+m,y+n,36,36,BmpData_28);
		if(x_event==29) move_Image_Asm_565(x+m,y+n,36,36,BmpData_29);
		if(x_event==30) move_Image_Asm_565(x+m,y+n,36,36,BmpData_30);
		if(x_event==31) move_Image_Asm_565(x+m,y+n,36,36,BmpData_31);
		if(x_event==32) move_Image_Asm_565(x+m,y+n,36,36,BmpData_32);
		if(x_event==33) move_Image_Asm_565(x+m,y+n,36,36,BmpData_33);
		if(x_event==34) move_Image_Asm_565(x+m,y+n,36,36,BmpData_34);
		if(x_event==35) move_Image_Asm_565(x+m,y+n,36,36,BmpData_35);
		if(x_event==36) move_Image_Asm_565(x+m,y+n,36,36,BmpData_36);
		if(x_event==37) move_Image_Asm_565(x+m,y+n,36,36,BmpData_37);
		if(x_event==38) move_Image_Asm_565(x+m,y+n,36,36,BmpData_38);
		if(x_event==39) move_Image_Asm_565(x+m,y+n,36,36,BmpData_39);
		if(x_event==40) move_Image_Asm_565(x+m,y+n,36,36,BmpData_40);
		if(x_event==41) move_Image_Asm_565(x+m,y+n,36,36,BmpData_41);
		if(x_event==42) move_Image_Asm_565(x+m,y+n,36,36,BmpData_42);
		if(x_event==43) move_Image_Asm_565(x+m,y+n,36,36,BmpData_43);
		if(x_event==44) move_Image_Asm_565(x+m,y+n,36,36,BmpData_44);
		if(x_event==45) move_Image_Asm_565(x+m,y+n,36,36,BmpData_45);
		if(x_event==46) move_Image_Asm_565(x+m,y+n,36,36,BmpData_46);
		if(x_event==47) move_Image_Asm_565(x+m,y+n,36,36,BmpData_47);
		if(x_event==48) move_Image_Asm_565(x+m,y+n,36,36,BmpData_48);
		if(x_event==49) move_Image_Asm_565(x+m,y+n,36,36,BmpData_49);
		if(x_event==50) move_Image_Asm_565(x+m,y+n,36,36,BmpData_50);
		if(x_event==51) move_Image_Asm_565(x+m,y+n,36,36,BmpData_51);
		if(x_event==52) move_Image_Asm_565(x+m,y+n,36,36,BmpData_52);
		if(x_event==53) move_Image_Asm_565(x+m,y+n,36,36,BmpData_53);
		if(x_event==54) move_Image_Asm_565(x+m,y+n,36,36,BmpData_54);
		if(x_event==55) move_Image_Asm_565(x+m,y+n,36,36,BmpData_55);
		if(x_event==56) move_Image_Asm_565(x+m,y+n,36,36,BmpData_56);
		if(x_event==57) move_Image_Asm_565(x+m,y+n,36,36,BmpData_57);
		if(x_event==58) move_Image_Asm_565(x+m,y+n,36,36,BmpData_58);
		if(x_event==59) move_Image_Asm_565(x+m,y+n,36,36,BmpData_59);
		if(x_event==60) move_Image_Asm_565(x+m,y+n,36,36,BmpData_60);
		if(x_event==61) move_Image_Asm_565(x+m,y+n,36,36,BmpData_61);
		if(x_event==62) move_Image_Asm_565(x+m,y+n,36,36,BmpData_62);
		if(x_event==63) move_Image_Asm_565(x+m,y+n,36,36,BmpData_63);
		if(x_event==64) move_Image_Asm_565(x+m,y+n,36,36,BmpData_64);
		if(x_event==65) move_Image_Asm_565(x+m,y+n,36,36,BmpData_65);
		if(x_event==66) move_Image_Asm_565(x+m,y+n,36,36,BmpData_66);
		if(x_event==67) move_Image_Asm_565(x+m,y+n,36,36,BmpData_67);
		if(x_event==68) move_Image_Asm_565(x+m,y+n,36,36,BmpData_68);
		if(x_event==69) move_Image_Asm_565(x+m,y+n,36,36,BmpData_69);
		if(x_event==70) move_Image_Asm_565(x+m,y+n,36,36,BmpData_70);
		if(x_event==71) move_Image_Asm_565(x+m,y+n,36,36,BmpData_71);
		if(x_event==72) move_Image_Asm_565(x+m,y+n,36,36,BmpData_72);
		if(x_event==73) move_Image_Asm_565(x+m,y+n,36,36,BmpData_73);
		if(x_event==74) move_Image_Asm_565(x+m,y+n,36,36,BmpData_74);
		if(x_event==75) move_Image_Asm_565(x+m,y+n,36,36,BmpData_75);
		if(x_event==76) move_Image_Asm_565(x+m,y+n,36,36,BmpData_76);
		if(x_event==77) move_Image_Asm_565(x+m,y+n,36,36,BmpData_77);
		if(x_event==78) move_Image_Asm_565(x+m,y+n,36,36,BmpData_78);
		if(x_event==79) move_Image_Asm_565(x+m,y+n,36,36,BmpData_79);
		if(x_event==80) move_Image_Asm_565(x+m,y+n,36,36,BmpData_80);
		if(x_event==81) move_Image_Asm_565(x+m,y+n,36,36,BmpData_81);
		if(x_event==82) move_Image_Asm_565(x+m,y+n,36,36,BmpData_82);
		if(x_event==83) move_Image_Asm_565(x+m,y+n,36,36,BmpData_83);
		if(x_event==84) move_Image_Asm_565(x+m,y+n,36,36,BmpData_84);
		if(x_event==85) move_Image_Asm_565(x+m,y+n,36,36,BmpData_85);
		if(x_event==86) move_Image_Asm_565(x+m,y+n,36,36,BmpData_86);
		if(x_event==87) move_Image_Asm_565(x+m,y+n,36,36,BmpData_87);
		if(x_event==88) move_Image_Asm_565(x+m,y+n,36,36,BmpData_88);
		if(x_event==89) move_Image_Asm_565(x+m,y+n,36,36,BmpData_89);
		if(x_event==90) move_Image_Asm_565(x+m,y+n,36,36,BmpData_90);
		if(x_event==91) move_Image_Asm_565(x+m,y+n,36,36,BmpData_91);
		if(x_event==92) move_Image_Asm_565(x+m,y+n,36,36,BmpData_92);
		if(x_event==93) move_Image_Asm_565(x+m,y+n,36,36,BmpData_93);
		if(x_event==94) move_Image_Asm_565(x+m,y+n,36,36,BmpData_94);
		if(x_event==95) move_Image_Asm_565(x+m,y+n,36,36,BmpData_95);
		if(x_event==96) move_Image_Asm_565(x+m,y+n,36,36,BmpData_96);
		if(x_event==97) move_Image_Asm_565(x+m,y+n,36,36,BmpData_97);
		if(x_event==98) move_Image_Asm_565(x+m,y+n,36,36,BmpData_98);
		if(x_event==99) move_Image_Asm_565(x+m,y+n,36,36,BmpData_99);
		if(x_event==100) move_Image_Asm_565(x+m,y+n,36,36,BmpData_100);
		if(x_event==101) move_Image_Asm_565(x+m,y+n,36,36,BmpData_101);
		if(x_event==102) move_Image_Asm_565(x+m,y+n,36,36,BmpData_102);
		if(x_event==103) move_Image_Asm_565(x+m,y+n,36,36,BmpData_103);
		if(x_event==104) move_Image_Asm_565(x+m,y+n,36,36,BmpData_104);
		if(x_event==105) move_Image_Asm_565(x+m,y+n,36,36,BmpData_105);
		if(x_event==106) move_Image_Asm_565(x+m,y+n,36,36,BmpData_106);
		if(x_event==107) move_Image_Asm_565(x+m,y+n,36,36,BmpData_107);
		if(x_event==108) 	move_Image_Asm_565(x+m,y+n,36,36,BmpData_36);
	}
	if(LSN==2)     //����ָ������ʾ
	{
		m=129;
		n=88;
		if(x_event==1) move_Image_Asm_565(x+m,y+n,36,36,BmpData_1);
		if(x_event==2) move_Image_Asm_565(x+m,y+n,36,36,BmpData_2);
		if(x_event==3) move_Image_Asm_565(x+m,y+n,36,36,BmpData_3);
		if(x_event==4) move_Image_Asm_565(x+m,y+n,36,36,BmpData_4);
		if(x_event==5) move_Image_Asm_565(x+m,y+n,36,36,BmpData_5);
		if(x_event==6) move_Image_Asm_565(x+m,y+n,36,36,BmpData_6);
		if(x_event==7) move_Image_Asm_565(x+m,y+n,36,36,BmpData_7);
		if(x_event==8) move_Image_Asm_565(x+m,y+n,36,36,BmpData_8);
		if(x_event==9) move_Image_Asm_565(x+m,y+n,36,36,BmpData_9);
		if(x_event==10) move_Image_Asm_565(x+m,y+n,36,36,BmpData_10);
		if(x_event==11) move_Image_Asm_565(x+m,y+n,36,36,BmpData_11);
		if(x_event==12) move_Image_Asm_565(x+m,y+n,36,36,BmpData_12);
		if(x_event==13) move_Image_Asm_565(x+m,y+n,36,36,BmpData_13);
		if(x_event==14) move_Image_Asm_565(x+m,y+n,36,36,BmpData_14);
		if(x_event==15) move_Image_Asm_565(x+m,y+n,36,36,BmpData_15);
		if(x_event==16) move_Image_Asm_565(x+m,y+n,36,36,BmpData_16);
		if(x_event==17) move_Image_Asm_565(x+m,y+n,36,36,BmpData_17);
		if(x_event==18) move_Image_Asm_565(x+m,y+n,36,36,BmpData_18);
		if(x_event==19) move_Image_Asm_565(x+m,y+n,36,36,BmpData_19);
		if(x_event==20) move_Image_Asm_565(x+m,y+n,36,36,BmpData_20);
		if(x_event==21) move_Image_Asm_565(x+m,y+n,36,36,BmpData_21);
		if(x_event==22) move_Image_Asm_565(x+m,y+n,36,36,BmpData_22);
		if(x_event==23) move_Image_Asm_565(x+m,y+n,36,36,BmpData_23);
		if(x_event==24) move_Image_Asm_565(x+m,y+n,36,36,BmpData_24);
		if(x_event==25) move_Image_Asm_565(x+m,y+n,36,36,BmpData_25);
		if(x_event==26) move_Image_Asm_565(x+m,y+n,36,36,BmpData_26);
		if(x_event==27) move_Image_Asm_565(x+m,y+n,36,36,BmpData_27);
		if(x_event==28) move_Image_Asm_565(x+m,y+n,36,36,BmpData_28);
		if(x_event==29) move_Image_Asm_565(x+m,y+n,36,36,BmpData_29);
		if(x_event==30) move_Image_Asm_565(x+m,y+n,36,36,BmpData_30);
		if(x_event==31) move_Image_Asm_565(x+m,y+n,36,36,BmpData_31);
		if(x_event==32) move_Image_Asm_565(x+m,y+n,36,36,BmpData_32);
		if(x_event==33) move_Image_Asm_565(x+m,y+n,36,36,BmpData_33);
		if(x_event==34) move_Image_Asm_565(x+m,y+n,36,36,BmpData_34);
		if(x_event==35) move_Image_Asm_565(x+m,y+n,36,36,BmpData_35);
		if(x_event==36) move_Image_Asm_565(x+m,y+n,36,36,BmpData_36);
		if(x_event==37) move_Image_Asm_565(x+m,y+n,36,36,BmpData_37);
		if(x_event==38) move_Image_Asm_565(x+m,y+n,36,36,BmpData_38);
		if(x_event==39) move_Image_Asm_565(x+m,y+n,36,36,BmpData_39);
		if(x_event==40) move_Image_Asm_565(x+m,y+n,36,36,BmpData_40);
		if(x_event==41) move_Image_Asm_565(x+m,y+n,36,36,BmpData_41);
		if(x_event==42) move_Image_Asm_565(x+m,y+n,36,36,BmpData_42);
		if(x_event==43) move_Image_Asm_565(x+m,y+n,36,36,BmpData_43);
		if(x_event==44) move_Image_Asm_565(x+m,y+n,36,36,BmpData_44);
		if(x_event==45) move_Image_Asm_565(x+m,y+n,36,36,BmpData_45);
		if(x_event==46) move_Image_Asm_565(x+m,y+n,36,36,BmpData_46);
		if(x_event==47) move_Image_Asm_565(x+m,y+n,36,36,BmpData_47);
		if(x_event==48) move_Image_Asm_565(x+m,y+n,36,36,BmpData_48);
		if(x_event==49) move_Image_Asm_565(x+m,y+n,36,36,BmpData_49);
		if(x_event==50) move_Image_Asm_565(x+m,y+n,36,36,BmpData_50);
		if(x_event==51) move_Image_Asm_565(x+m,y+n,36,36,BmpData_51);
		if(x_event==52) move_Image_Asm_565(x+m,y+n,36,36,BmpData_52);
		if(x_event==53) move_Image_Asm_565(x+m,y+n,36,36,BmpData_53);
		if(x_event==54) move_Image_Asm_565(x+m,y+n,36,36,BmpData_54);
		if(x_event==55) move_Image_Asm_565(x+m,y+n,36,36,BmpData_55);
		if(x_event==56) move_Image_Asm_565(x+m,y+n,36,36,BmpData_56);
		if(x_event==57) move_Image_Asm_565(x+m,y+n,36,36,BmpData_57);
		if(x_event==58) move_Image_Asm_565(x+m,y+n,36,36,BmpData_58);
		if(x_event==59) move_Image_Asm_565(x+m,y+n,36,36,BmpData_59);
		if(x_event==60) move_Image_Asm_565(x+m,y+n,36,36,BmpData_60);
		if(x_event==61) move_Image_Asm_565(x+m,y+n,36,36,BmpData_61);
		if(x_event==62) move_Image_Asm_565(x+m,y+n,36,36,BmpData_62);
		if(x_event==63) move_Image_Asm_565(x+m,y+n,36,36,BmpData_63);
		if(x_event==64) move_Image_Asm_565(x+m,y+n,36,36,BmpData_64);
		if(x_event==65) move_Image_Asm_565(x+m,y+n,36,36,BmpData_65);
		if(x_event==66) move_Image_Asm_565(x+m,y+n,36,36,BmpData_66);
		if(x_event==67) move_Image_Asm_565(x+m,y+n,36,36,BmpData_67);
		if(x_event==68) move_Image_Asm_565(x+m,y+n,36,36,BmpData_68);
		if(x_event==69) move_Image_Asm_565(x+m,y+n,36,36,BmpData_69);
		if(x_event==70) move_Image_Asm_565(x+m,y+n,36,36,BmpData_70);
		if(x_event==71) move_Image_Asm_565(x+m,y+n,36,36,BmpData_71);
		if(x_event==72) move_Image_Asm_565(x+m,y+n,36,36,BmpData_72);
		if(x_event==73) move_Image_Asm_565(x+m,y+n,36,36,BmpData_73);
		if(x_event==74) move_Image_Asm_565(x+m,y+n,36,36,BmpData_74);
		if(x_event==75) move_Image_Asm_565(x+m,y+n,36,36,BmpData_75);
		if(x_event==76) move_Image_Asm_565(x+m,y+n,36,36,BmpData_76);
		if(x_event==77) move_Image_Asm_565(x+m,y+n,36,36,BmpData_77);
		if(x_event==78) move_Image_Asm_565(x+m,y+n,36,36,BmpData_78);
		if(x_event==79) move_Image_Asm_565(x+m,y+n,36,36,BmpData_79);
		if(x_event==80) move_Image_Asm_565(x+m,y+n,36,36,BmpData_80);
		if(x_event==81) move_Image_Asm_565(x+m,y+n,36,36,BmpData_81);
		if(x_event==82) move_Image_Asm_565(x+m,y+n,36,36,BmpData_82);
		if(x_event==83) move_Image_Asm_565(x+m,y+n,36,36,BmpData_83);
		if(x_event==84) move_Image_Asm_565(x+m,y+n,36,36,BmpData_84);
		if(x_event==85) move_Image_Asm_565(x+m,y+n,36,36,BmpData_85);
		if(x_event==86) move_Image_Asm_565(x+m,y+n,36,36,BmpData_86);
		if(x_event==87) move_Image_Asm_565(x+m,y+n,36,36,BmpData_87);
		if(x_event==88) move_Image_Asm_565(x+m,y+n,36,36,BmpData_88);
		if(x_event==89) move_Image_Asm_565(x+m,y+n,36,36,BmpData_89);
		if(x_event==90) move_Image_Asm_565(x+m,y+n,36,36,BmpData_90);
		if(x_event==91) move_Image_Asm_565(x+m,y+n,36,36,BmpData_91);
		if(x_event==92) move_Image_Asm_565(x+m,y+n,36,36,BmpData_92);
		if(x_event==93) move_Image_Asm_565(x+m,y+n,36,36,BmpData_93);
		if(x_event==94) move_Image_Asm_565(x+m,y+n,36,36,BmpData_94);
		if(x_event==95) move_Image_Asm_565(x+m,y+n,36,36,BmpData_95);
		if(x_event==96) move_Image_Asm_565(x+m,y+n,36,36,BmpData_96);
		if(x_event==97) move_Image_Asm_565(x+m,y+n,36,36,BmpData_97);
		if(x_event==98) move_Image_Asm_565(x+m,y+n,36,36,BmpData_98);
		if(x_event==99) move_Image_Asm_565(x+m,y+n,36,36,BmpData_99);
		if(x_event==100) move_Image_Asm_565(x+m,y+n,36,36,BmpData_100);
		if(x_event==101) move_Image_Asm_565(x+m,y+n,36,36,BmpData_101);
		if(x_event==102) move_Image_Asm_565(x+m,y+n,36,36,BmpData_102);
		if(x_event==103) move_Image_Asm_565(x+m,y+n,36,36,BmpData_103);
		if(x_event==104) move_Image_Asm_565(x+m,y+n,36,36,BmpData_104);
		if(x_event==105) move_Image_Asm_565(x+m,y+n,36,36,BmpData_105);
		if(x_event==106) move_Image_Asm_565(x+m,y+n,36,36,BmpData_106);
		if(x_event==107) move_Image_Asm_565(x+m,y+n,36,36,BmpData_107);
		if(x_event==108) move_Image_Asm_565(x+m,y+n,36,36,BmpData_108);
	}
	if(LSN==3)    //��ָ������ʾ
	{
		m=147;
		n=130;
		if(x_event==1) move_Image_Asm_565(x+m,y+n,36,36,BmpData_1);
		if(x_event==2) move_Image_Asm_565(x+m,y+n,36,36,BmpData_2);
		if(x_event==3) move_Image_Asm_565(x+m,y+n,36,36,BmpData_3);
		if(x_event==4) move_Image_Asm_565(x+m,y+n,36,36,BmpData_4);
		if(x_event==5) move_Image_Asm_565(x+m,y+n,36,36,BmpData_5);
		if(x_event==6) move_Image_Asm_565(x+m,y+n,36,36,BmpData_6);
		if(x_event==7) move_Image_Asm_565(x+m,y+n,36,36,BmpData_7);
		if(x_event==8) move_Image_Asm_565(x+m,y+n,36,36,BmpData_8);
		if(x_event==9) move_Image_Asm_565(x+m,y+n,36,36,BmpData_9);
		if(x_event==10) move_Image_Asm_565(x+m,y+n,36,36,BmpData_10);
		if(x_event==11) move_Image_Asm_565(x+m,y+n,36,36,BmpData_11);
		if(x_event==12) move_Image_Asm_565(x+m,y+n,36,36,BmpData_12);
		if(x_event==13) move_Image_Asm_565(x+m,y+n,36,36,BmpData_13);
		if(x_event==14) move_Image_Asm_565(x+m,y+n,36,36,BmpData_14);
		if(x_event==15) move_Image_Asm_565(x+m,y+n,36,36,BmpData_15);
		if(x_event==16) move_Image_Asm_565(x+m,y+n,36,36,BmpData_16);
		if(x_event==17) move_Image_Asm_565(x+m,y+n,36,36,BmpData_17);
		if(x_event==18) move_Image_Asm_565(x+m,y+n,36,36,BmpData_18);
		if(x_event==19) move_Image_Asm_565(x+m,y+n,36,36,BmpData_19);
		if(x_event==20) move_Image_Asm_565(x+m,y+n,36,36,BmpData_20);
		if(x_event==21) move_Image_Asm_565(x+m,y+n,36,36,BmpData_21);
		if(x_event==22) move_Image_Asm_565(x+m,y+n,36,36,BmpData_22);
		if(x_event==23) move_Image_Asm_565(x+m,y+n,36,36,BmpData_23);
		if(x_event==24) move_Image_Asm_565(x+m,y+n,36,36,BmpData_24);
		if(x_event==25) move_Image_Asm_565(x+m,y+n,36,36,BmpData_25);
		if(x_event==26) move_Image_Asm_565(x+m,y+n,36,36,BmpData_26);
		if(x_event==27) move_Image_Asm_565(x+m,y+n,36,36,BmpData_27);
		if(x_event==28) move_Image_Asm_565(x+m,y+n,36,36,BmpData_28);
		if(x_event==29) move_Image_Asm_565(x+m,y+n,36,36,BmpData_29);
		if(x_event==30) move_Image_Asm_565(x+m,y+n,36,36,BmpData_30);
		if(x_event==31) move_Image_Asm_565(x+m,y+n,36,36,BmpData_31);
		if(x_event==32) move_Image_Asm_565(x+m,y+n,36,36,BmpData_32);
		if(x_event==33) move_Image_Asm_565(x+m,y+n,36,36,BmpData_33);
		if(x_event==34) move_Image_Asm_565(x+m,y+n,36,36,BmpData_34);
		if(x_event==35) move_Image_Asm_565(x+m,y+n,36,36,BmpData_35);
		if(x_event==36) move_Image_Asm_565(x+m,y+n,36,36,BmpData_36);
		if(x_event==37) move_Image_Asm_565(x+m,y+n,36,36,BmpData_37);
		if(x_event==38) move_Image_Asm_565(x+m,y+n,36,36,BmpData_38);
		if(x_event==39) move_Image_Asm_565(x+m,y+n,36,36,BmpData_39);
		if(x_event==40) move_Image_Asm_565(x+m,y+n,36,36,BmpData_40);
		if(x_event==41) move_Image_Asm_565(x+m,y+n,36,36,BmpData_41);
		if(x_event==42) move_Image_Asm_565(x+m,y+n,36,36,BmpData_42);
		if(x_event==43) move_Image_Asm_565(x+m,y+n,36,36,BmpData_43);
		if(x_event==44) move_Image_Asm_565(x+m,y+n,36,36,BmpData_44);
		if(x_event==45) move_Image_Asm_565(x+m,y+n,36,36,BmpData_45);
		if(x_event==46) move_Image_Asm_565(x+m,y+n,36,36,BmpData_46);
		if(x_event==47) move_Image_Asm_565(x+m,y+n,36,36,BmpData_47);
		if(x_event==48) move_Image_Asm_565(x+m,y+n,36,36,BmpData_48);
		if(x_event==49) move_Image_Asm_565(x+m,y+n,36,36,BmpData_49);
		if(x_event==50) move_Image_Asm_565(x+m,y+n,36,36,BmpData_50);
		if(x_event==51) move_Image_Asm_565(x+m,y+n,36,36,BmpData_51);
		if(x_event==52) move_Image_Asm_565(x+m,y+n,36,36,BmpData_52);
		if(x_event==53) move_Image_Asm_565(x+m,y+n,36,36,BmpData_53);
		if(x_event==54) move_Image_Asm_565(x+m,y+n,36,36,BmpData_54);
		if(x_event==55) move_Image_Asm_565(x+m,y+n,36,36,BmpData_55);
		if(x_event==56) move_Image_Asm_565(x+m,y+n,36,36,BmpData_56);
		if(x_event==57) move_Image_Asm_565(x+m,y+n,36,36,BmpData_57);
		if(x_event==58) move_Image_Asm_565(x+m,y+n,36,36,BmpData_58);
		if(x_event==59) move_Image_Asm_565(x+m,y+n,36,36,BmpData_59);
		if(x_event==60) move_Image_Asm_565(x+m,y+n,36,36,BmpData_60);
		if(x_event==61) move_Image_Asm_565(x+m,y+n,36,36,BmpData_61);
		if(x_event==62) move_Image_Asm_565(x+m,y+n,36,36,BmpData_62);
		if(x_event==63) move_Image_Asm_565(x+m,y+n,36,36,BmpData_63);
		if(x_event==64) move_Image_Asm_565(x+m,y+n,36,36,BmpData_64);
		if(x_event==65) move_Image_Asm_565(x+m,y+n,36,36,BmpData_65);
		if(x_event==66) move_Image_Asm_565(x+m,y+n,36,36,BmpData_66);
		if(x_event==67) move_Image_Asm_565(x+m,y+n,36,36,BmpData_67);
		if(x_event==68) move_Image_Asm_565(x+m,y+n,36,36,BmpData_68);
		if(x_event==69) move_Image_Asm_565(x+m,y+n,36,36,BmpData_69);
		if(x_event==70) move_Image_Asm_565(x+m,y+n,36,36,BmpData_70);
		if(x_event==71) move_Image_Asm_565(x+m,y+n,36,36,BmpData_71);
		if(x_event==72) move_Image_Asm_565(x+m,y+n,36,36,BmpData_72);
		if(x_event==73) move_Image_Asm_565(x+m,y+n,36,36,BmpData_73);
		if(x_event==74) move_Image_Asm_565(x+m,y+n,36,36,BmpData_74);
		if(x_event==75) move_Image_Asm_565(x+m,y+n,36,36,BmpData_75);
		if(x_event==76) move_Image_Asm_565(x+m,y+n,36,36,BmpData_76);
		if(x_event==77) move_Image_Asm_565(x+m,y+n,36,36,BmpData_77);
		if(x_event==78) move_Image_Asm_565(x+m,y+n,36,36,BmpData_78);
		if(x_event==79) move_Image_Asm_565(x+m,y+n,36,36,BmpData_79);
		if(x_event==80) move_Image_Asm_565(x+m,y+n,36,36,BmpData_80);
		if(x_event==81) move_Image_Asm_565(x+m,y+n,36,36,BmpData_81);
		if(x_event==82) move_Image_Asm_565(x+m,y+n,36,36,BmpData_82);
		if(x_event==83) move_Image_Asm_565(x+m,y+n,36,36,BmpData_83);
		if(x_event==84) move_Image_Asm_565(x+m,y+n,36,36,BmpData_84);
		if(x_event==85) move_Image_Asm_565(x+m,y+n,36,36,BmpData_85);
		if(x_event==86) move_Image_Asm_565(x+m,y+n,36,36,BmpData_86);
		if(x_event==87) move_Image_Asm_565(x+m,y+n,36,36,BmpData_87);
		if(x_event==88) move_Image_Asm_565(x+m,y+n,36,36,BmpData_88);
		if(x_event==89) move_Image_Asm_565(x+m,y+n,36,36,BmpData_89);
		if(x_event==90) move_Image_Asm_565(x+m,y+n,36,36,BmpData_90);
		if(x_event==91) move_Image_Asm_565(x+m,y+n,36,36,BmpData_91);
		if(x_event==92) move_Image_Asm_565(x+m,y+n,36,36,BmpData_92);
		if(x_event==93) move_Image_Asm_565(x+m,y+n,36,36,BmpData_93);
		if(x_event==94) move_Image_Asm_565(x+m,y+n,36,36,BmpData_94);
		if(x_event==95) move_Image_Asm_565(x+m,y+n,36,36,BmpData_95);
		if(x_event==96) move_Image_Asm_565(x+m,y+n,36,36,BmpData_96);
		if(x_event==97) move_Image_Asm_565(x+m,y+n,36,36,BmpData_97);
		if(x_event==98) move_Image_Asm_565(x+m,y+n,36,36,BmpData_98);
		if(x_event==99) move_Image_Asm_565(x+m,y+n,36,36,BmpData_99);
		if(x_event==100) move_Image_Asm_565(x+m,y+n,36,36,BmpData_100);
		if(x_event==101) move_Image_Asm_565(x+m,y+n,36,36,BmpData_101);
		if(x_event==102) move_Image_Asm_565(x+m,y+n,36,36,BmpData_102);
		if(x_event==103) move_Image_Asm_565(x+m,y+n,36,36,BmpData_103);
		if(x_event==104) move_Image_Asm_565(x+m,y+n,36,36,BmpData_104);
		if(x_event==105) move_Image_Asm_565(x+m,y+n,36,36,BmpData_105);
		if(x_event==106) move_Image_Asm_565(x+m,y+n,36,36,BmpData_106);
		if(x_event==107) move_Image_Asm_565(x+m,y+n,36,36,BmpData_107);
		if(x_event==108) move_Image_Asm_565(x+m,y+n,36,36,BmpData_108);
	}
	if(LSN==4)     //ʳָ������ʾ
	{
		m=131;
		n=179;
		if(x_event==1) move_Image_Asm_565(x+m,y+n,36,36,BmpData_1);
		if(x_event==2) move_Image_Asm_565(x+m,y+n,36,36,BmpData_2);
		if(x_event==3) move_Image_Asm_565(x+m,y+n,36,36,BmpData_3);
		if(x_event==4) move_Image_Asm_565(x+m,y+n,36,36,BmpData_4);
		if(x_event==5) move_Image_Asm_565(x+m,y+n,36,36,BmpData_5);
		if(x_event==6) move_Image_Asm_565(x+m,y+n,36,36,BmpData_6);
		if(x_event==7) move_Image_Asm_565(x+m,y+n,36,36,BmpData_7);
		if(x_event==8) move_Image_Asm_565(x+m,y+n,36,36,BmpData_8);
		if(x_event==9) move_Image_Asm_565(x+m,y+n,36,36,BmpData_9);
		if(x_event==10) move_Image_Asm_565(x+m,y+n,36,36,BmpData_10);
		if(x_event==11) move_Image_Asm_565(x+m,y+n,36,36,BmpData_11);
		if(x_event==12) move_Image_Asm_565(x+m,y+n,36,36,BmpData_12);
		if(x_event==13) move_Image_Asm_565(x+m,y+n,36,36,BmpData_13);
		if(x_event==14) move_Image_Asm_565(x+m,y+n,36,36,BmpData_14);
		if(x_event==15) move_Image_Asm_565(x+m,y+n,36,36,BmpData_15);
		if(x_event==16) move_Image_Asm_565(x+m,y+n,36,36,BmpData_16);
		if(x_event==17) move_Image_Asm_565(x+m,y+n,36,36,BmpData_17);
		if(x_event==18) move_Image_Asm_565(x+m,y+n,36,36,BmpData_18);
		if(x_event==19) move_Image_Asm_565(x+m,y+n,36,36,BmpData_19);
		if(x_event==20) move_Image_Asm_565(x+m,y+n,36,36,BmpData_20);
		if(x_event==21) move_Image_Asm_565(x+m,y+n,36,36,BmpData_21);
		if(x_event==22) move_Image_Asm_565(x+m,y+n,36,36,BmpData_22);
		if(x_event==23) move_Image_Asm_565(x+m,y+n,36,36,BmpData_23);
		if(x_event==24) move_Image_Asm_565(x+m,y+n,36,36,BmpData_24);
		if(x_event==25) move_Image_Asm_565(x+m,y+n,36,36,BmpData_25);
		if(x_event==26) move_Image_Asm_565(x+m,y+n,36,36,BmpData_26);
		if(x_event==27) move_Image_Asm_565(x+m,y+n,36,36,BmpData_27);
		if(x_event==28) move_Image_Asm_565(x+m,y+n,36,36,BmpData_28);
		if(x_event==29) move_Image_Asm_565(x+m,y+n,36,36,BmpData_29);
		if(x_event==30) move_Image_Asm_565(x+m,y+n,36,36,BmpData_30);
		if(x_event==31) move_Image_Asm_565(x+m,y+n,36,36,BmpData_31);
		if(x_event==32) move_Image_Asm_565(x+m,y+n,36,36,BmpData_32);
		if(x_event==33) move_Image_Asm_565(x+m,y+n,36,36,BmpData_33);
		if(x_event==34) move_Image_Asm_565(x+m,y+n,36,36,BmpData_34);
		if(x_event==35) move_Image_Asm_565(x+m,y+n,36,36,BmpData_35);
		if(x_event==36) move_Image_Asm_565(x+m,y+n,36,36,BmpData_36);
		if(x_event==37) move_Image_Asm_565(x+m,y+n,36,36,BmpData_37);
		if(x_event==38) move_Image_Asm_565(x+m,y+n,36,36,BmpData_38);
		if(x_event==39) move_Image_Asm_565(x+m,y+n,36,36,BmpData_39);
		if(x_event==40) move_Image_Asm_565(x+m,y+n,36,36,BmpData_40);
		if(x_event==41) move_Image_Asm_565(x+m,y+n,36,36,BmpData_41);
		if(x_event==42) move_Image_Asm_565(x+m,y+n,36,36,BmpData_42);
		if(x_event==43) move_Image_Asm_565(x+m,y+n,36,36,BmpData_43);
		if(x_event==44) move_Image_Asm_565(x+m,y+n,36,36,BmpData_44);
		if(x_event==45) move_Image_Asm_565(x+m,y+n,36,36,BmpData_45);
		if(x_event==46) move_Image_Asm_565(x+m,y+n,36,36,BmpData_46);
		if(x_event==47) move_Image_Asm_565(x+m,y+n,36,36,BmpData_47);
		if(x_event==48) move_Image_Asm_565(x+m,y+n,36,36,BmpData_48);
		if(x_event==49) move_Image_Asm_565(x+m,y+n,36,36,BmpData_49);
		if(x_event==50) move_Image_Asm_565(x+m,y+n,36,36,BmpData_50);
		if(x_event==51) move_Image_Asm_565(x+m,y+n,36,36,BmpData_51);
		if(x_event==52) move_Image_Asm_565(x+m,y+n,36,36,BmpData_52);
		if(x_event==53) move_Image_Asm_565(x+m,y+n,36,36,BmpData_53);
		if(x_event==54) move_Image_Asm_565(x+m,y+n,36,36,BmpData_54);
		if(x_event==55) move_Image_Asm_565(x+m,y+n,36,36,BmpData_55);
		if(x_event==56) move_Image_Asm_565(x+m,y+n,36,36,BmpData_56);
		if(x_event==57) move_Image_Asm_565(x+m,y+n,36,36,BmpData_57);
		if(x_event==58) move_Image_Asm_565(x+m,y+n,36,36,BmpData_58);
		if(x_event==59) move_Image_Asm_565(x+m,y+n,36,36,BmpData_59);
		if(x_event==60) move_Image_Asm_565(x+m,y+n,36,36,BmpData_60);
		if(x_event==61) move_Image_Asm_565(x+m,y+n,36,36,BmpData_61);
		if(x_event==62) move_Image_Asm_565(x+m,y+n,36,36,BmpData_62);
		if(x_event==63) move_Image_Asm_565(x+m,y+n,36,36,BmpData_63);
		if(x_event==64) move_Image_Asm_565(x+m,y+n,36,36,BmpData_64);
		if(x_event==65) move_Image_Asm_565(x+m,y+n,36,36,BmpData_65);
		if(x_event==66) move_Image_Asm_565(x+m,y+n,36,36,BmpData_66);
		if(x_event==67) move_Image_Asm_565(x+m,y+n,36,36,BmpData_67);
		if(x_event==68) move_Image_Asm_565(x+m,y+n,36,36,BmpData_68);
		if(x_event==69) move_Image_Asm_565(x+m,y+n,36,36,BmpData_69);
		if(x_event==70) move_Image_Asm_565(x+m,y+n,36,36,BmpData_70);
		if(x_event==71) move_Image_Asm_565(x+m,y+n,36,36,BmpData_71);
		if(x_event==72) move_Image_Asm_565(x+m,y+n,36,36,BmpData_72);
		if(x_event==73) move_Image_Asm_565(x+m,y+n,36,36,BmpData_73);
		if(x_event==74) move_Image_Asm_565(x+m,y+n,36,36,BmpData_74);
		if(x_event==75) move_Image_Asm_565(x+m,y+n,36,36,BmpData_75);
		if(x_event==76) move_Image_Asm_565(x+m,y+n,36,36,BmpData_76);
		if(x_event==77) move_Image_Asm_565(x+m,y+n,36,36,BmpData_77);
		if(x_event==78) move_Image_Asm_565(x+m,y+n,36,36,BmpData_78);
		if(x_event==79) move_Image_Asm_565(x+m,y+n,36,36,BmpData_79);
		if(x_event==80) move_Image_Asm_565(x+m,y+n,36,36,BmpData_80);
		if(x_event==81) move_Image_Asm_565(x+m,y+n,36,36,BmpData_81);
		if(x_event==82) move_Image_Asm_565(x+m,y+n,36,36,BmpData_82);
		if(x_event==83) move_Image_Asm_565(x+m,y+n,36,36,BmpData_83);
		if(x_event==84) move_Image_Asm_565(x+m,y+n,36,36,BmpData_84);
		if(x_event==85) move_Image_Asm_565(x+m,y+n,36,36,BmpData_85);
		if(x_event==86) move_Image_Asm_565(x+m,y+n,36,36,BmpData_86);
		if(x_event==87) move_Image_Asm_565(x+m,y+n,36,36,BmpData_87);
		if(x_event==88) move_Image_Asm_565(x+m,y+n,36,36,BmpData_88);
		if(x_event==89) move_Image_Asm_565(x+m,y+n,36,36,BmpData_89);
		if(x_event==90) move_Image_Asm_565(x+m,y+n,36,36,BmpData_90);
		if(x_event==91) move_Image_Asm_565(x+m,y+n,36,36,BmpData_91);
		if(x_event==92) move_Image_Asm_565(x+m,y+n,36,36,BmpData_92);
		if(x_event==93) move_Image_Asm_565(x+m,y+n,36,36,BmpData_93);
		if(x_event==94) move_Image_Asm_565(x+m,y+n,36,36,BmpData_94);
		if(x_event==95) move_Image_Asm_565(x+m,y+n,36,36,BmpData_95);
		if(x_event==96) move_Image_Asm_565(x+m,y+n,36,36,BmpData_96);
		if(x_event==97) move_Image_Asm_565(x+m,y+n,36,36,BmpData_97);
		if(x_event==98) move_Image_Asm_565(x+m,y+n,36,36,BmpData_98);
		if(x_event==99) move_Image_Asm_565(x+m,y+n,36,36,BmpData_99);
		if(x_event==100) move_Image_Asm_565(x+m,y+n,36,36,BmpData_100);
		if(x_event==101) move_Image_Asm_565(x+m,y+n,36,36,BmpData_101);
		if(x_event==102) move_Image_Asm_565(x+m,y+n,36,36,BmpData_102);
		if(x_event==103) move_Image_Asm_565(x+m,y+n,36,36,BmpData_103);
		if(x_event==104) move_Image_Asm_565(x+m,y+n,36,36,BmpData_104);
		if(x_event==105) move_Image_Asm_565(x+m,y+n,36,36,BmpData_105);
		if(x_event==106) move_Image_Asm_565(x+m,y+n,36,36,BmpData_106);
		if(x_event==107) move_Image_Asm_565(x+m,y+n,36,36,BmpData_107);
		if(x_event==108) move_Image_Asm_565(x+m,y+n,36,36,BmpData_108);
	}
	if(LSN==5)    //Ĵָ������ʾ
	{
		m=67;
		n=225;
		if(x_event==1) move_Image_Asm_565(x+m,y+n,36,36,BmpData_1);
		if(x_event==2) move_Image_Asm_565(x+m,y+n,36,36,BmpData_2);
		if(x_event==3) move_Image_Asm_565(x+m,y+n,36,36,BmpData_3);
		if(x_event==4) move_Image_Asm_565(x+m,y+n,36,36,BmpData_4);
		if(x_event==5) move_Image_Asm_565(x+m,y+n,36,36,BmpData_5);
		if(x_event==6) move_Image_Asm_565(x+m,y+n,36,36,BmpData_6);
		if(x_event==7) move_Image_Asm_565(x+m,y+n,36,36,BmpData_7);
		if(x_event==8) move_Image_Asm_565(x+m,y+n,36,36,BmpData_8);
		if(x_event==9) move_Image_Asm_565(x+m,y+n,36,36,BmpData_9);
		if(x_event==10) move_Image_Asm_565(x+m,y+n,36,36,BmpData_10);
		if(x_event==11) move_Image_Asm_565(x+m,y+n,36,36,BmpData_11);
		if(x_event==12) move_Image_Asm_565(x+m,y+n,36,36,BmpData_12);
		if(x_event==13) move_Image_Asm_565(x+m,y+n,36,36,BmpData_13);
		if(x_event==14) move_Image_Asm_565(x+m,y+n,36,36,BmpData_14);
		if(x_event==15) move_Image_Asm_565(x+m,y+n,36,36,BmpData_15);
		if(x_event==16) move_Image_Asm_565(x+m,y+n,36,36,BmpData_16);
		if(x_event==17) move_Image_Asm_565(x+m,y+n,36,36,BmpData_17);
		if(x_event==18) move_Image_Asm_565(x+m,y+n,36,36,BmpData_18);
		if(x_event==19) move_Image_Asm_565(x+m,y+n,36,36,BmpData_19);
		if(x_event==20) move_Image_Asm_565(x+m,y+n,36,36,BmpData_20);
		if(x_event==21) move_Image_Asm_565(x+m,y+n,36,36,BmpData_21);
		if(x_event==22) move_Image_Asm_565(x+m,y+n,36,36,BmpData_22);
		if(x_event==23) move_Image_Asm_565(x+m,y+n,36,36,BmpData_23);
		if(x_event==24) move_Image_Asm_565(x+m,y+n,36,36,BmpData_24);
		if(x_event==25) move_Image_Asm_565(x+m,y+n,36,36,BmpData_25);
		if(x_event==26) move_Image_Asm_565(x+m,y+n,36,36,BmpData_26);
		if(x_event==27) move_Image_Asm_565(x+m,y+n,36,36,BmpData_27);
		if(x_event==28) move_Image_Asm_565(x+m,y+n,36,36,BmpData_28);
		if(x_event==29) move_Image_Asm_565(x+m,y+n,36,36,BmpData_29);
		if(x_event==30) move_Image_Asm_565(x+m,y+n,36,36,BmpData_30);
		if(x_event==31) move_Image_Asm_565(x+m,y+n,36,36,BmpData_31);
		if(x_event==32) move_Image_Asm_565(x+m,y+n,36,36,BmpData_32);
		if(x_event==33) move_Image_Asm_565(x+m,y+n,36,36,BmpData_33);
		if(x_event==34) move_Image_Asm_565(x+m,y+n,36,36,BmpData_34);
		if(x_event==35) move_Image_Asm_565(x+m,y+n,36,36,BmpData_35);
		if(x_event==36) move_Image_Asm_565(x+m,y+n,36,36,BmpData_36);
		if(x_event==37) move_Image_Asm_565(x+m,y+n,36,36,BmpData_37);
		if(x_event==38) move_Image_Asm_565(x+m,y+n,36,36,BmpData_38);
		if(x_event==39) move_Image_Asm_565(x+m,y+n,36,36,BmpData_39);
		if(x_event==40) move_Image_Asm_565(x+m,y+n,36,36,BmpData_40);
		if(x_event==41) move_Image_Asm_565(x+m,y+n,36,36,BmpData_41);
		if(x_event==42) move_Image_Asm_565(x+m,y+n,36,36,BmpData_42);
		if(x_event==43) move_Image_Asm_565(x+m,y+n,36,36,BmpData_43);
		if(x_event==44) move_Image_Asm_565(x+m,y+n,36,36,BmpData_44);
		if(x_event==45) move_Image_Asm_565(x+m,y+n,36,36,BmpData_45);
		if(x_event==46) move_Image_Asm_565(x+m,y+n,36,36,BmpData_46);
		if(x_event==47) move_Image_Asm_565(x+m,y+n,36,36,BmpData_47);
		if(x_event==48) move_Image_Asm_565(x+m,y+n,36,36,BmpData_48);
		if(x_event==49) move_Image_Asm_565(x+m,y+n,36,36,BmpData_49);
		if(x_event==50) move_Image_Asm_565(x+m,y+n,36,36,BmpData_50);
		if(x_event==51) move_Image_Asm_565(x+m,y+n,36,36,BmpData_51);
		if(x_event==52) move_Image_Asm_565(x+m,y+n,36,36,BmpData_52);
		if(x_event==53) move_Image_Asm_565(x+m,y+n,36,36,BmpData_53);
		if(x_event==54) move_Image_Asm_565(x+m,y+n,36,36,BmpData_54);
		if(x_event==55) move_Image_Asm_565(x+m,y+n,36,36,BmpData_55);
		if(x_event==56) move_Image_Asm_565(x+m,y+n,36,36,BmpData_56);
		if(x_event==57) move_Image_Asm_565(x+m,y+n,36,36,BmpData_57);
		if(x_event==58) move_Image_Asm_565(x+m,y+n,36,36,BmpData_58);
		if(x_event==59) move_Image_Asm_565(x+m,y+n,36,36,BmpData_59);
		if(x_event==60) move_Image_Asm_565(x+m,y+n,36,36,BmpData_60);
		if(x_event==61) move_Image_Asm_565(x+m,y+n,36,36,BmpData_61);
		if(x_event==62) move_Image_Asm_565(x+m,y+n,36,36,BmpData_62);
		if(x_event==63) move_Image_Asm_565(x+m,y+n,36,36,BmpData_63);
		if(x_event==64) move_Image_Asm_565(x+m,y+n,36,36,BmpData_64);
		if(x_event==65) move_Image_Asm_565(x+m,y+n,36,36,BmpData_65);
		if(x_event==66) move_Image_Asm_565(x+m,y+n,36,36,BmpData_66);
		if(x_event==67) move_Image_Asm_565(x+m,y+n,36,36,BmpData_67);
		if(x_event==68) move_Image_Asm_565(x+m,y+n,36,36,BmpData_68);
		if(x_event==69) move_Image_Asm_565(x+m,y+n,36,36,BmpData_69);
		if(x_event==70) move_Image_Asm_565(x+m,y+n,36,36,BmpData_70);
		if(x_event==71) move_Image_Asm_565(x+m,y+n,36,36,BmpData_71);
		if(x_event==72) move_Image_Asm_565(x+m,y+n,36,36,BmpData_72);
		if(x_event==73) move_Image_Asm_565(x+m,y+n,36,36,BmpData_73);
		if(x_event==74) move_Image_Asm_565(x+m,y+n,36,36,BmpData_74);
		if(x_event==75) move_Image_Asm_565(x+m,y+n,36,36,BmpData_75);
		if(x_event==76) move_Image_Asm_565(x+m,y+n,36,36,BmpData_76);
		if(x_event==77) move_Image_Asm_565(x+m,y+n,36,36,BmpData_77);
		if(x_event==78) move_Image_Asm_565(x+m,y+n,36,36,BmpData_78);
		if(x_event==79) move_Image_Asm_565(x+m,y+n,36,36,BmpData_79);
		if(x_event==80) move_Image_Asm_565(x+m,y+n,36,36,BmpData_80);
		if(x_event==81) move_Image_Asm_565(x+m,y+n,36,36,BmpData_81);
		if(x_event==82) move_Image_Asm_565(x+m,y+n,36,36,BmpData_82);
		if(x_event==83) move_Image_Asm_565(x+m,y+n,36,36,BmpData_83);
		if(x_event==84) move_Image_Asm_565(x+m,y+n,36,36,BmpData_84);
		if(x_event==85) move_Image_Asm_565(x+m,y+n,36,36,BmpData_85);
		if(x_event==86) move_Image_Asm_565(x+m,y+n,36,36,BmpData_86);
		if(x_event==87) move_Image_Asm_565(x+m,y+n,36,36,BmpData_87);
		if(x_event==88) move_Image_Asm_565(x+m,y+n,36,36,BmpData_88);
		if(x_event==89) move_Image_Asm_565(x+m,y+n,36,36,BmpData_89);
		if(x_event==90) move_Image_Asm_565(x+m,y+n,36,36,BmpData_90);
		if(x_event==91) move_Image_Asm_565(x+m,y+n,36,36,BmpData_91);
		if(x_event==92) move_Image_Asm_565(x+m,y+n,36,36,BmpData_92);
		if(x_event==93) move_Image_Asm_565(x+m,y+n,36,36,BmpData_93);
		if(x_event==94) move_Image_Asm_565(x+m,y+n,36,36,BmpData_94);
		if(x_event==95) move_Image_Asm_565(x+m,y+n,36,36,BmpData_95);
		if(x_event==96) move_Image_Asm_565(x+m,y+n,36,36,BmpData_96);
		if(x_event==97) move_Image_Asm_565(x+m,y+n,36,36,BmpData_97);
		if(x_event==98) move_Image_Asm_565(x+m,y+n,36,36,BmpData_98);
		if(x_event==99) move_Image_Asm_565(x+m,y+n,36,36,BmpData_99);
		if(x_event==100) move_Image_Asm_565(x+m,y+n,36,36,BmpData_100);
		if(x_event==101) move_Image_Asm_565(x+m,y+n,36,36,BmpData_101);
		if(x_event==102) move_Image_Asm_565(x+m,y+n,36,36,BmpData_102);
		if(x_event==103) move_Image_Asm_565(x+m,y+n,36,36,BmpData_103);
		if(x_event==104) move_Image_Asm_565(x+m,y+n,36,36,BmpData_104);
		if(x_event==105) move_Image_Asm_565(x+m,y+n,36,36,BmpData_105);
		if(x_event==106) move_Image_Asm_565(x+m,y+n,36,36,BmpData_106);
		if(x_event==107) move_Image_Asm_565(x+m,y+n,36,36,BmpData_107);
		if(x_event==108) move_Image_Asm_565(x+m,y+n,36,36,BmpData_108);
		}
  }


/**
  * @brief  ����������ʾ����
  * @param  RSN ��ָ
	* @param  x_event ����
  * @retval ��
  */
void  R_Show_Note(uint16_t RSN,uint16_t x_event)
{
	uint16_t x=80-20,y=690+62;
	uint16_t m,n;
	if(RSN==1)      //Ĵָ������ʾ
	{
		m=67;
		n=46;
		if(x_event==1) move_Image_Asm_565(x+m,y+n,36,36,BmpData_1);
		if(x_event==2) move_Image_Asm_565(x+m,y+n,36,36,BmpData_2);
		if(x_event==3) move_Image_Asm_565(x+m,y+n,36,36,BmpData_3);
		if(x_event==4) move_Image_Asm_565(x+m,y+n,36,36,BmpData_4);
		if(x_event==5) move_Image_Asm_565(x+m,y+n,36,36,BmpData_5);
		if(x_event==6) move_Image_Asm_565(x+m,y+n,36,36,BmpData_6);
		if(x_event==7) move_Image_Asm_565(x+m,y+n,36,36,BmpData_7);
		if(x_event==8) move_Image_Asm_565(x+m,y+n,36,36,BmpData_8);
		if(x_event==9) move_Image_Asm_565(x+m,y+n,36,36,BmpData_9);
		if(x_event==10) move_Image_Asm_565(x+m,y+n,36,36,BmpData_10);
		if(x_event==11) move_Image_Asm_565(x+m,y+n,36,36,BmpData_11);
		if(x_event==12) move_Image_Asm_565(x+m,y+n,36,36,BmpData_12);
		if(x_event==13) move_Image_Asm_565(x+m,y+n,36,36,BmpData_13);
		if(x_event==14) move_Image_Asm_565(x+m,y+n,36,36,BmpData_14);
		if(x_event==15) move_Image_Asm_565(x+m,y+n,36,36,BmpData_15);
		if(x_event==16) move_Image_Asm_565(x+m,y+n,36,36,BmpData_16);
		if(x_event==17) move_Image_Asm_565(x+m,y+n,36,36,BmpData_17);
		if(x_event==18) move_Image_Asm_565(x+m,y+n,36,36,BmpData_18);
		if(x_event==19) move_Image_Asm_565(x+m,y+n,36,36,BmpData_19);
		if(x_event==20) move_Image_Asm_565(x+m,y+n,36,36,BmpData_20);
		if(x_event==21) move_Image_Asm_565(x+m,y+n,36,36,BmpData_21);
		if(x_event==22) move_Image_Asm_565(x+m,y+n,36,36,BmpData_22);
		if(x_event==23) move_Image_Asm_565(x+m,y+n,36,36,BmpData_23);
		if(x_event==24) move_Image_Asm_565(x+m,y+n,36,36,BmpData_24);
		if(x_event==25) move_Image_Asm_565(x+m,y+n,36,36,BmpData_25);
		if(x_event==26) move_Image_Asm_565(x+m,y+n,36,36,BmpData_26);
		if(x_event==27) move_Image_Asm_565(x+m,y+n,36,36,BmpData_27);
		if(x_event==28) move_Image_Asm_565(x+m,y+n,36,36,BmpData_28);
		if(x_event==29) move_Image_Asm_565(x+m,y+n,36,36,BmpData_29);
		if(x_event==30) move_Image_Asm_565(x+m,y+n,36,36,BmpData_30);
		if(x_event==31) move_Image_Asm_565(x+m,y+n,36,36,BmpData_31);
		if(x_event==32) move_Image_Asm_565(x+m,y+n,36,36,BmpData_32);
		if(x_event==33) move_Image_Asm_565(x+m,y+n,36,36,BmpData_33);
		if(x_event==34) move_Image_Asm_565(x+m,y+n,36,36,BmpData_34);
		if(x_event==35) move_Image_Asm_565(x+m,y+n,36,36,BmpData_35);
		if(x_event==36) move_Image_Asm_565(x+m,y+n,36,36,BmpData_36);
		if(x_event==37) move_Image_Asm_565(x+m,y+n,36,36,BmpData_37);
		if(x_event==38) move_Image_Asm_565(x+m,y+n,36,36,BmpData_38);
		if(x_event==39) move_Image_Asm_565(x+m,y+n,36,36,BmpData_39);
		if(x_event==40) move_Image_Asm_565(x+m,y+n,36,36,BmpData_40);
		if(x_event==41) move_Image_Asm_565(x+m,y+n,36,36,BmpData_41);
		if(x_event==42) move_Image_Asm_565(x+m,y+n,36,36,BmpData_42);
		if(x_event==43) move_Image_Asm_565(x+m,y+n,36,36,BmpData_43);
		if(x_event==44) move_Image_Asm_565(x+m,y+n,36,36,BmpData_44);
		if(x_event==45) move_Image_Asm_565(x+m,y+n,36,36,BmpData_45);
		if(x_event==46) move_Image_Asm_565(x+m,y+n,36,36,BmpData_46);
		if(x_event==47) move_Image_Asm_565(x+m,y+n,36,36,BmpData_47);
		if(x_event==48) move_Image_Asm_565(x+m,y+n,36,36,BmpData_48);
		if(x_event==49) move_Image_Asm_565(x+m,y+n,36,36,BmpData_49);
		if(x_event==50) move_Image_Asm_565(x+m,y+n,36,36,BmpData_50);
		if(x_event==51) move_Image_Asm_565(x+m,y+n,36,36,BmpData_51);
		if(x_event==52) move_Image_Asm_565(x+m,y+n,36,36,BmpData_52);
		if(x_event==53) move_Image_Asm_565(x+m,y+n,36,36,BmpData_53);
		if(x_event==54) move_Image_Asm_565(x+m,y+n,36,36,BmpData_54);
		if(x_event==55) move_Image_Asm_565(x+m,y+n,36,36,BmpData_55);
		if(x_event==56) move_Image_Asm_565(x+m,y+n,36,36,BmpData_56);
		if(x_event==57) move_Image_Asm_565(x+m,y+n,36,36,BmpData_57);
		if(x_event==58) move_Image_Asm_565(x+m,y+n,36,36,BmpData_58);
		if(x_event==59) move_Image_Asm_565(x+m,y+n,36,36,BmpData_59);
		if(x_event==60) move_Image_Asm_565(x+m,y+n,36,36,BmpData_60);
		if(x_event==61) move_Image_Asm_565(x+m,y+n,36,36,BmpData_61);
		if(x_event==62) move_Image_Asm_565(x+m,y+n,36,36,BmpData_62);
		if(x_event==63) move_Image_Asm_565(x+m,y+n,36,36,BmpData_63);
		if(x_event==64) move_Image_Asm_565(x+m,y+n,36,36,BmpData_64);
		if(x_event==65) move_Image_Asm_565(x+m,y+n,36,36,BmpData_65);
		if(x_event==66) move_Image_Asm_565(x+m,y+n,36,36,BmpData_66);
		if(x_event==67) move_Image_Asm_565(x+m,y+n,36,36,BmpData_67);
		if(x_event==68) move_Image_Asm_565(x+m,y+n,36,36,BmpData_68);
		if(x_event==69) move_Image_Asm_565(x+m,y+n,36,36,BmpData_69);
		if(x_event==70) move_Image_Asm_565(x+m,y+n,36,36,BmpData_70);
		if(x_event==71) move_Image_Asm_565(x+m,y+n,36,36,BmpData_71);
		if(x_event==72) move_Image_Asm_565(x+m,y+n,36,36,BmpData_72);
		if(x_event==73) move_Image_Asm_565(x+m,y+n,36,36,BmpData_73);
		if(x_event==74) move_Image_Asm_565(x+m,y+n,36,36,BmpData_74);
		if(x_event==75) move_Image_Asm_565(x+m,y+n,36,36,BmpData_75);
		if(x_event==76) move_Image_Asm_565(x+m,y+n,36,36,BmpData_76);
		if(x_event==77) move_Image_Asm_565(x+m,y+n,36,36,BmpData_77);
		if(x_event==78) move_Image_Asm_565(x+m,y+n,36,36,BmpData_78);
		if(x_event==79) move_Image_Asm_565(x+m,y+n,36,36,BmpData_79);
		if(x_event==80) move_Image_Asm_565(x+m,y+n,36,36,BmpData_80);
		if(x_event==81) move_Image_Asm_565(x+m,y+n,36,36,BmpData_81);
		if(x_event==82) move_Image_Asm_565(x+m,y+n,36,36,BmpData_82);
		if(x_event==83) move_Image_Asm_565(x+m,y+n,36,36,BmpData_83);
		if(x_event==84) move_Image_Asm_565(x+m,y+n,36,36,BmpData_84);
		if(x_event==85) move_Image_Asm_565(x+m,y+n,36,36,BmpData_85);
		if(x_event==86) move_Image_Asm_565(x+m,y+n,36,36,BmpData_86);
		if(x_event==87) move_Image_Asm_565(x+m,y+n,36,36,BmpData_87);
		if(x_event==88) move_Image_Asm_565(x+m,y+n,36,36,BmpData_88);
		if(x_event==89) move_Image_Asm_565(x+m,y+n,36,36,BmpData_89);
		if(x_event==90) move_Image_Asm_565(x+m,y+n,36,36,BmpData_90);
		if(x_event==91) move_Image_Asm_565(x+m,y+n,36,36,BmpData_91);
		if(x_event==92) move_Image_Asm_565(x+m,y+n,36,36,BmpData_92);
		if(x_event==93) move_Image_Asm_565(x+m,y+n,36,36,BmpData_93);
		if(x_event==94) move_Image_Asm_565(x+m,y+n,36,36,BmpData_94);
		if(x_event==95) move_Image_Asm_565(x+m,y+n,36,36,BmpData_95);
		if(x_event==96) move_Image_Asm_565(x+m,y+n,36,36,BmpData_96);
		if(x_event==97) move_Image_Asm_565(x+m,y+n,36,36,BmpData_97);
		if(x_event==98) move_Image_Asm_565(x+m,y+n,36,36,BmpData_98);
		if(x_event==99) move_Image_Asm_565(x+m,y+n,36,36,BmpData_99);
		if(x_event==100) move_Image_Asm_565(x+m,y+n,36,36,BmpData_100);
		if(x_event==101) move_Image_Asm_565(x+m,y+n,36,36,BmpData_101);
		if(x_event==102) move_Image_Asm_565(x+m,y+n,36,36,BmpData_102);
		if(x_event==103) move_Image_Asm_565(x+m,y+n,36,36,BmpData_103);
		if(x_event==104) move_Image_Asm_565(x+m,y+n,36,36,BmpData_104);
		if(x_event==105) move_Image_Asm_565(x+m,y+n,36,36,BmpData_105);
		if(x_event==106) move_Image_Asm_565(x+m,y+n,36,36,BmpData_106);
		if(x_event==107) move_Image_Asm_565(x+m,y+n,36,36,BmpData_107);
		if(x_event==108) move_Image_Asm_565(x+m,y+n,36,36,BmpData_108);
		}
	if(RSN==2)   //ʳָ������ʾ
	{
		m=131;
		n=93;
		if(x_event==1) move_Image_Asm_565(x+m,y+n,36,36,BmpData_1);
		if(x_event==2) move_Image_Asm_565(x+m,y+n,36,36,BmpData_2);
		if(x_event==3) move_Image_Asm_565(x+m,y+n,36,36,BmpData_3);
		if(x_event==4) move_Image_Asm_565(x+m,y+n,36,36,BmpData_4);
		if(x_event==5) move_Image_Asm_565(x+m,y+n,36,36,BmpData_5);
		if(x_event==6) move_Image_Asm_565(x+m,y+n,36,36,BmpData_6);
		if(x_event==7) move_Image_Asm_565(x+m,y+n,36,36,BmpData_7);
		if(x_event==8) move_Image_Asm_565(x+m,y+n,36,36,BmpData_8);
		if(x_event==9) move_Image_Asm_565(x+m,y+n,36,36,BmpData_9);
		if(x_event==10) move_Image_Asm_565(x+m,y+n,36,36,BmpData_10);
		if(x_event==11) move_Image_Asm_565(x+m,y+n,36,36,BmpData_11);
		if(x_event==12) move_Image_Asm_565(x+m,y+n,36,36,BmpData_12);
		if(x_event==13) move_Image_Asm_565(x+m,y+n,36,36,BmpData_13);
		if(x_event==14) move_Image_Asm_565(x+m,y+n,36,36,BmpData_14);
		if(x_event==15) move_Image_Asm_565(x+m,y+n,36,36,BmpData_15);
		if(x_event==16) move_Image_Asm_565(x+m,y+n,36,36,BmpData_16);
		if(x_event==17) move_Image_Asm_565(x+m,y+n,36,36,BmpData_17);
		if(x_event==18) move_Image_Asm_565(x+m,y+n,36,36,BmpData_18);
		if(x_event==19) move_Image_Asm_565(x+m,y+n,36,36,BmpData_19);
		if(x_event==20) move_Image_Asm_565(x+m,y+n,36,36,BmpData_20);
		if(x_event==21) move_Image_Asm_565(x+m,y+n,36,36,BmpData_21);
		if(x_event==22) move_Image_Asm_565(x+m,y+n,36,36,BmpData_22);
		if(x_event==23) move_Image_Asm_565(x+m,y+n,36,36,BmpData_23);
		if(x_event==24) move_Image_Asm_565(x+m,y+n,36,36,BmpData_24);
		if(x_event==25) move_Image_Asm_565(x+m,y+n,36,36,BmpData_25);
		if(x_event==26) move_Image_Asm_565(x+m,y+n,36,36,BmpData_26);
		if(x_event==27) move_Image_Asm_565(x+m,y+n,36,36,BmpData_27);
		if(x_event==28) move_Image_Asm_565(x+m,y+n,36,36,BmpData_28);
		if(x_event==29) move_Image_Asm_565(x+m,y+n,36,36,BmpData_29);
		if(x_event==30) move_Image_Asm_565(x+m,y+n,36,36,BmpData_30);
		if(x_event==31) move_Image_Asm_565(x+m,y+n,36,36,BmpData_31);
		if(x_event==32) move_Image_Asm_565(x+m,y+n,36,36,BmpData_32);
		if(x_event==33) move_Image_Asm_565(x+m,y+n,36,36,BmpData_33);
		if(x_event==34) move_Image_Asm_565(x+m,y+n,36,36,BmpData_34);
		if(x_event==35) move_Image_Asm_565(x+m,y+n,36,36,BmpData_35);
		if(x_event==36) move_Image_Asm_565(x+m,y+n,36,36,BmpData_36);
		if(x_event==37) move_Image_Asm_565(x+m,y+n,36,36,BmpData_37);
		if(x_event==38) move_Image_Asm_565(x+m,y+n,36,36,BmpData_38);
		if(x_event==39) move_Image_Asm_565(x+m,y+n,36,36,BmpData_39);
		if(x_event==40) move_Image_Asm_565(x+m,y+n,36,36,BmpData_40);
		if(x_event==41) move_Image_Asm_565(x+m,y+n,36,36,BmpData_41);
		if(x_event==42) move_Image_Asm_565(x+m,y+n,36,36,BmpData_42);
		if(x_event==43) move_Image_Asm_565(x+m,y+n,36,36,BmpData_43);
		if(x_event==44) move_Image_Asm_565(x+m,y+n,36,36,BmpData_44);
		if(x_event==45) move_Image_Asm_565(x+m,y+n,36,36,BmpData_45);
		if(x_event==46) move_Image_Asm_565(x+m,y+n,36,36,BmpData_46);
		if(x_event==47) move_Image_Asm_565(x+m,y+n,36,36,BmpData_47);
		if(x_event==48) move_Image_Asm_565(x+m,y+n,36,36,BmpData_48);
		if(x_event==49) move_Image_Asm_565(x+m,y+n,36,36,BmpData_49);
		if(x_event==50) move_Image_Asm_565(x+m,y+n,36,36,BmpData_50);
		if(x_event==51) move_Image_Asm_565(x+m,y+n,36,36,BmpData_51);
		if(x_event==52) move_Image_Asm_565(x+m,y+n,36,36,BmpData_52);
		if(x_event==53) move_Image_Asm_565(x+m,y+n,36,36,BmpData_53);
		if(x_event==54) move_Image_Asm_565(x+m,y+n,36,36,BmpData_54);
		if(x_event==55) move_Image_Asm_565(x+m,y+n,36,36,BmpData_55);
		if(x_event==56) move_Image_Asm_565(x+m,y+n,36,36,BmpData_56);
		if(x_event==57) move_Image_Asm_565(x+m,y+n,36,36,BmpData_57);
		if(x_event==58) move_Image_Asm_565(x+m,y+n,36,36,BmpData_58);
		if(x_event==59) move_Image_Asm_565(x+m,y+n,36,36,BmpData_59);
		if(x_event==60) move_Image_Asm_565(x+m,y+n,36,36,BmpData_60);
		if(x_event==61) move_Image_Asm_565(x+m,y+n,36,36,BmpData_61);
		if(x_event==62) move_Image_Asm_565(x+m,y+n,36,36,BmpData_62);
		if(x_event==63) move_Image_Asm_565(x+m,y+n,36,36,BmpData_63);
		if(x_event==64) move_Image_Asm_565(x+m,y+n,36,36,BmpData_64);
		if(x_event==65) move_Image_Asm_565(x+m,y+n,36,36,BmpData_65);
		if(x_event==66) move_Image_Asm_565(x+m,y+n,36,36,BmpData_66);
		if(x_event==67) move_Image_Asm_565(x+m,y+n,36,36,BmpData_67);
		if(x_event==68) move_Image_Asm_565(x+m,y+n,36,36,BmpData_68);
		if(x_event==69) move_Image_Asm_565(x+m,y+n,36,36,BmpData_69);
		if(x_event==70) move_Image_Asm_565(x+m,y+n,36,36,BmpData_70);
		if(x_event==71) move_Image_Asm_565(x+m,y+n,36,36,BmpData_71);
		if(x_event==72) move_Image_Asm_565(x+m,y+n,36,36,BmpData_72);
		if(x_event==73) move_Image_Asm_565(x+m,y+n,36,36,BmpData_73);
		if(x_event==74) move_Image_Asm_565(x+m,y+n,36,36,BmpData_74);
		if(x_event==75) move_Image_Asm_565(x+m,y+n,36,36,BmpData_75);
		if(x_event==76) move_Image_Asm_565(x+m,y+n,36,36,BmpData_76);
		if(x_event==77) move_Image_Asm_565(x+m,y+n,36,36,BmpData_77);
		if(x_event==78) move_Image_Asm_565(x+m,y+n,36,36,BmpData_78);
		if(x_event==79) move_Image_Asm_565(x+m,y+n,36,36,BmpData_79);
		if(x_event==80) move_Image_Asm_565(x+m,y+n,36,36,BmpData_80);
		if(x_event==81) move_Image_Asm_565(x+m,y+n,36,36,BmpData_81);
		if(x_event==82) move_Image_Asm_565(x+m,y+n,36,36,BmpData_82);
		if(x_event==83) move_Image_Asm_565(x+m,y+n,36,36,BmpData_83);
		if(x_event==84) move_Image_Asm_565(x+m,y+n,36,36,BmpData_84);
		if(x_event==85) move_Image_Asm_565(x+m,y+n,36,36,BmpData_85);
		if(x_event==86) move_Image_Asm_565(x+m,y+n,36,36,BmpData_86);
		if(x_event==87) move_Image_Asm_565(x+m,y+n,36,36,BmpData_87);
		if(x_event==88) move_Image_Asm_565(x+m,y+n,36,36,BmpData_88);
		if(x_event==89) move_Image_Asm_565(x+m,y+n,36,36,BmpData_89);
		if(x_event==90) move_Image_Asm_565(x+m,y+n,36,36,BmpData_90);
		if(x_event==91) move_Image_Asm_565(x+m,y+n,36,36,BmpData_91);
		if(x_event==92) move_Image_Asm_565(x+m,y+n,36,36,BmpData_92);
		if(x_event==93) move_Image_Asm_565(x+m,y+n,36,36,BmpData_93);
		if(x_event==94) move_Image_Asm_565(x+m,y+n,36,36,BmpData_94);
		if(x_event==95) move_Image_Asm_565(x+m,y+n,36,36,BmpData_95);
		if(x_event==96) move_Image_Asm_565(x+m,y+n,36,36,BmpData_96);
		if(x_event==97) move_Image_Asm_565(x+m,y+n,36,36,BmpData_97);
		if(x_event==98) move_Image_Asm_565(x+m,y+n,36,36,BmpData_98);
		if(x_event==99) move_Image_Asm_565(x+m,y+n,36,36,BmpData_99);
		if(x_event==100) move_Image_Asm_565(x+m,y+n,36,36,BmpData_100);
		if(x_event==101) move_Image_Asm_565(x+m,y+n,36,36,BmpData_101);
		if(x_event==102) move_Image_Asm_565(x+m,y+n,36,36,BmpData_102);
		if(x_event==103) move_Image_Asm_565(x+m,y+n,36,36,BmpData_103);
		if(x_event==104) move_Image_Asm_565(x+m,y+n,36,36,BmpData_104);
		if(x_event==105) move_Image_Asm_565(x+m,y+n,36,36,BmpData_105);
		if(x_event==106) move_Image_Asm_565(x+m,y+n,36,36,BmpData_106);
		if(x_event==107) move_Image_Asm_565(x+m,y+n,36,36,BmpData_107);
		if(x_event==108) move_Image_Asm_565(x+m,y+n,36,36,BmpData_108);
	}
	if(RSN==3)     //��ָ������ʾ
	{
		m=147;
		n=141;
		if(x_event==1) move_Image_Asm_565(x+m,y+n,36,36,BmpData_1);
		if(x_event==2) move_Image_Asm_565(x+m,y+n,36,36,BmpData_2);
		if(x_event==3) move_Image_Asm_565(x+m,y+n,36,36,BmpData_3);
		if(x_event==4) move_Image_Asm_565(x+m,y+n,36,36,BmpData_4);
		if(x_event==5) move_Image_Asm_565(x+m,y+n,36,36,BmpData_5);
		if(x_event==6) move_Image_Asm_565(x+m,y+n,36,36,BmpData_6);
		if(x_event==7) move_Image_Asm_565(x+m,y+n,36,36,BmpData_7);
		if(x_event==8) move_Image_Asm_565(x+m,y+n,36,36,BmpData_8);
		if(x_event==9) move_Image_Asm_565(x+m,y+n,36,36,BmpData_9);
		if(x_event==10) move_Image_Asm_565(x+m,y+n,36,36,BmpData_10);
		if(x_event==11) move_Image_Asm_565(x+m,y+n,36,36,BmpData_11);
		if(x_event==12) move_Image_Asm_565(x+m,y+n,36,36,BmpData_12);
		if(x_event==13) move_Image_Asm_565(x+m,y+n,36,36,BmpData_13);
		if(x_event==14) move_Image_Asm_565(x+m,y+n,36,36,BmpData_14);
		if(x_event==15) move_Image_Asm_565(x+m,y+n,36,36,BmpData_15);
		if(x_event==16) move_Image_Asm_565(x+m,y+n,36,36,BmpData_16);
		if(x_event==17) move_Image_Asm_565(x+m,y+n,36,36,BmpData_17);
		if(x_event==18) move_Image_Asm_565(x+m,y+n,36,36,BmpData_18);
		if(x_event==19) move_Image_Asm_565(x+m,y+n,36,36,BmpData_19);
		if(x_event==20) move_Image_Asm_565(x+m,y+n,36,36,BmpData_20);
		if(x_event==21) move_Image_Asm_565(x+m,y+n,36,36,BmpData_21);
		if(x_event==22) move_Image_Asm_565(x+m,y+n,36,36,BmpData_22);
		if(x_event==23) move_Image_Asm_565(x+m,y+n,36,36,BmpData_23);
		if(x_event==24) move_Image_Asm_565(x+m,y+n,36,36,BmpData_24);
		if(x_event==25) move_Image_Asm_565(x+m,y+n,36,36,BmpData_25);
		if(x_event==26) move_Image_Asm_565(x+m,y+n,36,36,BmpData_26);
		if(x_event==27) move_Image_Asm_565(x+m,y+n,36,36,BmpData_27);
		if(x_event==28) move_Image_Asm_565(x+m,y+n,36,36,BmpData_28);
		if(x_event==29) move_Image_Asm_565(x+m,y+n,36,36,BmpData_29);
		if(x_event==30) move_Image_Asm_565(x+m,y+n,36,36,BmpData_30);
		if(x_event==31) move_Image_Asm_565(x+m,y+n,36,36,BmpData_31);
		if(x_event==32) move_Image_Asm_565(x+m,y+n,36,36,BmpData_32);
		if(x_event==33) move_Image_Asm_565(x+m,y+n,36,36,BmpData_33);
		if(x_event==34) move_Image_Asm_565(x+m,y+n,36,36,BmpData_34);
		if(x_event==35) move_Image_Asm_565(x+m,y+n,36,36,BmpData_35);
		if(x_event==36) move_Image_Asm_565(x+m,y+n,36,36,BmpData_36);
		if(x_event==37) move_Image_Asm_565(x+m,y+n,36,36,BmpData_37);
		if(x_event==38) move_Image_Asm_565(x+m,y+n,36,36,BmpData_38);
		if(x_event==39) move_Image_Asm_565(x+m,y+n,36,36,BmpData_39);
		if(x_event==40) move_Image_Asm_565(x+m,y+n,36,36,BmpData_40);
		if(x_event==41) move_Image_Asm_565(x+m,y+n,36,36,BmpData_41);
		if(x_event==42) move_Image_Asm_565(x+m,y+n,36,36,BmpData_42);
		if(x_event==43) move_Image_Asm_565(x+m,y+n,36,36,BmpData_43);
		if(x_event==44) move_Image_Asm_565(x+m,y+n,36,36,BmpData_44);
		if(x_event==45) move_Image_Asm_565(x+m,y+n,36,36,BmpData_45);
		if(x_event==46) move_Image_Asm_565(x+m,y+n,36,36,BmpData_46);
		if(x_event==47) move_Image_Asm_565(x+m,y+n,36,36,BmpData_47);
		if(x_event==48) move_Image_Asm_565(x+m,y+n,36,36,BmpData_48);
		if(x_event==49) move_Image_Asm_565(x+m,y+n,36,36,BmpData_49);
		if(x_event==50) move_Image_Asm_565(x+m,y+n,36,36,BmpData_50);
		if(x_event==51) move_Image_Asm_565(x+m,y+n,36,36,BmpData_51);
		if(x_event==52) move_Image_Asm_565(x+m,y+n,36,36,BmpData_52);
		if(x_event==53) move_Image_Asm_565(x+m,y+n,36,36,BmpData_53);
		if(x_event==54) move_Image_Asm_565(x+m,y+n,36,36,BmpData_54);
		if(x_event==55) move_Image_Asm_565(x+m,y+n,36,36,BmpData_55);
		if(x_event==56) move_Image_Asm_565(x+m,y+n,36,36,BmpData_56);
		if(x_event==57) move_Image_Asm_565(x+m,y+n,36,36,BmpData_57);
		if(x_event==58) move_Image_Asm_565(x+m,y+n,36,36,BmpData_58);
		if(x_event==59) move_Image_Asm_565(x+m,y+n,36,36,BmpData_59);
		if(x_event==60) move_Image_Asm_565(x+m,y+n,36,36,BmpData_60);
		if(x_event==61) move_Image_Asm_565(x+m,y+n,36,36,BmpData_61);
		if(x_event==62) move_Image_Asm_565(x+m,y+n,36,36,BmpData_62);
		if(x_event==63) move_Image_Asm_565(x+m,y+n,36,36,BmpData_63);
		if(x_event==64) move_Image_Asm_565(x+m,y+n,36,36,BmpData_64);
		if(x_event==65) move_Image_Asm_565(x+m,y+n,36,36,BmpData_65);
		if(x_event==66) move_Image_Asm_565(x+m,y+n,36,36,BmpData_66);
		if(x_event==67) move_Image_Asm_565(x+m,y+n,36,36,BmpData_67);
		if(x_event==68) move_Image_Asm_565(x+m,y+n,36,36,BmpData_68);
		if(x_event==69) move_Image_Asm_565(x+m,y+n,36,36,BmpData_69);
		if(x_event==70) move_Image_Asm_565(x+m,y+n,36,36,BmpData_70);
		if(x_event==71) move_Image_Asm_565(x+m,y+n,36,36,BmpData_71);
		if(x_event==72) move_Image_Asm_565(x+m,y+n,36,36,BmpData_72);
		if(x_event==73) move_Image_Asm_565(x+m,y+n,36,36,BmpData_73);
		if(x_event==74) move_Image_Asm_565(x+m,y+n,36,36,BmpData_74);
		if(x_event==75) move_Image_Asm_565(x+m,y+n,36,36,BmpData_75);
		if(x_event==76) move_Image_Asm_565(x+m,y+n,36,36,BmpData_76);
		if(x_event==77) move_Image_Asm_565(x+m,y+n,36,36,BmpData_77);
		if(x_event==78) move_Image_Asm_565(x+m,y+n,36,36,BmpData_78);
		if(x_event==79) move_Image_Asm_565(x+m,y+n,36,36,BmpData_79);
		if(x_event==80) move_Image_Asm_565(x+m,y+n,36,36,BmpData_80);
		if(x_event==81) move_Image_Asm_565(x+m,y+n,36,36,BmpData_81);
		if(x_event==82) move_Image_Asm_565(x+m,y+n,36,36,BmpData_82);
		if(x_event==83) move_Image_Asm_565(x+m,y+n,36,36,BmpData_83);
		if(x_event==84) move_Image_Asm_565(x+m,y+n,36,36,BmpData_84);
		if(x_event==85) move_Image_Asm_565(x+m,y+n,36,36,BmpData_85);
		if(x_event==86) move_Image_Asm_565(x+m,y+n,36,36,BmpData_86);
		if(x_event==87) move_Image_Asm_565(x+m,y+n,36,36,BmpData_87);
		if(x_event==88) move_Image_Asm_565(x+m,y+n,36,36,BmpData_88);
		if(x_event==89) move_Image_Asm_565(x+m,y+n,36,36,BmpData_89);
		if(x_event==90) move_Image_Asm_565(x+m,y+n,36,36,BmpData_90);
		if(x_event==91) move_Image_Asm_565(x+m,y+n,36,36,BmpData_91);
		if(x_event==92) move_Image_Asm_565(x+m,y+n,36,36,BmpData_92);
		if(x_event==93) move_Image_Asm_565(x+m,y+n,36,36,BmpData_93);
		if(x_event==94) move_Image_Asm_565(x+m,y+n,36,36,BmpData_94);
		if(x_event==95) move_Image_Asm_565(x+m,y+n,36,36,BmpData_95);
		if(x_event==96) move_Image_Asm_565(x+m,y+n,36,36,BmpData_96);
		if(x_event==97) move_Image_Asm_565(x+m,y+n,36,36,BmpData_97);
		if(x_event==98) move_Image_Asm_565(x+m,y+n,36,36,BmpData_98);
		if(x_event==99) move_Image_Asm_565(x+m,y+n,36,36,BmpData_99);
		if(x_event==100) move_Image_Asm_565(x+m,y+n,36,36,BmpData_100);
		if(x_event==101) move_Image_Asm_565(x+m,y+n,36,36,BmpData_101);
		if(x_event==102) move_Image_Asm_565(x+m,y+n,36,36,BmpData_102);
		if(x_event==103) move_Image_Asm_565(x+m,y+n,36,36,BmpData_103);
		if(x_event==104) move_Image_Asm_565(x+m,y+n,36,36,BmpData_104);
		if(x_event==105) move_Image_Asm_565(x+m,y+n,36,36,BmpData_105);
		if(x_event==106) move_Image_Asm_565(x+m,y+n,36,36,BmpData_106);
		if(x_event==107) move_Image_Asm_565(x+m,y+n,36,36,BmpData_107);
		if(x_event==108) move_Image_Asm_565(x+m,y+n,36,36,BmpData_108);
	}
	if(RSN==4)      //����ָ������ʾ
	{
		m=129;
		n=184;
		if(x_event==1) move_Image_Asm_565(x+m,y+n,36,36,BmpData_1);
		if(x_event==2) move_Image_Asm_565(x+m,y+n,36,36,BmpData_2);
		if(x_event==3) move_Image_Asm_565(x+m,y+n,36,36,BmpData_3);
		if(x_event==4) move_Image_Asm_565(x+m,y+n,36,36,BmpData_4);
		if(x_event==5) move_Image_Asm_565(x+m,y+n,36,36,BmpData_5);
		if(x_event==6) move_Image_Asm_565(x+m,y+n,36,36,BmpData_6);
		if(x_event==7) move_Image_Asm_565(x+m,y+n,36,36,BmpData_7);
		if(x_event==8) move_Image_Asm_565(x+m,y+n,36,36,BmpData_8);
		if(x_event==9) move_Image_Asm_565(x+m,y+n,36,36,BmpData_9);
		if(x_event==10) move_Image_Asm_565(x+m,y+n,36,36,BmpData_10);
		if(x_event==11) move_Image_Asm_565(x+m,y+n,36,36,BmpData_11);
		if(x_event==12) move_Image_Asm_565(x+m,y+n,36,36,BmpData_12);
		if(x_event==13) move_Image_Asm_565(x+m,y+n,36,36,BmpData_13);
		if(x_event==14) move_Image_Asm_565(x+m,y+n,36,36,BmpData_14);
		if(x_event==15) move_Image_Asm_565(x+m,y+n,36,36,BmpData_15);
		if(x_event==16) move_Image_Asm_565(x+m,y+n,36,36,BmpData_16);
		if(x_event==17) move_Image_Asm_565(x+m,y+n,36,36,BmpData_17);
		if(x_event==18) move_Image_Asm_565(x+m,y+n,36,36,BmpData_18);
		if(x_event==19) move_Image_Asm_565(x+m,y+n,36,36,BmpData_19);
		if(x_event==20) move_Image_Asm_565(x+m,y+n,36,36,BmpData_20);
		if(x_event==21) move_Image_Asm_565(x+m,y+n,36,36,BmpData_21);
		if(x_event==22) move_Image_Asm_565(x+m,y+n,36,36,BmpData_22);
		if(x_event==23) move_Image_Asm_565(x+m,y+n,36,36,BmpData_23);
		if(x_event==24) move_Image_Asm_565(x+m,y+n,36,36,BmpData_24);
		if(x_event==25) move_Image_Asm_565(x+m,y+n,36,36,BmpData_25);
		if(x_event==26) move_Image_Asm_565(x+m,y+n,36,36,BmpData_26);
		if(x_event==27) move_Image_Asm_565(x+m,y+n,36,36,BmpData_27);
		if(x_event==28) move_Image_Asm_565(x+m,y+n,36,36,BmpData_28);
		if(x_event==29) move_Image_Asm_565(x+m,y+n,36,36,BmpData_29);
		if(x_event==30) move_Image_Asm_565(x+m,y+n,36,36,BmpData_30);
		if(x_event==31) move_Image_Asm_565(x+m,y+n,36,36,BmpData_31);
		if(x_event==32) move_Image_Asm_565(x+m,y+n,36,36,BmpData_32);
		if(x_event==33) move_Image_Asm_565(x+m,y+n,36,36,BmpData_33);
		if(x_event==34) move_Image_Asm_565(x+m,y+n,36,36,BmpData_34);
		if(x_event==35) move_Image_Asm_565(x+m,y+n,36,36,BmpData_35);
		if(x_event==36) move_Image_Asm_565(x+m,y+n,36,36,BmpData_36);
		if(x_event==37) move_Image_Asm_565(x+m,y+n,36,36,BmpData_37);
		if(x_event==38) move_Image_Asm_565(x+m,y+n,36,36,BmpData_38);
		if(x_event==39) move_Image_Asm_565(x+m,y+n,36,36,BmpData_39);
		if(x_event==40) move_Image_Asm_565(x+m,y+n,36,36,BmpData_40);
		if(x_event==41) move_Image_Asm_565(x+m,y+n,36,36,BmpData_41);
		if(x_event==42) move_Image_Asm_565(x+m,y+n,36,36,BmpData_42);
		if(x_event==43) move_Image_Asm_565(x+m,y+n,36,36,BmpData_43);
		if(x_event==44) move_Image_Asm_565(x+m,y+n,36,36,BmpData_44);
		if(x_event==45) move_Image_Asm_565(x+m,y+n,36,36,BmpData_45);
		if(x_event==46) move_Image_Asm_565(x+m,y+n,36,36,BmpData_46);
		if(x_event==47) move_Image_Asm_565(x+m,y+n,36,36,BmpData_47);
		if(x_event==48) move_Image_Asm_565(x+m,y+n,36,36,BmpData_48);
		if(x_event==49) move_Image_Asm_565(x+m,y+n,36,36,BmpData_49);
		if(x_event==50) move_Image_Asm_565(x+m,y+n,36,36,BmpData_50);
		if(x_event==51) move_Image_Asm_565(x+m,y+n,36,36,BmpData_51);
		if(x_event==52) move_Image_Asm_565(x+m,y+n,36,36,BmpData_52);
		if(x_event==53) move_Image_Asm_565(x+m,y+n,36,36,BmpData_53);
		if(x_event==54) move_Image_Asm_565(x+m,y+n,36,36,BmpData_54);
		if(x_event==55) move_Image_Asm_565(x+m,y+n,36,36,BmpData_55);
		if(x_event==56) move_Image_Asm_565(x+m,y+n,36,36,BmpData_56);
		if(x_event==57) move_Image_Asm_565(x+m,y+n,36,36,BmpData_57);
		if(x_event==58) move_Image_Asm_565(x+m,y+n,36,36,BmpData_58);
		if(x_event==59) move_Image_Asm_565(x+m,y+n,36,36,BmpData_59);
		if(x_event==60) move_Image_Asm_565(x+m,y+n,36,36,BmpData_60);
		if(x_event==61) move_Image_Asm_565(x+m,y+n,36,36,BmpData_61);
		if(x_event==62) move_Image_Asm_565(x+m,y+n,36,36,BmpData_62);
		if(x_event==63) move_Image_Asm_565(x+m,y+n,36,36,BmpData_63);
		if(x_event==64) move_Image_Asm_565(x+m,y+n,36,36,BmpData_64);
		if(x_event==65) move_Image_Asm_565(x+m,y+n,36,36,BmpData_65);
		if(x_event==66) move_Image_Asm_565(x+m,y+n,36,36,BmpData_66);
		if(x_event==67) move_Image_Asm_565(x+m,y+n,36,36,BmpData_67);
		if(x_event==68) move_Image_Asm_565(x+m,y+n,36,36,BmpData_68);
		if(x_event==69) move_Image_Asm_565(x+m,y+n,36,36,BmpData_69);
		if(x_event==70) move_Image_Asm_565(x+m,y+n,36,36,BmpData_70);
		if(x_event==71) move_Image_Asm_565(x+m,y+n,36,36,BmpData_71);
		if(x_event==72) move_Image_Asm_565(x+m,y+n,36,36,BmpData_72);
		if(x_event==73) move_Image_Asm_565(x+m,y+n,36,36,BmpData_73);
		if(x_event==74) move_Image_Asm_565(x+m,y+n,36,36,BmpData_74);
		if(x_event==75) move_Image_Asm_565(x+m,y+n,36,36,BmpData_75);
		if(x_event==76) move_Image_Asm_565(x+m,y+n,36,36,BmpData_76);
		if(x_event==77) move_Image_Asm_565(x+m,y+n,36,36,BmpData_77);
		if(x_event==78) move_Image_Asm_565(x+m,y+n,36,36,BmpData_78);
		if(x_event==79) move_Image_Asm_565(x+m,y+n,36,36,BmpData_79);
		if(x_event==80) move_Image_Asm_565(x+m,y+n,36,36,BmpData_80);
		if(x_event==81) move_Image_Asm_565(x+m,y+n,36,36,BmpData_81);
		if(x_event==82) move_Image_Asm_565(x+m,y+n,36,36,BmpData_82);
		if(x_event==83) move_Image_Asm_565(x+m,y+n,36,36,BmpData_83);
		if(x_event==84) move_Image_Asm_565(x+m,y+n,36,36,BmpData_84);
		if(x_event==85) move_Image_Asm_565(x+m,y+n,36,36,BmpData_85);
		if(x_event==86) move_Image_Asm_565(x+m,y+n,36,36,BmpData_86);
		if(x_event==87) move_Image_Asm_565(x+m,y+n,36,36,BmpData_87);
		if(x_event==88) move_Image_Asm_565(x+m,y+n,36,36,BmpData_88);
		if(x_event==89) move_Image_Asm_565(x+m,y+n,36,36,BmpData_89);
		if(x_event==90) move_Image_Asm_565(x+m,y+n,36,36,BmpData_90);
		if(x_event==91) move_Image_Asm_565(x+m,y+n,36,36,BmpData_91);
		if(x_event==92) move_Image_Asm_565(x+m,y+n,36,36,BmpData_92);
		if(x_event==93) move_Image_Asm_565(x+m,y+n,36,36,BmpData_93);
		if(x_event==94) move_Image_Asm_565(x+m,y+n,36,36,BmpData_94);
		if(x_event==95) move_Image_Asm_565(x+m,y+n,36,36,BmpData_95);
		if(x_event==96) move_Image_Asm_565(x+m,y+n,36,36,BmpData_96);
		if(x_event==97) move_Image_Asm_565(x+m,y+n,36,36,BmpData_97);
		if(x_event==98) move_Image_Asm_565(x+m,y+n,36,36,BmpData_98);
		if(x_event==99) move_Image_Asm_565(x+m,y+n,36,36,BmpData_99);
		if(x_event==100) move_Image_Asm_565(x+m,y+n,36,36,BmpData_100);
		if(x_event==101) move_Image_Asm_565(x+m,y+n,36,36,BmpData_101);
		if(x_event==102) move_Image_Asm_565(x+m,y+n,36,36,BmpData_102);
		if(x_event==103) move_Image_Asm_565(x+m,y+n,36,36,BmpData_103);
		if(x_event==104) move_Image_Asm_565(x+m,y+n,36,36,BmpData_104);
		if(x_event==105) move_Image_Asm_565(x+m,y+n,36,36,BmpData_105);
		if(x_event==106) move_Image_Asm_565(x+m,y+n,36,36,BmpData_104);
		if(x_event==107) move_Image_Asm_565(x+m,y+n,36,36,BmpData_107);
		if(x_event==108) move_Image_Asm_565(x+m,y+n,36,36,BmpData_108);
	}
	if(RSN==5)    //βָ������ʾ
	{
		m=107;
		n=228;
		if(x_event==1) move_Image_Asm_565(x+m,y+n,36,36,BmpData_1);
		if(x_event==2) move_Image_Asm_565(x+m,y+n,36,36,BmpData_2);
		if(x_event==3) move_Image_Asm_565(x+m,y+n,36,36,BmpData_3);
		if(x_event==4) move_Image_Asm_565(x+m,y+n,36,36,BmpData_4);
		if(x_event==5) move_Image_Asm_565(x+m,y+n,36,36,BmpData_5);
		if(x_event==6) move_Image_Asm_565(x+m,y+n,36,36,BmpData_6);
		if(x_event==7) move_Image_Asm_565(x+m,y+n,36,36,BmpData_7);
		if(x_event==8) move_Image_Asm_565(x+m,y+n,36,36,BmpData_8);
		if(x_event==9) move_Image_Asm_565(x+m,y+n,36,36,BmpData_9);
		if(x_event==10) move_Image_Asm_565(x+m,y+n,36,36,BmpData_10);
		if(x_event==11) move_Image_Asm_565(x+m,y+n,36,36,BmpData_11);
		if(x_event==12) move_Image_Asm_565(x+m,y+n,36,36,BmpData_12);
		if(x_event==13) move_Image_Asm_565(x+m,y+n,36,36,BmpData_13);
		if(x_event==14) move_Image_Asm_565(x+m,y+n,36,36,BmpData_14);
		if(x_event==15) move_Image_Asm_565(x+m,y+n,36,36,BmpData_15);
		if(x_event==16) move_Image_Asm_565(x+m,y+n,36,36,BmpData_16);
		if(x_event==17) move_Image_Asm_565(x+m,y+n,36,36,BmpData_17);
		if(x_event==18) move_Image_Asm_565(x+m,y+n,36,36,BmpData_18);
		if(x_event==19) move_Image_Asm_565(x+m,y+n,36,36,BmpData_19);
		if(x_event==20) move_Image_Asm_565(x+m,y+n,36,36,BmpData_20);
		if(x_event==21) move_Image_Asm_565(x+m,y+n,36,36,BmpData_21);
		if(x_event==22) move_Image_Asm_565(x+m,y+n,36,36,BmpData_22);
		if(x_event==23) move_Image_Asm_565(x+m,y+n,36,36,BmpData_23);
		if(x_event==24) move_Image_Asm_565(x+m,y+n,36,36,BmpData_24);
		if(x_event==25) move_Image_Asm_565(x+m,y+n,36,36,BmpData_25);
		if(x_event==26) move_Image_Asm_565(x+m,y+n,36,36,BmpData_26);
		if(x_event==27) move_Image_Asm_565(x+m,y+n,36,36,BmpData_27);
		if(x_event==28) move_Image_Asm_565(x+m,y+n,36,36,BmpData_28);
		if(x_event==29) move_Image_Asm_565(x+m,y+n,36,36,BmpData_29);
		if(x_event==30) move_Image_Asm_565(x+m,y+n,36,36,BmpData_30);
		if(x_event==31) move_Image_Asm_565(x+m,y+n,36,36,BmpData_31);
		if(x_event==32) move_Image_Asm_565(x+m,y+n,36,36,BmpData_32);
		if(x_event==33) move_Image_Asm_565(x+m,y+n,36,36,BmpData_33);
		if(x_event==34) move_Image_Asm_565(x+m,y+n,36,36,BmpData_34);
		if(x_event==35) move_Image_Asm_565(x+m,y+n,36,36,BmpData_35);
		if(x_event==36) move_Image_Asm_565(x+m,y+n,36,36,BmpData_36);
		if(x_event==37) move_Image_Asm_565(x+m,y+n,36,36,BmpData_37);
		if(x_event==38) move_Image_Asm_565(x+m,y+n,36,36,BmpData_38);
		if(x_event==39) move_Image_Asm_565(x+m,y+n,36,36,BmpData_39);
		if(x_event==40) move_Image_Asm_565(x+m,y+n,36,36,BmpData_40);
		if(x_event==41) move_Image_Asm_565(x+m,y+n,36,36,BmpData_41);
		if(x_event==42) move_Image_Asm_565(x+m,y+n,36,36,BmpData_42);
		if(x_event==43) move_Image_Asm_565(x+m,y+n,36,36,BmpData_43);
		if(x_event==44) move_Image_Asm_565(x+m,y+n,36,36,BmpData_44);
		if(x_event==45) move_Image_Asm_565(x+m,y+n,36,36,BmpData_45);
		if(x_event==46) move_Image_Asm_565(x+m,y+n,36,36,BmpData_46);
		if(x_event==47) move_Image_Asm_565(x+m,y+n,36,36,BmpData_47);
		if(x_event==48) move_Image_Asm_565(x+m,y+n,36,36,BmpData_48);
		if(x_event==49) move_Image_Asm_565(x+m,y+n,36,36,BmpData_49);
		if(x_event==50) move_Image_Asm_565(x+m,y+n,36,36,BmpData_50);
		if(x_event==51) move_Image_Asm_565(x+m,y+n,36,36,BmpData_51);
		if(x_event==52) move_Image_Asm_565(x+m,y+n,36,36,BmpData_52);
		if(x_event==53) move_Image_Asm_565(x+m,y+n,36,36,BmpData_53);
		if(x_event==54) move_Image_Asm_565(x+m,y+n,36,36,BmpData_54);
		if(x_event==55) move_Image_Asm_565(x+m,y+n,36,36,BmpData_55);
		if(x_event==56) move_Image_Asm_565(x+m,y+n,36,36,BmpData_56);
		if(x_event==57) move_Image_Asm_565(x+m,y+n,36,36,BmpData_57);
		if(x_event==58) move_Image_Asm_565(x+m,y+n,36,36,BmpData_58);
		if(x_event==59) move_Image_Asm_565(x+m,y+n,36,36,BmpData_59);
		if(x_event==60) move_Image_Asm_565(x+m,y+n,36,36,BmpData_60);
		if(x_event==61) move_Image_Asm_565(x+m,y+n,36,36,BmpData_61);
		if(x_event==62) move_Image_Asm_565(x+m,y+n,36,36,BmpData_62);
		if(x_event==63) move_Image_Asm_565(x+m,y+n,36,36,BmpData_63);
		if(x_event==64) move_Image_Asm_565(x+m,y+n,36,36,BmpData_64);
		if(x_event==65) move_Image_Asm_565(x+m,y+n,36,36,BmpData_65);
		if(x_event==66) move_Image_Asm_565(x+m,y+n,36,36,BmpData_66);
		if(x_event==67) move_Image_Asm_565(x+m,y+n,36,36,BmpData_67);
		if(x_event==68) move_Image_Asm_565(x+m,y+n,36,36,BmpData_68);
		if(x_event==69) move_Image_Asm_565(x+m,y+n,36,36,BmpData_69);
		if(x_event==70) move_Image_Asm_565(x+m,y+n,36,36,BmpData_70);
		if(x_event==71) move_Image_Asm_565(x+m,y+n,36,36,BmpData_71);
		if(x_event==72) move_Image_Asm_565(x+m,y+n,36,36,BmpData_72);
		if(x_event==73) move_Image_Asm_565(x+m,y+n,36,36,BmpData_73);
		if(x_event==74) move_Image_Asm_565(x+m,y+n,36,36,BmpData_74);
		if(x_event==75) move_Image_Asm_565(x+m,y+n,36,36,BmpData_75);
		if(x_event==76) move_Image_Asm_565(x+m,y+n,36,36,BmpData_76);
		if(x_event==77) move_Image_Asm_565(x+m,y+n,36,36,BmpData_77);
		if(x_event==78) move_Image_Asm_565(x+m,y+n,36,36,BmpData_78);
		if(x_event==79) move_Image_Asm_565(x+m,y+n,36,36,BmpData_79);
		if(x_event==80) move_Image_Asm_565(x+m,y+n,36,36,BmpData_80);
		if(x_event==81) move_Image_Asm_565(x+m,y+n,36,36,BmpData_81);
		if(x_event==82) move_Image_Asm_565(x+m,y+n,36,36,BmpData_82);
		if(x_event==83) move_Image_Asm_565(x+m,y+n,36,36,BmpData_83);
		if(x_event==84) move_Image_Asm_565(x+m,y+n,36,36,BmpData_84);
		if(x_event==85) move_Image_Asm_565(x+m,y+n,36,36,BmpData_85);
		if(x_event==86) move_Image_Asm_565(x+m,y+n,36,36,BmpData_86);
		if(x_event==87) move_Image_Asm_565(x+m,y+n,36,36,BmpData_87);
		if(x_event==88) move_Image_Asm_565(x+m,y+n,36,36,BmpData_88);
		if(x_event==89) move_Image_Asm_565(x+m,y+n,36,36,BmpData_89);
		if(x_event==90) move_Image_Asm_565(x+m,y+n,36,36,BmpData_90);
		if(x_event==91) move_Image_Asm_565(x+m,y+n,36,36,BmpData_91);
		if(x_event==92) move_Image_Asm_565(x+m,y+n,36,36,BmpData_92);
		if(x_event==93) move_Image_Asm_565(x+m,y+n,36,36,BmpData_93);
		if(x_event==94) move_Image_Asm_565(x+m,y+n,36,36,BmpData_94);
		if(x_event==95) move_Image_Asm_565(x+m,y+n,36,36,BmpData_95);
		if(x_event==96) move_Image_Asm_565(x+m,y+n,36,36,BmpData_96);
		if(x_event==97) move_Image_Asm_565(x+m,y+n,36,36,BmpData_97);
		if(x_event==98) move_Image_Asm_565(x+m,y+n,36,36,BmpData_98);
		if(x_event==99) move_Image_Asm_565(x+m,y+n,36,36,BmpData_99);
		if(x_event==100) move_Image_Asm_565(x+m,y+n,36,36,BmpData_100);
		if(x_event==101) move_Image_Asm_565(x+m,y+n,36,36,BmpData_101);
		if(x_event==102) move_Image_Asm_565(x+m,y+n,36,36,BmpData_102);
		if(x_event==103) move_Image_Asm_565(x+m,y+n,36,36,BmpData_103);
		if(x_event==104) move_Image_Asm_565(x+m,y+n,36,36,BmpData_104);
		if(x_event==105) move_Image_Asm_565(x+m,y+n,36,36,BmpData_105);
		if(x_event==106) move_Image_Asm_565(x+m,y+n,36,36,BmpData_106);
		if(x_event==107) move_Image_Asm_565(x+m,y+n,36,36,BmpData_107);
		if(x_event==108) move_Image_Asm_565(x+m,y+n,36,36,BmpData_108);
	}
}


/**
  * @brief  ���������ָ�����
  * @param  LCN ��ָ
  * @retval ��
  */
void  L_Cover_Note(uint16_t LCN)
{
	uint16_t x=80-20,y=290-64;
	if(LCN==1)
		move_Image_Asm_565(x+107,y+42,36,36,BmpData_06);     //βָ
	if(LCN==2)
		move_Image_Asm_565(x+129,y+88,36,36,BmpData_06);     //����ָ
	if(LCN==3)
		move_Image_Asm_565(x+147,y+130,36,36,BmpData_06);    //��ָ
	if(LCN==4)
		move_Image_Asm_565(x+131,y+179,36,36,BmpData_06);    //ʳָ
	if(LCN==5)
		move_Image_Asm_565(x+67,y+225,36,36,BmpData_06);    //Ĵָ
}
/**
  * @brief  ���������ָ�����
  * @param  RCN ��ָ
  * @retval ��
  */
void  R_Cover_Note(uint16_t RCN)
{
	uint16_t x=80-20,y=690+62;
	if(RCN==1)
		move_Image_Asm_565(x+67,y+46,36,36,BmpData_06);    //Ĵָ
	if(RCN==2)
		move_Image_Asm_565(x+131,y+93,36,36,BmpData_06);     //ʳָ
	if(RCN==3)
		move_Image_Asm_565(x+147,y+141,36,36,BmpData_06);    //��ָ
	if(RCN==4)
		move_Image_Asm_565(x+129,y+184,36,36,BmpData_06);    //����ָ
	if(RCN==5)
		move_Image_Asm_565(x+107,y+228,36,36,BmpData_06);    //βָ
}

void Show_Fingure()
{
	/******************������*********************/
	 move_Image_Asm_565(740,0,60,1280,BmpData_song_name);  
	/******************����**************************/
	 move_Image_Asm_565(300+219+42-40,0,219,640,BmpData_pu1[0].BmpData_P);
	 move_Image_Asm_565(300+219-40,0,42,640,BmpData_pu2[0].BmpData_P);
	 move_Image_Asm_565(300-40,0,219,640,BmpData_pu3[0].BmpData_P);
	 move_Image_Asm_565(300+219+42-40,640,219,640,BmpData_pu1[1].BmpData_P);
	 move_Image_Asm_565(300+219-40,640,42,640,BmpData_pu2[1].BmpData_P);
	 move_Image_Asm_565(300-40,640,219,640,BmpData_pu3[1].BmpData_P);
   DrawFullRect(300-40,0,480,30,LCD_COLOR1555_GREY);      //���ɫ�� 
	 DrawFullRect(300-40,1250,480,30,LCD_COLOR1555_GREY);  //�ұ�ɫ�� 
}

void Show_Fingure1()
{
	/**************��ʾ������****************/		
	move_Image_Asm_565(80-20,290-64,200,300,BmpData_Lefthand);   //����ָ��
	move_Image_Asm_565(80-20,690+62,200,300,BmpData_Righthand);  //����ָ��
	/*********** **����ָ********************/
	move_Image_Asm_565(85-20,497-64,57,73,BmpData_L1a);      //Ĵָ
	move_Image_Asm_565(147-20,463-64,100,48,BmpData_L2a);    //ʳָ
	move_Image_Asm_565(155-20,421-64,108,34,BmpData_L3a);    //��ָ
	move_Image_Asm_565(152-20,377-64,94,38,BmpData_L4a);     //����ָ
	move_Image_Asm_565(130-20,329-64,72,45,BmpData_L5a);     //βָ
	/********************����ָ************************/
	move_Image_Asm_565(85-20,719+62,57,73,BmpData_R1a);      //Ĵָ
	move_Image_Asm_565(147-20,777+62,100,48,BmpData_R2a);    //ʳָ
	move_Image_Asm_565(155-20,832+62,108,34,BmpData_R3a);    //��ָ
	move_Image_Asm_565(152-20,873+62,94,38,BmpData_R4a);    //����ָ
	move_Image_Asm_565(130-20,914+62,72,45,BmpData_R5a);    //βָ
//	/******************ͼ��*********************/
//	move_Image_Asm_565(0,0,60,1280,BmpData_Icon);

//	if(Lyrics_Song_Switch_Flag == 0)
//  {
//     move_Image_Asm_565(8,974,41,48,BmpData_qu);                //�����ٴ�ѡ�������ģʽ	
//	}
//  else		
//  {
//     move_Image_Asm_565(8,974,41,48,BmpData_ci);                //�����ٴ�ѡ������ģʽ	
//	}	
}

void Show_Fingure_For_Ci_or_Qu()
{  
	/******************����**************************/
	 move_Image_Asm_565(260,0,219,640,BmpData_pu3[0].BmpData_P);
	 move_Image_Asm_565(260,640,219,640,BmpData_pu3[1].BmpData_P);
   DrawFullRect(260,0,480,30,LCD_COLOR1555_GREY);      //���ɫ�� 
	 DrawFullRect(260,1250,480,30,LCD_COLOR1555_GREY);  //�ұ�ɫ�� 
}
