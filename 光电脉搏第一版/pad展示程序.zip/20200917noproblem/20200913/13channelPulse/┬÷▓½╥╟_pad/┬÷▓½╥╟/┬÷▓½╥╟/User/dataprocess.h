#ifndef __DATAPROCESS_H
#define __DATAPROCESS_H
#include "stm32f4xx.h"
#include "ff.h"

extern int select_rank;//ѡ��ǰselect_rank��ͨ��
extern int count5;//ѡȡ��KB�����ݽ��м�������

void read_File_channel_1();
void read_File_channel_2();
void read_File_channel_3();
void read_File_channel_4();
unsigned long HextoDec(char* hex, int length);
void draw_1(int*);
void draw_2(int*);
void draw_3(int*);
void draw_4(int*);
void clear_read_File_channel_1();
void clear_read_File_channel_2();
void clear_read_File_channel_3();
void clear_read_File_channel_4();

void read_File_channel_cal();
void sigProcess_1();
void sigProcess_2();
void sigProcess_3();
void sigProcess_4();
//void ADCWaveformDisp_MainLoop(void);
//void Read_file_Display();
#endif