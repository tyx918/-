
#ifndef __timer3_h__
#define __timer3_h__
#include "stm32f4xx.h"


void TIM2_Configuration(void);



#endif 


