﻿#ifndef COMMON_H
#define COMMON_H



#define MAX_CLIENT_COUNT      2  //最大客户端数目



#endif // COMMON_H
