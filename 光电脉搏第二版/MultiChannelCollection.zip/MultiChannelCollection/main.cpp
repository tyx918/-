﻿#include "multichannel.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MultiChannel w;//执行默认构造函数
    w.show();

    a.exec();//等待事件发生
    return 0;
}
