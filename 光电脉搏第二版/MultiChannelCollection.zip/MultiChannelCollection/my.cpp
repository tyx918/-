#include "my.h"

my::my(QWidget *parent) : QWidget(parent)
{

}
