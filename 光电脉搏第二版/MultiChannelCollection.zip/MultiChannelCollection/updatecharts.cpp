﻿#include "updatecharts.h"

int a[8]={0,0,0,0,0,0,0,0};
//extern int getAdChannel();
extern MultiChannel *bb;
updateCharts::updateCharts(QThread  *parent) : QThread (parent)
  ,runState(false),runSpeed(1000),KBcount(0),cc(0),sequence(0),n(0)
{
    tWidget = new timeWidget;
    //multiChannel = new MultiChannel;
    currentReadNums = 0;
   // Charts = new updateCharts();
    connect(tWidget,&timeWidget::plotState,this,&updateCharts::stateChange);//start or stop
    connect(tWidget,&timeWidget::plotSpeed,this,&updateCharts::speedChange);
    connect(tWidget,&timeWidget::signalPlayFile,this,&updateCharts::startPlotFile);//若选项卡控件在timewidget这个对象中发出信号xx，则当前对象转到updatecharts的槽中
    connect(this,&updateCharts::signalCurrentPlayState,tWidget,&timeWidget::updatePlayState);
    //connect(multiChannel,&MultiChannel::channelNums,this,&updateCharts::getChannels);
}

updateCharts::~updateCharts()
{
    delete tWidget;
    requestInterruption();
    quit();
    wait();
}

void updateCharts::startPlotFile(QString fName)//timechartplot中选择文件后的槽函数
{
   qDebug() << "进入文件显示槽";
   currentReadNums = 0;
   tWidget->timeChart->clearTimeChart();//清除坐标轴上的波形
    if(fName =="Cancel") //取消播放操作
    {
        requestInterruption();
        quit();
        wait();
        KBcount=0;
        emit signalCurrentPlayState("");
        return;
    }
        selectedChannelNums = bb->getAdChannel();
        //qDebug()<<"selectedChannelNums: "<<selectedChannelNums;
        ///若传来的是文件名
        fileName = fName;
        rFile = new QFile(fileName);
        if(!rFile->isOpen())//若该文件未曾打开
           rFile->open(QIODevice::ReadOnly);//打开
        fileSize = rFile->size();//获取其大小
        qDebug() << fileSize/1024 << "kB";
        //stopNums = fileSize /3456;
        //stopNums = (fileSize-1024-24*4992) /4992;
        stopNums = (fileSize-1024-4992) /4992;
        if (this->isRunning())//若该文件正在播放中
        {
            this->wait();  //等待
        }
        //判断序列号
        QString head = rFile->read(1024).toHex();//读取帧头
//        qDebug()<< head;
        QString medium = head.mid(6,2);//获取通道选择数目
        sequence = medium.toInt();
        switch (sequence) {
        case 0:
            cc = 8;
        break;
        case 1:
            cc = 1;
        break;
        case 2:
            cc = 2;
        break;
        case 3:
            cc = 3;
        break;
        case 4:
            cc = 4;
        break;
        case 5:
            cc = 5;
        break;
        case 6:
            cc = 6;
        break;
        case 7:
            cc = 7;
        break;
        case 8:
            cc = 8;
        break;
        case 9:
            cc = 9;
        break;
        case 10:
            cc = 10;
        break;
        case 11:
            cc = 11;
        break;
        case 12:
            cc = 12;
        break;
        case 13:
            cc = 13;
        break;
        default:
            break;
        }
        //qDebug()<< sequence;8通道是2

        //判断哪几通道选通
        rFile->seek(8);//指到第八个字节
        QByteArray byte0 = rFile->read(1);//byte为十六进制字符
        char byte = byte0[0];
        rFile->seek(1024+4992);//跳过1024个字节 + 4992个字节
        n=0;//用来判断有几个通道选通 ， 根据第八通道的数据，存下来的
        for(int i=0;i<8;i++)
            a[i]=0;
        for(int i=0; i<8; i++)
        {
            if(byte&0x01)
            {
                a[i]=1;
                n++;
                byte = byte>>1;
            }
            else
                byte = byte>>1;
        }
//        qDebug()<<"n= "<<n;
//        for(int i=0;i<8;i++)
//          qDebug()<< a[i];

        KBcount=0;//文件大小
        emit signalCurrentPlayState("Played: "+QString::number(KBcount)+"KB");//发出携带字符串的信号，那么槽也要有参数字符串

        this->start();//开启线程
}

void updateCharts::stateChange(bool state,bool getIsRun,int getPlotChannelNums,int mode)
{
        if(mode<=8) {
           plotChannelNums = getPlotChannelNums;
        }
        else if(mode>=9) {
            switch (cc) {
            case 13:
                plotChannelNums = getPlotChannelNums;
                break;
            case 12:
                plotChannelNums = getPlotChannelNums -1;
                break;
            case 11:
                plotChannelNums = getPlotChannelNums - 2;
                break;
            case 10:
                plotChannelNums = getPlotChannelNums - 3;
                break;
            case 9:
                plotChannelNums = getPlotChannelNums - 4;
                break;
            default:
                break;
            }
        }
    isRun = getIsRun;
    runState = state;
}

void updateCharts::speedChange(unsigned long speed)
{
    runSpeed = speed;
}



qreal updateCharts::getValue(QByteArray twoBytes)//每次取2个字节（1个点）画图
{
    if(sequence=='0')
    {
        if(twoBytes[0]&0x0020)//负值  设置为0-2.5
        {
            return (qreal)((((twoBytes[0]&0x001f)<<8)|(twoBytes[1]&0x00ff))/8192.0*2.5);
           //  qDebug()<<(int)(twoBytes[1]&0x001f);
        }
        else
        {
            return (qreal)((((twoBytes[0]&0x001f)<<8)|(twoBytes[1]&0x00ff))/8192.0*2.5+2.5);
        }
    }
    else
    {

        return (qreal)((((twoBytes[1]&0x000f)<<8)|(twoBytes[0]&0x00ff))/4096.0*5);
    }
        //return (qreal)((((twoBytes[0]&0x000f)<<8)|(twoBytes[1]&0x00ff))/4096.0*5);
//    else if (sequence==2)
//         return (qreal)((((twoBytes[1]&0x000f)<<8)|(twoBytes[0]&0x00ff))/4096.0*5);
}

//绘图进程
void updateCharts::run()
{
    qDebug()<<"run";
    QByteArray dataPack;
    QList<qreal> timeYData[13];
    while(!isInterruptionRequested())
    {
      if(KBcount<(fileSize/1024-1))//判断数据是否小于所选文件大小
      {
            while(!runState)//暂停与否（暂停）,由start键决定，一开始为false
            {
                if(isInterruptionRequested())//取消操作
                {
                    rFile->close();
                    return;
                }
            }
           // qDebug()<<"开始绘图";
           // qDebug()<<rFile->pos();
            //1 - 8通道的显示读取
            if(cc<9)
            {
                switch (cc) {
                case 1:
                    dataPack=rFile->read(256);
                    break;
                case 2:
                    dataPack=rFile->read(512);
                    break;
                case 3:
                    dataPack=rFile->read(768);//三个通道应该读取的数据
                    break;
                case 4:
                    dataPack=rFile->read(1024);//四个通道应该读取的数据
                    break;
                case 5:
                    dataPack=rFile->read(1280);
                    break;
                case 6:
                    dataPack=rFile->read(1536);
                    break;
                case 7:
                    dataPack=rFile->read(1792);
                    break;
                case 8:
                    dataPack=rFile->read(2048);
                    break;
                default:
                    break;
                }
                double dataPackSize = dataPack.size();
                for(int j=0;j<128;j++)//2个字节1个点,1个通道128个点（4通道）
                {
                  int p=0;
                  for(int k=0;k<n;k++)//4个通道 , 可变,k应该变
                  {
                      if(a[k])
                      {
                          //qDebug()<<"line205";
                        //！！ timeYData[k] << getValue(dataPack.mid(j*2*n+p*2,2)) + k*5;//mid()返回一个从pos位置开始，包含len（默认值-1）字节
                          timeYData[k] << getValue(dataPack.mid(j*2*n+p*2,2)) + k*5;//mid()返回一个从pos位置开始，包含len（默认值-1）字节
                          //qDebug()<<"timeYData[%d]= "<<k <<timeYData[k];
                          p++;
                      }
                      else
                         timeYData[k]<<k*5;//???
                  }
                }
                KBcount=KBcount + dataPackSize/1024;//文件大小
            }
            //9-13通道的显示读取
            else if(cc>=9)
            {
                //192 * 2 * 通道数
                switch (cc) {
                case 9:
                     dataPack = rFile->read(3456);//192*2*9
                    break;
                case 10:
                     dataPack = rFile->read(3840);
                    break;
                case 11:
                     dataPack = rFile->read(4224);
                    break;
                case 12:
                     dataPack = rFile->read(4608);
                    break;
                case 13:
                     dataPack = rFile->read(4992);//192*2*13
                    break;
                default:
                    break;
                }
                qDebug()<<"plotChannelNums" <<plotChannelNums;
                //dataPack = rFile->read(4992);//160k-1k帧头=159k整除3k
                for(int j=0;j<192;j++)//2个字节1个点,1个通道192个点（8通道）
                {
                  for(int k=0;k<plotChannelNums;k++)//8个通道
                    {
                      if(plotChannelNums<=5) {
                          //qDebug()<<"读取的数据"<<dataPack.mid(j*2*13+k*2+16,2).toHex();
                          timeYData[k] << getValue(dataPack.mid(j*2*cc+k*2+16,2)) + k*5;//mid()返回一个从pos位置开始，包含len（默认值-1）字节

                      }
                      else if(plotChannelNums==8) {
                          timeYData[k] << getValue(dataPack.mid(j*2*cc+k*2,2)) + k*5;
                      }
                      //qDebug()<<"timeYData "<< k  <<  timeYData[k];
                    }
                }
                currentReadNums++;
                KBcount+=3.0;
                if(currentReadNums == stopNums) {
                    //rFile->close();
                    KBcount=0;
                    currentReadNums = 0;
                    emit signalCurrentPlayState("Completed.");
                    runState=false;
                    rFile->seek(1024+4992);
                    if(!isRun) {
                        qDebug()<<"line22";
                        rFile->close();
                        this->requestInterruption();
                        this->quit();
                    }
                }
            }
            //tWidget->timeChart->updateTimeChart(timeYData,cc,a);//绘制波形（8个数组数据）
            if(cc >=9) {
               tWidget->timeChart->updateTimeChart(timeYData,plotChannelNums,a,cc);//绘制波形（8个数组数据）
            }else {
               tWidget->timeChart->updateTimeChart(timeYData,cc,a,cc);//绘制波形（8个数组数据）
            }
            //tWidget->timeChart->updateTimeChart(timeYData,plotChannelNums,a);//绘制波形（8个数组数据）

            msleep(runSpeed);//设置绘制速度
            for(int l=0;l<13;l++)
                timeYData[l].clear();//删除赋给列表的数据
            emit signalCurrentPlayState("Played: "+QString::number(KBcount)+"KB");//绘制完1KB数据就显示在右上角
      }
      else
      {
            qDebug()<<"read done";
            qDebug()<<rFile->pos();
            rFile->close();
            KBcount=0;

            emit signalCurrentPlayState("Completed.");
            runState=false;
            this->requestInterruption();
            this->quit();
        }
   }
}


