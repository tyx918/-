/****************************************************************************
** Meta object code from reading C++ file 'timechartplot.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../timechartplot.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'timechartplot.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_timeChartPlot_t {
    QByteArrayData data[4];
    char stringdata0[39];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_timeChartPlot_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_timeChartPlot_t qt_meta_stringdata_timeChartPlot = {
    {
QT_MOC_LITERAL(0, 0, 13), // "timeChartPlot"
QT_MOC_LITERAL(1, 14, 13), // "handleTimeout"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 9) // "chartInit"

    },
    "timeChartPlot\0handleTimeout\0\0chartInit"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_timeChartPlot[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   24,    2, 0x08 /* Private */,
       3,    0,   25,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void timeChartPlot::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        timeChartPlot *_t = static_cast<timeChartPlot *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->handleTimeout(); break;
        case 1: _t->chartInit(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject timeChartPlot::staticMetaObject = {
    { &QGraphicsView::staticMetaObject, qt_meta_stringdata_timeChartPlot.data,
      qt_meta_data_timeChartPlot,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *timeChartPlot::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *timeChartPlot::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_timeChartPlot.stringdata0))
        return static_cast<void*>(this);
    return QGraphicsView::qt_metacast(_clname);
}

int timeChartPlot::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGraphicsView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
    return _id;
}
struct qt_meta_stringdata_timeWidget_t {
    QByteArrayData data[22];
    char stringdata0[281];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_timeWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_timeWidget_t qt_meta_stringdata_timeWidget = {
    {
QT_MOC_LITERAL(0, 0, 10), // "timeWidget"
QT_MOC_LITERAL(1, 11, 9), // "plotState"
QT_MOC_LITERAL(2, 21, 0), // ""
QT_MOC_LITERAL(3, 22, 9), // "plotSpeed"
QT_MOC_LITERAL(4, 32, 14), // "signalPlayFile"
QT_MOC_LITERAL(5, 47, 8), // "fileName"
QT_MOC_LITERAL(6, 56, 10), // "initWidget"
QT_MOC_LITERAL(7, 67, 18), // "createTimeScaleBox"
QT_MOC_LITERAL(8, 86, 10), // "QComboBox*"
QT_MOC_LITERAL(9, 97, 17), // "createChSelectBox"
QT_MOC_LITERAL(10, 115, 17), // "createSPSelectBox"
QT_MOC_LITERAL(11, 133, 17), // "createStartButton"
QT_MOC_LITERAL(12, 151, 12), // "QPushButton*"
QT_MOC_LITERAL(13, 164, 16), // "createNextButton"
QT_MOC_LITERAL(14, 181, 16), // "createFileButton"
QT_MOC_LITERAL(15, 198, 11), // "stateChange"
QT_MOC_LITERAL(16, 210, 9), // "nextClick"
QT_MOC_LITERAL(17, 220, 13), // "channelChange"
QT_MOC_LITERAL(18, 234, 5), // "index"
QT_MOC_LITERAL(19, 240, 11), // "speedChange"
QT_MOC_LITERAL(20, 252, 15), // "timeScaleChange"
QT_MOC_LITERAL(21, 268, 12) // "playDataFile"

    },
    "timeWidget\0plotState\0\0plotSpeed\0"
    "signalPlayFile\0fileName\0initWidget\0"
    "createTimeScaleBox\0QComboBox*\0"
    "createChSelectBox\0createSPSelectBox\0"
    "createStartButton\0QPushButton*\0"
    "createNextButton\0createFileButton\0"
    "stateChange\0nextClick\0channelChange\0"
    "index\0speedChange\0timeScaleChange\0"
    "playDataFile"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_timeWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    4,   94,    2, 0x06 /* Public */,
       3,    1,  103,    2, 0x06 /* Public */,
       4,    1,  106,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    0,  109,    2, 0x08 /* Private */,
       7,    0,  110,    2, 0x08 /* Private */,
       9,    0,  111,    2, 0x08 /* Private */,
      10,    0,  112,    2, 0x08 /* Private */,
      11,    0,  113,    2, 0x08 /* Private */,
      13,    0,  114,    2, 0x08 /* Private */,
      14,    0,  115,    2, 0x08 /* Private */,
      15,    0,  116,    2, 0x08 /* Private */,
      16,    0,  117,    2, 0x08 /* Private */,
      17,    1,  118,    2, 0x08 /* Private */,
      19,    1,  121,    2, 0x08 /* Private */,
      20,    1,  124,    2, 0x08 /* Private */,
      21,    0,  127,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool, QMetaType::Int, QMetaType::Int,    2,    2,    2,    2,
    QMetaType::Void, QMetaType::ULong,    2,
    QMetaType::Void, QMetaType::QString,    5,

 // slots: parameters
    QMetaType::Void,
    0x80000000 | 8,
    0x80000000 | 8,
    0x80000000 | 8,
    0x80000000 | 12,
    0x80000000 | 12,
    0x80000000 | 12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   18,
    QMetaType::Void, QMetaType::Int,   18,
    QMetaType::Void, QMetaType::Int,   18,
    QMetaType::Void,

       0        // eod
};

void timeWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        timeWidget *_t = static_cast<timeWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->plotState((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 1: _t->plotSpeed((*reinterpret_cast< ulong(*)>(_a[1]))); break;
        case 2: _t->signalPlayFile((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->initWidget(); break;
        case 4: { QComboBox* _r = _t->createTimeScaleBox();
            if (_a[0]) *reinterpret_cast< QComboBox**>(_a[0]) = std::move(_r); }  break;
        case 5: { QComboBox* _r = _t->createChSelectBox();
            if (_a[0]) *reinterpret_cast< QComboBox**>(_a[0]) = std::move(_r); }  break;
        case 6: { QComboBox* _r = _t->createSPSelectBox();
            if (_a[0]) *reinterpret_cast< QComboBox**>(_a[0]) = std::move(_r); }  break;
        case 7: { QPushButton* _r = _t->createStartButton();
            if (_a[0]) *reinterpret_cast< QPushButton**>(_a[0]) = std::move(_r); }  break;
        case 8: { QPushButton* _r = _t->createNextButton();
            if (_a[0]) *reinterpret_cast< QPushButton**>(_a[0]) = std::move(_r); }  break;
        case 9: { QPushButton* _r = _t->createFileButton();
            if (_a[0]) *reinterpret_cast< QPushButton**>(_a[0]) = std::move(_r); }  break;
        case 10: _t->stateChange(); break;
        case 11: _t->nextClick(); break;
        case 12: _t->channelChange((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->speedChange((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->timeScaleChange((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->playDataFile(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (timeWidget::*_t)(bool , bool , int , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&timeWidget::plotState)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (timeWidget::*_t)(unsigned long );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&timeWidget::plotSpeed)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (timeWidget::*_t)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&timeWidget::signalPlayFile)) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject timeWidget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_timeWidget.data,
      qt_meta_data_timeWidget,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *timeWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *timeWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_timeWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int timeWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 16;
    }
    return _id;
}

// SIGNAL 0
void timeWidget::plotState(bool _t1, bool _t2, int _t3, int _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void timeWidget::plotSpeed(unsigned long _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void timeWidget::signalPlayFile(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
