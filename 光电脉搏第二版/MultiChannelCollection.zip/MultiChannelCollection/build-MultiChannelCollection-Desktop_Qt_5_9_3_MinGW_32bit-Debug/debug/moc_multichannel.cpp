/****************************************************************************
** Meta object code from reading C++ file 'multichannel.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../multichannel.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'multichannel.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MultiChannel_t {
    QByteArrayData data[42];
    char stringdata0[703];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MultiChannel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MultiChannel_t qt_meta_stringdata_MultiChannel = {
    {
QT_MOC_LITERAL(0, 0, 12), // "MultiChannel"
QT_MOC_LITERAL(1, 13, 11), // "channelNums"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 14), // "changeFilePath"
QT_MOC_LITERAL(4, 41, 16), // "slotAddNewClient"
QT_MOC_LITERAL(5, 58, 4), // "qsip"
QT_MOC_LITERAL(6, 63, 5), // "iflag"
QT_MOC_LITERAL(7, 69, 13), // "slotDelClient"
QT_MOC_LITERAL(8, 83, 16), // "UIinitialization"
QT_MOC_LITERAL(9, 100, 8), // "plotInit"
QT_MOC_LITERAL(10, 109, 12), // "fileDealInfo"
QT_MOC_LITERAL(11, 122, 4), // "info"
QT_MOC_LITERAL(12, 127, 9), // "deleteTab"
QT_MOC_LITERAL(13, 137, 5), // "index"
QT_MOC_LITERAL(14, 143, 12), // "adRateChoose"
QT_MOC_LITERAL(15, 156, 15), // "daChannelChoose"
QT_MOC_LITERAL(16, 172, 18), // "on_siglePB_clicked"
QT_MOC_LITERAL(17, 191, 16), // "on_start_clicked"
QT_MOC_LITERAL(18, 208, 17), // "on_sendPB_clicked"
QT_MOC_LITERAL(19, 226, 18), // "on_multiPB_clicked"
QT_MOC_LITERAL(20, 245, 18), // "on_startPB_clicked"
QT_MOC_LITERAL(21, 264, 17), // "on_stopPB_clicked"
QT_MOC_LITERAL(22, 282, 18), // "on_resetPB_clicked"
QT_MOC_LITERAL(23, 301, 19), // "on_sendFile_clicked"
QT_MOC_LITERAL(24, 321, 20), // "on_multiPB_2_clicked"
QT_MOC_LITERAL(25, 342, 19), // "on_upSensor_clicked"
QT_MOC_LITERAL(26, 362, 20), // "on_upHistory_clicked"
QT_MOC_LITERAL(27, 383, 30), // "on_verticalSlider_valueChanged"
QT_MOC_LITERAL(28, 414, 5), // "value"
QT_MOC_LITERAL(29, 420, 32), // "on_horizontalSlider_valueChanged"
QT_MOC_LITERAL(30, 453, 15), // "on_Stop_clicked"
QT_MOC_LITERAL(31, 469, 29), // "on_doubleSpinBox_valueChanged"
QT_MOC_LITERAL(32, 499, 4), // "arg1"
QT_MOC_LITERAL(33, 504, 31), // "on_doubleSpinBox_2_valueChanged"
QT_MOC_LITERAL(34, 536, 17), // "on_adSure_clicked"
QT_MOC_LITERAL(35, 554, 17), // "on_daSure_clicked"
QT_MOC_LITERAL(36, 572, 18), // "on_setPath_clicked"
QT_MOC_LITERAL(37, 591, 28), // "on_adNum_currentIndexChanged"
QT_MOC_LITERAL(38, 620, 18), // "on_adNum_activated"
QT_MOC_LITERAL(39, 639, 21), // "on_clearInfor_clicked"
QT_MOC_LITERAL(40, 661, 21), // "on_groupBox_2_clicked"
QT_MOC_LITERAL(41, 683, 19) // "on_sendTime_clicked"

    },
    "MultiChannel\0channelNums\0\0changeFilePath\0"
    "slotAddNewClient\0qsip\0iflag\0slotDelClient\0"
    "UIinitialization\0plotInit\0fileDealInfo\0"
    "info\0deleteTab\0index\0adRateChoose\0"
    "daChannelChoose\0on_siglePB_clicked\0"
    "on_start_clicked\0on_sendPB_clicked\0"
    "on_multiPB_clicked\0on_startPB_clicked\0"
    "on_stopPB_clicked\0on_resetPB_clicked\0"
    "on_sendFile_clicked\0on_multiPB_2_clicked\0"
    "on_upSensor_clicked\0on_upHistory_clicked\0"
    "on_verticalSlider_valueChanged\0value\0"
    "on_horizontalSlider_valueChanged\0"
    "on_Stop_clicked\0on_doubleSpinBox_valueChanged\0"
    "arg1\0on_doubleSpinBox_2_valueChanged\0"
    "on_adSure_clicked\0on_daSure_clicked\0"
    "on_setPath_clicked\0on_adNum_currentIndexChanged\0"
    "on_adNum_activated\0on_clearInfor_clicked\0"
    "on_groupBox_2_clicked\0on_sendTime_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MultiChannel[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      34,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  184,    2, 0x06 /* Public */,
       3,    1,  187,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    2,  190,    2, 0x08 /* Private */,
       7,    1,  195,    2, 0x08 /* Private */,
       8,    0,  198,    2, 0x08 /* Private */,
       9,    0,  199,    2, 0x08 /* Private */,
      10,    1,  200,    2, 0x08 /* Private */,
      12,    1,  203,    2, 0x08 /* Private */,
      14,    0,  206,    2, 0x08 /* Private */,
      15,    0,  207,    2, 0x08 /* Private */,
      16,    0,  208,    2, 0x08 /* Private */,
      17,    0,  209,    2, 0x08 /* Private */,
      18,    0,  210,    2, 0x08 /* Private */,
      19,    0,  211,    2, 0x08 /* Private */,
      20,    0,  212,    2, 0x08 /* Private */,
      21,    0,  213,    2, 0x08 /* Private */,
      22,    0,  214,    2, 0x08 /* Private */,
      23,    0,  215,    2, 0x08 /* Private */,
      24,    0,  216,    2, 0x08 /* Private */,
      25,    0,  217,    2, 0x08 /* Private */,
      26,    0,  218,    2, 0x08 /* Private */,
      27,    1,  219,    2, 0x08 /* Private */,
      29,    1,  222,    2, 0x08 /* Private */,
      30,    0,  225,    2, 0x08 /* Private */,
      31,    1,  226,    2, 0x08 /* Private */,
      33,    1,  229,    2, 0x08 /* Private */,
      34,    0,  232,    2, 0x08 /* Private */,
      35,    0,  233,    2, 0x08 /* Private */,
      36,    0,  234,    2, 0x08 /* Private */,
      37,    1,  235,    2, 0x08 /* Private */,
      38,    1,  238,    2, 0x08 /* Private */,
      39,    0,  241,    2, 0x08 /* Private */,
      40,    0,  242,    2, 0x08 /* Private */,
      41,    0,  243,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QString,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    5,    6,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   11,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   28,
    QMetaType::Void, QMetaType::Int,   28,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double,   32,
    QMetaType::Void, QMetaType::Double,   32,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   32,
    QMetaType::Void, QMetaType::QString,   32,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MultiChannel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MultiChannel *_t = static_cast<MultiChannel *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->channelNums((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->changeFilePath((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->slotAddNewClient((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 3: _t->slotDelClient((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->UIinitialization(); break;
        case 5: _t->plotInit(); break;
        case 6: _t->fileDealInfo((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->deleteTab((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->adRateChoose(); break;
        case 9: _t->daChannelChoose(); break;
        case 10: _t->on_siglePB_clicked(); break;
        case 11: _t->on_start_clicked(); break;
        case 12: _t->on_sendPB_clicked(); break;
        case 13: _t->on_multiPB_clicked(); break;
        case 14: _t->on_startPB_clicked(); break;
        case 15: _t->on_stopPB_clicked(); break;
        case 16: _t->on_resetPB_clicked(); break;
        case 17: _t->on_sendFile_clicked(); break;
        case 18: _t->on_multiPB_2_clicked(); break;
        case 19: _t->on_upSensor_clicked(); break;
        case 20: _t->on_upHistory_clicked(); break;
        case 21: _t->on_verticalSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 22: _t->on_horizontalSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 23: _t->on_Stop_clicked(); break;
        case 24: _t->on_doubleSpinBox_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 25: _t->on_doubleSpinBox_2_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 26: _t->on_adSure_clicked(); break;
        case 27: _t->on_daSure_clicked(); break;
        case 28: _t->on_setPath_clicked(); break;
        case 29: _t->on_adNum_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 30: _t->on_adNum_activated((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 31: _t->on_clearInfor_clicked(); break;
        case 32: _t->on_groupBox_2_clicked(); break;
        case 33: _t->on_sendTime_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (MultiChannel::*_t)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MultiChannel::channelNums)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (MultiChannel::*_t)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MultiChannel::changeFilePath)) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject MultiChannel::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_MultiChannel.data,
      qt_meta_data_MultiChannel,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MultiChannel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MultiChannel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MultiChannel.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int MultiChannel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 34)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 34;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 34)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 34;
    }
    return _id;
}

// SIGNAL 0
void MultiChannel::channelNums(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MultiChannel::changeFilePath(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
