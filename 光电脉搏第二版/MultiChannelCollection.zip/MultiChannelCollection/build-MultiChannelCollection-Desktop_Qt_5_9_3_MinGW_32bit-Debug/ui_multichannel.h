/********************************************************************************
** Form generated from reading UI file 'multichannel.ui'
**
** Created by: Qt User Interface Compiler version 5.9.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MULTICHANNEL_H
#define UI_MULTICHANNEL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MultiChannel
{
public:
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label_4;
    QLineEdit *portEdit;
    QPushButton *start;
    QSpacerItem *horizontalSpacer_4;
    QLabel *label_30;
    QLineEdit *currentPath;
    QPushButton *setPath;
    QTabWidget *tabWidget_3;
    QWidget *configure;
    QGroupBox *groupBox_2;
    QPushButton *upSensor;
    QPushButton *upHistory;
    QPushButton *siglePB;
    QPushButton *multiPB;
    QPushButton *resetPB;
    QPushButton *multiPB_2;
    QLineEdit *files;
    QLineEdit *folders;
    QGroupBox *groupBox_3;
    QComboBox *adNum;
    QLabel *label_8;
    QCheckBox *adC1;
    QCheckBox *adC3;
    QCheckBox *adC7;
    QCheckBox *adC4;
    QComboBox *adRate;
    QCheckBox *adC8;
    QCheckBox *adC5;
    QPushButton *adSure;
    QCheckBox *adC6;
    QCheckBox *adC2;
    QLabel *label_10;
    QPushButton *pushButton_2;
    QLabel *tip;
    QCheckBox *adC9;
    QCheckBox *adC10;
    QCheckBox *adC11;
    QCheckBox *adC12;
    QCheckBox *adC13;
    QPushButton *sendTime;
    QCheckBox *light1;
    QCheckBox *light2;
    QGroupBox *groupBox_4;
    QLabel *label_2;
    QComboBox *daRate;
    QLabel *label_9;
    QCheckBox *daC1;
    QCheckBox *daC3;
    QCheckBox *daC7;
    QCheckBox *daC4;
    QCheckBox *daC8;
    QCheckBox *daC5;
    QPushButton *daSure;
    QCheckBox *daC2;
    QCheckBox *daC6;
    QPushButton *stopPB;
    QPushButton *startPB;
    QCheckBox *sigleCheck;
    QCheckBox *mutiCheck;
    QWidget *motorCtrl;
    QGroupBox *groupBox;
    QSlider *horizontalSlider;
    QLabel *label_43;
    QPushButton *Stop;
    QLabel *label_46;
    QLabel *label_44;
    QLabel *label_vspeed;
    QSlider *verticalSlider;
    QDoubleSpinBox *doubleSpinBox;
    QLabel *label_hspeed;
    QDoubleSpinBox *doubleSpinBox_2;
    QLabel *label_45;
    QTabWidget *tabWidget;
    QTextBrowser *infoShow;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QPushButton *sendPB;
    QCheckBox *hexCheck;
    QPushButton *sendFile;
    QLineEdit *sendText;
    QPushButton *clearInfor;

    void setupUi(QWidget *MultiChannel)
    {
        if (MultiChannel->objectName().isEmpty())
            MultiChannel->setObjectName(QStringLiteral("MultiChannel"));
        MultiChannel->resize(1366, 768);
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MultiChannel->sizePolicy().hasHeightForWidth());
        MultiChannel->setSizePolicy(sizePolicy);
        MultiChannel->setMinimumSize(QSize(1366, 768));
        MultiChannel->setMaximumSize(QSize(1366, 768));
        horizontalLayoutWidget = new QWidget(MultiChannel);
        horizontalLayoutWidget->setObjectName(QStringLiteral("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(10, 10, 1351, 32));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(horizontalLayoutWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setStyleSheet(QString::fromUtf8("font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
""));

        horizontalLayout->addWidget(label_4);

        portEdit = new QLineEdit(horizontalLayoutWidget);
        portEdit->setObjectName(QStringLiteral("portEdit"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Maximum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(portEdit->sizePolicy().hasHeightForWidth());
        portEdit->setSizePolicy(sizePolicy1);
        portEdit->setMaximumSize(QSize(100, 16777215));
        portEdit->setStyleSheet(QString::fromUtf8("font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: rgb(60, 68, 106);\n"
"\n"
"background-color: rgb(255, 255, 255);"));

        horizontalLayout->addWidget(portEdit);

        start = new QPushButton(horizontalLayoutWidget);
        start->setObjectName(QStringLiteral("start"));
        start->setMinimumSize(QSize(50, 0));
        start->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"background-color:rgb(218, 223, 237);                                       \n"
"\n"
"	\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::hover\n"
"{ /*\351\274\240\346\240\207\346\202\254\345\201\234\345\234\250\346\214\211\351\222\256\344\270\212\346\227\266*/\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black;\n"
" background-color: rgb(255, 255, 255);\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::pressed\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black; \n"
"border:1px groove black; \n"
"	background-color: rgb(201, 206, 218);\n"
"border-style: outset;\n"
"}\n"
"\n"
"                   "));

        horizontalLayout->addWidget(start);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_4);

        label_30 = new QLabel(horizontalLayoutWidget);
        label_30->setObjectName(QStringLiteral("label_30"));
        label_30->setStyleSheet(QString::fromUtf8("font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
""));

        horizontalLayout->addWidget(label_30);

        currentPath = new QLineEdit(horizontalLayoutWidget);
        currentPath->setObjectName(QStringLiteral("currentPath"));
        currentPath->setStyleSheet(QString::fromUtf8("font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"background-color: rgb(255, 255, 255);\n"
"color: rgb(60, 68, 106);\n"
""));

        horizontalLayout->addWidget(currentPath);

        setPath = new QPushButton(horizontalLayoutWidget);
        setPath->setObjectName(QStringLiteral("setPath"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(setPath->sizePolicy().hasHeightForWidth());
        setPath->setSizePolicy(sizePolicy2);
        setPath->setMinimumSize(QSize(150, 0));
        setPath->setMaximumSize(QSize(200, 16777215));
        setPath->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"background-color:rgb(218, 223, 237);                                       \n"
"\n"
"	\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::hover\n"
"{ /*\351\274\240\346\240\207\346\202\254\345\201\234\345\234\250\346\214\211\351\222\256\344\270\212\346\227\266*/\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black;\n"
" background-color: rgb(255, 255, 255);\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::pressed\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black; \n"
"border:1px groove black; \n"
"	background-color: rgb(201, 206, 218);\n"
"border-style: outset;\n"
"}\n"
"\n"
"                   "));

        horizontalLayout->addWidget(setPath);

        tabWidget_3 = new QTabWidget(MultiChannel);
        tabWidget_3->setObjectName(QStringLiteral("tabWidget_3"));
        tabWidget_3->setGeometry(QRect(10, 100, 461, 351));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font.setPointSize(11);
        tabWidget_3->setFont(font);
        tabWidget_3->setStyleSheet(QString::fromUtf8("font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"background-color: rgb(255, 255, 255);"));
        tabWidget_3->setTabShape(QTabWidget::Triangular);
        configure = new QWidget();
        configure->setObjectName(QStringLiteral("configure"));
        groupBox_2 = new QGroupBox(configure);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(10, 10, 441, 311));
        upSensor = new QPushButton(groupBox_2);
        upSensor->setObjectName(QStringLiteral("upSensor"));
        upSensor->setGeometry(QRect(210, 250, 111, 21));
        upSensor->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"background-color:rgb(218, 223, 237);                                       \n"
"\n"
"	\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::hover\n"
"{ /*\351\274\240\346\240\207\346\202\254\345\201\234\345\234\250\346\214\211\351\222\256\344\270\212\346\227\266*/\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black;\n"
" background-color: rgb(255, 255, 255);\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::pressed\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black; \n"
"border:1px groove black; \n"
"	background-color: rgb(201, 206, 218);\n"
"border-style: outset;\n"
"}\n"
"\n"
"                   "));
        upHistory = new QPushButton(groupBox_2);
        upHistory->setObjectName(QStringLiteral("upHistory"));
        upHistory->setGeometry(QRect(90, 250, 111, 21));
        upHistory->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"background-color:rgb(218, 223, 237);                                       \n"
"\n"
"	\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::hover\n"
"{ /*\351\274\240\346\240\207\346\202\254\345\201\234\345\234\250\346\214\211\351\222\256\344\270\212\346\227\266*/\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black;\n"
" background-color: rgb(255, 255, 255);\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::pressed\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black; \n"
"border:1px groove black; \n"
"	background-color: rgb(201, 206, 218);\n"
"border-style: outset;\n"
"}\n"
"\n"
"                   "));
        siglePB = new QPushButton(groupBox_2);
        siglePB->setObjectName(QStringLiteral("siglePB"));
        siglePB->setGeometry(QRect(10, 280, 71, 21));
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(siglePB->sizePolicy().hasHeightForWidth());
        siglePB->setSizePolicy(sizePolicy3);
        siglePB->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"background-color:rgb(218, 223, 237);                                       \n"
"\n"
"	\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::hover\n"
"{ /*\351\274\240\346\240\207\346\202\254\345\201\234\345\234\250\346\214\211\351\222\256\344\270\212\346\227\266*/\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black;\n"
" background-color: rgb(255, 255, 255);\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::pressed\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black; \n"
"border:1px groove black; \n"
"	background-color: rgb(201, 206, 218);\n"
"border-style: outset;\n"
"}\n"
"\n"
"                   "));
        multiPB = new QPushButton(groupBox_2);
        multiPB->setObjectName(QStringLiteral("multiPB"));
        multiPB->setGeometry(QRect(151, 280, 109, 21));
        multiPB->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"background-color:rgb(218, 223, 237);                                       \n"
"\n"
"	\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::hover\n"
"{ /*\351\274\240\346\240\207\346\202\254\345\201\234\345\234\250\346\214\211\351\222\256\344\270\212\346\227\266*/\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black;\n"
" background-color: rgb(255, 255, 255);\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::pressed\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black; \n"
"border:1px groove black; \n"
"	background-color: rgb(201, 206, 218);\n"
"border-style: outset;\n"
"}\n"
"\n"
"                   "));
        resetPB = new QPushButton(groupBox_2);
        resetPB->setObjectName(QStringLiteral("resetPB"));
        resetPB->setGeometry(QRect(10, 250, 71, 21));
        resetPB->setMinimumSize(QSize(30, 0));
        resetPB->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"background-color:rgb(218, 223, 237);                                       \n"
"\n"
"	\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::hover\n"
"{ /*\351\274\240\346\240\207\346\202\254\345\201\234\345\234\250\346\214\211\351\222\256\344\270\212\346\227\266*/\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black;\n"
" background-color: rgb(255, 255, 255);\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::pressed\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black; \n"
"border:1px groove black; \n"
"	background-color: rgb(201, 206, 218);\n"
"border-style: outset;\n"
"}\n"
"\n"
"                   "));
        multiPB_2 = new QPushButton(groupBox_2);
        multiPB_2->setObjectName(QStringLiteral("multiPB_2"));
        multiPB_2->setGeometry(QRect(326, 280, 109, 21));
        multiPB_2->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"background-color:rgb(218, 223, 237);                                       \n"
"\n"
"	\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::hover\n"
"{ /*\351\274\240\346\240\207\346\202\254\345\201\234\345\234\250\346\214\211\351\222\256\344\270\212\346\227\266*/\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black;\n"
" background-color: rgb(255, 255, 255);\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::pressed\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black; \n"
"border:1px groove black; \n"
"	background-color: rgb(201, 206, 218);\n"
"border-style: outset;\n"
"}\n"
"\n"
"                   "));
        files = new QLineEdit(groupBox_2);
        files->setObjectName(QStringLiteral("files"));
        files->setGeometry(QRect(390, 250, 47, 21));
        files->setStyleSheet(QString::fromUtf8("font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: rgb(60, 68, 106);\n"
"\n"
"background-color: rgb(255, 255, 255);"));
        folders = new QLineEdit(groupBox_2);
        folders->setObjectName(QStringLiteral("folders"));
        folders->setGeometry(QRect(335, 250, 47, 21));
        folders->setStyleSheet(QString::fromUtf8("font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: rgb(60, 68, 106);\n"
"\n"
"background-color: rgb(255, 255, 255);"));
        groupBox_3 = new QGroupBox(groupBox_2);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(10, 10, 221, 231));
        adNum = new QComboBox(groupBox_3);
        adNum->setObjectName(QStringLiteral("adNum"));
        adNum->setGeometry(QRect(100, 10, 91, 22));
        label_8 = new QLabel(groupBox_3);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(10, 50, 81, 16));
        adC1 = new QCheckBox(groupBox_3);
        adC1->setObjectName(QStringLiteral("adC1"));
        adC1->setGeometry(QRect(20, 80, 31, 16));
        adC3 = new QCheckBox(groupBox_3);
        adC3->setObjectName(QStringLiteral("adC3"));
        adC3->setGeometry(QRect(110, 80, 41, 16));
        adC7 = new QCheckBox(groupBox_3);
        adC7->setObjectName(QStringLiteral("adC7"));
        adC7->setGeometry(QRect(160, 110, 41, 16));
        adC4 = new QCheckBox(groupBox_3);
        adC4->setObjectName(QStringLiteral("adC4"));
        adC4->setGeometry(QRect(160, 80, 41, 16));
        adRate = new QComboBox(groupBox_3);
        adRate->setObjectName(QStringLiteral("adRate"));
        adRate->setGeometry(QRect(100, 50, 91, 22));
        adC8 = new QCheckBox(groupBox_3);
        adC8->setObjectName(QStringLiteral("adC8"));
        adC8->setGeometry(QRect(110, 110, 41, 16));
        adC5 = new QCheckBox(groupBox_3);
        adC5->setObjectName(QStringLiteral("adC5"));
        adC5->setGeometry(QRect(20, 110, 41, 16));
        adSure = new QPushButton(groupBox_3);
        adSure->setObjectName(QStringLiteral("adSure"));
        adSure->setGeometry(QRect(70, 170, 51, 21));
        adSure->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"background-color:rgb(218, 223, 237);                                       \n"
"\n"
"	\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::hover\n"
"{ /*\351\274\240\346\240\207\346\202\254\345\201\234\345\234\250\346\214\211\351\222\256\344\270\212\346\227\266*/\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black;\n"
" background-color: rgb(255, 255, 255);\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::pressed\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black; \n"
"border:1px groove black; \n"
"	background-color: rgb(201, 206, 218);\n"
"border-style: outset;\n"
"}\n"
"\n"
"                   "));
        adC6 = new QCheckBox(groupBox_3);
        adC6->setObjectName(QStringLiteral("adC6"));
        adC6->setGeometry(QRect(60, 110, 41, 16));
        adC2 = new QCheckBox(groupBox_3);
        adC2->setObjectName(QStringLiteral("adC2"));
        adC2->setGeometry(QRect(60, 80, 41, 16));
        label_10 = new QLabel(groupBox_3);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(10, 10, 81, 21));
        pushButton_2 = new QPushButton(groupBox_3);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(60, 280, 75, 23));
        pushButton_2->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"background-color:rgb(218, 223, 237);                                       \n"
"\n"
"	\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::hover\n"
"{ /*\351\274\240\346\240\207\346\202\254\345\201\234\345\234\250\346\214\211\351\222\256\344\270\212\346\227\266*/\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black;\n"
" background-color: rgb(255, 255, 255);\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::pressed\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black; \n"
"border:1px groove black; \n"
"	background-color: rgb(201, 206, 218);\n"
"border-style: outset;\n"
"}\n"
"\n"
"                   "));
        tip = new QLabel(groupBox_3);
        tip->setObjectName(QStringLiteral("tip"));
        tip->setGeometry(QRect(200, 50, 16, 16));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font1.setPointSize(11);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(50);
        tip->setFont(font1);
        adC9 = new QCheckBox(groupBox_3);
        adC9->setObjectName(QStringLiteral("adC9"));
        adC9->setGeometry(QRect(20, 140, 41, 16));
        adC10 = new QCheckBox(groupBox_3);
        adC10->setObjectName(QStringLiteral("adC10"));
        adC10->setGeometry(QRect(50, 140, 41, 16));
        adC11 = new QCheckBox(groupBox_3);
        adC11->setObjectName(QStringLiteral("adC11"));
        adC11->setGeometry(QRect(90, 140, 41, 16));
        adC12 = new QCheckBox(groupBox_3);
        adC12->setObjectName(QStringLiteral("adC12"));
        adC12->setGeometry(QRect(180, 140, 41, 16));
        adC13 = new QCheckBox(groupBox_3);
        adC13->setObjectName(QStringLiteral("adC13"));
        adC13->setGeometry(QRect(140, 140, 41, 16));
        sendTime = new QPushButton(groupBox_3);
        sendTime->setObjectName(QStringLiteral("sendTime"));
        sendTime->setGeometry(QRect(160, 200, 41, 21));
        sendTime->setCursor(QCursor(Qt::ArrowCursor));
        sendTime->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"background-color:rgb(218, 223, 237);                                       \n"
"\n"
"	\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::hover\n"
"{ /*\351\274\240\346\240\207\346\202\254\345\201\234\345\234\250\346\214\211\351\222\256\344\270\212\346\227\266*/\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black;\n"
" background-color: rgb(255, 255, 255);\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::pressed\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black; \n"
"border:1px groove black; \n"
"	background-color: rgb(201, 206, 218);\n"
"border-style: outset;\n"
"}\n"
"\n"
"                   "));
        light1 = new QCheckBox(groupBox_3);
        light1->setObjectName(QStringLiteral("light1"));
        light1->setGeometry(QRect(50, 200, 41, 16));
        light2 = new QCheckBox(groupBox_3);
        light2->setObjectName(QStringLiteral("light2"));
        light2->setGeometry(QRect(100, 200, 41, 16));
        groupBox_4 = new QGroupBox(groupBox_2);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        groupBox_4->setGeometry(QRect(230, 10, 201, 231));
        label_2 = new QLabel(groupBox_4);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(10, 45, 81, 21));
        daRate = new QComboBox(groupBox_4);
        daRate->setObjectName(QStringLiteral("daRate"));
        daRate->setGeometry(QRect(100, 10, 91, 22));
        label_9 = new QLabel(groupBox_4);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(10, 10, 81, 21));
        daC1 = new QCheckBox(groupBox_4);
        daC1->setObjectName(QStringLiteral("daC1"));
        daC1->setGeometry(QRect(20, 80, 31, 16));
        daC3 = new QCheckBox(groupBox_4);
        daC3->setObjectName(QStringLiteral("daC3"));
        daC3->setGeometry(QRect(110, 80, 41, 16));
        daC7 = new QCheckBox(groupBox_4);
        daC7->setObjectName(QStringLiteral("daC7"));
        daC7->setGeometry(QRect(110, 110, 41, 16));
        daC4 = new QCheckBox(groupBox_4);
        daC4->setObjectName(QStringLiteral("daC4"));
        daC4->setGeometry(QRect(150, 80, 41, 16));
        daC8 = new QCheckBox(groupBox_4);
        daC8->setObjectName(QStringLiteral("daC8"));
        daC8->setGeometry(QRect(150, 110, 41, 16));
        daC5 = new QCheckBox(groupBox_4);
        daC5->setObjectName(QStringLiteral("daC5"));
        daC5->setGeometry(QRect(20, 110, 41, 16));
        daSure = new QPushButton(groupBox_4);
        daSure->setObjectName(QStringLiteral("daSure"));
        daSure->setGeometry(QRect(60, 140, 75, 23));
        daSure->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"background-color:rgb(218, 223, 237);                                       \n"
"\n"
"	\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::hover\n"
"{ /*\351\274\240\346\240\207\346\202\254\345\201\234\345\234\250\346\214\211\351\222\256\344\270\212\346\227\266*/\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black;\n"
" background-color: rgb(255, 255, 255);\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::pressed\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black; \n"
"border:1px groove black; \n"
"	background-color: rgb(201, 206, 218);\n"
"border-style: outset;\n"
"}\n"
"\n"
"                   "));
        daC2 = new QCheckBox(groupBox_4);
        daC2->setObjectName(QStringLiteral("daC2"));
        daC2->setGeometry(QRect(60, 80, 41, 16));
        daC6 = new QCheckBox(groupBox_4);
        daC6->setObjectName(QStringLiteral("daC6"));
        daC6->setGeometry(QRect(60, 110, 41, 16));
        stopPB = new QPushButton(groupBox_4);
        stopPB->setObjectName(QStringLiteral("stopPB"));
        stopPB->setGeometry(QRect(100, 190, 81, 22));
        stopPB->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"background-color:rgb(218, 223, 237);                                       \n"
"\n"
"	\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::hover\n"
"{ /*\351\274\240\346\240\207\346\202\254\345\201\234\345\234\250\346\214\211\351\222\256\344\270\212\346\227\266*/\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black;\n"
" background-color: rgb(255, 255, 255);\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::pressed\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black; \n"
"border:1px groove black; \n"
"	background-color: rgb(201, 206, 218);\n"
"border-style: outset;\n"
"}\n"
"\n"
"                   "));
        startPB = new QPushButton(groupBox_4);
        startPB->setObjectName(QStringLiteral("startPB"));
        startPB->setGeometry(QRect(10, 190, 81, 21));
        startPB->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"background-color:rgb(218, 223, 237);                                       \n"
"\n"
"	\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::hover\n"
"{ /*\351\274\240\346\240\207\346\202\254\345\201\234\345\234\250\346\214\211\351\222\256\344\270\212\346\227\266*/\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black;\n"
" background-color: rgb(255, 255, 255);\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::pressed\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black; \n"
"border:1px groove black; \n"
"	background-color: rgb(201, 206, 218);\n"
"border-style: outset;\n"
"}\n"
"\n"
"                   "));
        sigleCheck = new QCheckBox(groupBox_2);
        sigleCheck->setObjectName(QStringLiteral("sigleCheck"));
        sigleCheck->setGeometry(QRect(85, 280, 58, 21));
        mutiCheck = new QCheckBox(groupBox_2);
        mutiCheck->setObjectName(QStringLiteral("mutiCheck"));
        mutiCheck->setGeometry(QRect(263, 280, 58, 21));
        mutiCheck->setTristate(false);
        tabWidget_3->addTab(configure, QString());
        motorCtrl = new QWidget();
        motorCtrl->setObjectName(QStringLiteral("motorCtrl"));
        groupBox = new QGroupBox(motorCtrl);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(10, 10, 421, 301));
        horizontalSlider = new QSlider(groupBox);
        horizontalSlider->setObjectName(QStringLiteral("horizontalSlider"));
        horizontalSlider->setGeometry(QRect(260, 110, 139, 27));
        horizontalSlider->setMinimumSize(QSize(139, 0));
        horizontalSlider->setMaximumSize(QSize(139, 16777215));
        horizontalSlider->setMinimum(-200);
        horizontalSlider->setMaximum(200);
        horizontalSlider->setOrientation(Qt::Horizontal);
        horizontalSlider->setTickPosition(QSlider::TicksAbove);
        horizontalSlider->setTickInterval(25);
        label_43 = new QLabel(groupBox);
        label_43->setObjectName(QStringLiteral("label_43"));
        label_43->setGeometry(QRect(10, 30, 44, 42));
        label_43->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	font-size:25px\n"
"}"));
        label_43->setTextFormat(Qt::PlainText);
        label_43->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        Stop = new QPushButton(groupBox);
        Stop->setObjectName(QStringLiteral("Stop"));
        Stop->setGeometry(QRect(150, 150, 51, 31));
        Stop->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"background-color:rgb(218, 223, 237);                                       \n"
"\n"
"	\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::hover\n"
"{ /*\351\274\240\346\240\207\346\202\254\345\201\234\345\234\250\346\214\211\351\222\256\344\270\212\346\227\266*/\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black;\n"
" background-color: rgb(255, 255, 255);\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::pressed\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black; \n"
"border:1px groove black; \n"
"	background-color: rgb(201, 206, 218);\n"
"border-style: outset;\n"
"}\n"
"\n"
"                   "));
        label_46 = new QLabel(groupBox);
        label_46->setObjectName(QStringLiteral("label_46"));
        label_46->setGeometry(QRect(350, 70, 44, 42));
        label_46->setMinimumSize(QSize(44, 42));
        label_46->setMaximumSize(QSize(44, 42));
        label_46->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	font-size:25px\n"
"}"));
        label_46->setTextFormat(Qt::PlainText);
        label_46->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_44 = new QLabel(groupBox);
        label_44->setObjectName(QStringLiteral("label_44"));
        label_44->setGeometry(QRect(10, 125, 44, 42));
        label_44->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	font-size:25px\n"
"}"));
        label_44->setTextFormat(Qt::PlainText);
        label_44->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_vspeed = new QLabel(groupBox);
        label_vspeed->setObjectName(QStringLiteral("label_vspeed"));
        label_vspeed->setGeometry(QRect(10, 78, 44, 41));
        verticalSlider = new QSlider(groupBox);
        verticalSlider->setObjectName(QStringLiteral("verticalSlider"));
        verticalSlider->setGeometry(QRect(62, 30, 27, 139));
        verticalSlider->setMinimum(-200);
        verticalSlider->setMaximum(200);
        verticalSlider->setSingleStep(10);
        verticalSlider->setSliderPosition(0);
        verticalSlider->setOrientation(Qt::Vertical);
        verticalSlider->setInvertedAppearance(false);
        verticalSlider->setInvertedControls(false);
        verticalSlider->setTickPosition(QSlider::TicksAbove);
        verticalSlider->setTickInterval(25);
        doubleSpinBox = new QDoubleSpinBox(groupBox);
        doubleSpinBox->setObjectName(QStringLiteral("doubleSpinBox"));
        doubleSpinBox->setGeometry(QRect(110, 230, 61, 24));
        doubleSpinBox->setMouseTracking(true);
        doubleSpinBox->setButtonSymbols(QAbstractSpinBox::UpDownArrows);
        doubleSpinBox->setDecimals(1);
        doubleSpinBox->setMinimum(-100);
        doubleSpinBox->setSingleStep(2.5);
        label_hspeed = new QLabel(groupBox);
        label_hspeed->setObjectName(QStringLiteral("label_hspeed"));
        label_hspeed->setGeometry(QRect(303, 69, 41, 44));
        label_hspeed->setMaximumSize(QSize(44, 16777215));
        doubleSpinBox_2 = new QDoubleSpinBox(groupBox);
        doubleSpinBox_2->setObjectName(QStringLiteral("doubleSpinBox_2"));
        doubleSpinBox_2->setGeometry(QRect(190, 230, 61, 24));
        doubleSpinBox_2->setFocusPolicy(Qt::NoFocus);
        doubleSpinBox_2->setContextMenuPolicy(Qt::NoContextMenu);
        doubleSpinBox_2->setLayoutDirection(Qt::LeftToRight);
        doubleSpinBox_2->setReadOnly(false);
        doubleSpinBox_2->setButtonSymbols(QAbstractSpinBox::UpDownArrows);
        doubleSpinBox_2->setDecimals(1);
        doubleSpinBox_2->setMinimum(-100);
        doubleSpinBox_2->setSingleStep(2.5);
        label_45 = new QLabel(groupBox);
        label_45->setObjectName(QStringLiteral("label_45"));
        label_45->setGeometry(QRect(255, 69, 42, 44));
        label_45->setMinimumSize(QSize(42, 44));
        label_45->setMaximumSize(QSize(42, 44));
        label_45->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	font-size:25px\n"
"}"));
        label_45->setTextFormat(Qt::PlainText);
        label_45->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        tabWidget_3->addTab(motorCtrl, QString());
        tabWidget = new QTabWidget(MultiChannel);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(475, 50, 881, 709));
        tabWidget->setMinimumSize(QSize(750, 600));
        tabWidget->setMaximumSize(QSize(891, 709));
        tabWidget->setStyleSheet(QString::fromUtf8("font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; "));
        infoShow = new QTextBrowser(MultiChannel);
        infoShow->setObjectName(QStringLiteral("infoShow"));
        infoShow->setGeometry(QRect(10, 459, 461, 261));
        sizePolicy.setHeightForWidth(infoShow->sizePolicy().hasHeightForWidth());
        infoShow->setSizePolicy(sizePolicy);
        infoShow->setMaximumSize(QSize(470, 400));
        infoShow->setStyleSheet(QString::fromUtf8("\n"
"font: 10pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"\n"
""));
        layoutWidget = new QWidget(MultiChannel);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 58, 400, 28));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        sendPB = new QPushButton(layoutWidget);
        sendPB->setObjectName(QStringLiteral("sendPB"));
        sendPB->setMinimumSize(QSize(80, 0));
        sendPB->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"background-color:rgb(218, 223, 237);                                       \n"
"\n"
"	\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::hover\n"
"{ /*\351\274\240\346\240\207\346\202\254\345\201\234\345\234\250\346\214\211\351\222\256\344\270\212\346\227\266*/\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black;\n"
" background-color: rgb(255, 255, 255);\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::pressed\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black; \n"
"border:1px groove black; \n"
"	background-color: rgb(201, 206, 218);\n"
"border-style: outset;\n"
"}\n"
"\n"
"                   "));

        gridLayout->addWidget(sendPB, 0, 2, 1, 1);

        hexCheck = new QCheckBox(layoutWidget);
        hexCheck->setObjectName(QStringLiteral("hexCheck"));
        QSizePolicy sizePolicy4(QSizePolicy::Maximum, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(hexCheck->sizePolicy().hasHeightForWidth());
        hexCheck->setSizePolicy(sizePolicy4);
        hexCheck->setStyleSheet(QString::fromUtf8("\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"\n"
""));

        gridLayout->addWidget(hexCheck, 0, 1, 1, 1);

        sendFile = new QPushButton(layoutWidget);
        sendFile->setObjectName(QStringLiteral("sendFile"));
        sendFile->setMinimumSize(QSize(80, 0));
        sendFile->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"background-color:rgb(218, 223, 237);                                       \n"
"\n"
"	\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::hover\n"
"{ /*\351\274\240\346\240\207\346\202\254\345\201\234\345\234\250\346\214\211\351\222\256\344\270\212\346\227\266*/\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black;\n"
" background-color: rgb(255, 255, 255);\n"
"border:1px groove black; \n"
"border-style: outset;\n"
"}\n"
"QPushButton::pressed\n"
"{\n"
"font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: black; \n"
"border:1px groove black; \n"
"	background-color: rgb(201, 206, 218);\n"
"border-style: outset;\n"
"}\n"
"\n"
"                   "));

        gridLayout->addWidget(sendFile, 0, 3, 1, 1);

        sendText = new QLineEdit(layoutWidget);
        sendText->setObjectName(QStringLiteral("sendText"));
        QSizePolicy sizePolicy5(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(sendText->sizePolicy().hasHeightForWidth());
        sendText->setSizePolicy(sizePolicy5);
        sendText->setMinimumSize(QSize(100, 0));
        sendText->setMaximumSize(QSize(16777215, 26));
        sendText->setStyleSheet(QString::fromUtf8("font: 11pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"color: black; \n"
"                                       \n"
""));

        gridLayout->addWidget(sendText, 0, 0, 1, 1);

        clearInfor = new QPushButton(MultiChannel);
        clearInfor->setObjectName(QStringLiteral("clearInfor"));
        clearInfor->setGeometry(QRect(10, 730, 75, 23));

        retranslateUi(MultiChannel);

        tabWidget_3->setCurrentIndex(0);
        tabWidget->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(MultiChannel);
    } // setupUi

    void retranslateUi(QWidget *MultiChannel)
    {
        MultiChannel->setWindowTitle(QApplication::translate("MultiChannel", "MultiChannel", Q_NULLPTR));
        label_4->setText(QApplication::translate("MultiChannel", "\347\253\257\345\217\243:", Q_NULLPTR));
        start->setText(QApplication::translate("MultiChannel", "\345\220\257\345\212\250", Q_NULLPTR));
        label_30->setText(QApplication::translate("MultiChannel", "\345\255\230\345\202\250\350\267\257\345\276\204:", Q_NULLPTR));
        setPath->setText(QApplication::translate("MultiChannel", "\350\256\276\347\275\256 \345\255\230\345\202\250 \345\234\260\345\235\200", Q_NULLPTR));
        groupBox_2->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        upSensor->setToolTip(QApplication::translate("MultiChannel", "<html><head/><body><p><br/></p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_WHATSTHIS
        upSensor->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        upSensor->setText(QApplication::translate("MultiChannel", " \344\270\212\345\217\221\344\274\240\346\204\237\346\225\260\346\215\256", Q_NULLPTR));
        upHistory->setText(QApplication::translate("MultiChannel", "\344\270\212\345\217\221\345\216\206\345\217\262\346\225\260\346\215\256", Q_NULLPTR));
        siglePB->setText(QApplication::translate("MultiChannel", "\345\215\225\345\270\247\346\243\200\346\265\213", Q_NULLPTR));
        multiPB->setText(QApplication::translate("MultiChannel", "\345\274\200\345\247\213\350\277\236\347\273\255\346\243\200\346\265\213", Q_NULLPTR));
        resetPB->setText(QApplication::translate("MultiChannel", "\345\244\215\344\275\215", Q_NULLPTR));
        multiPB_2->setText(QApplication::translate("MultiChannel", "\345\201\234\346\255\242\350\277\236\347\273\255\346\243\200\346\265\213", Q_NULLPTR));
        files->setText(QString());
        groupBox_3->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        adNum->setToolTip(QApplication::translate("MultiChannel", "<html><head/><body><p><span style=\" font-family:'\345\256\213\344\275\223'; font-size:12pt;\">\350\257\264\346\230\216\357\274\232</span></p><p><span style=\" font-family:'\345\256\213\344\275\223'; font-size:12pt;\">\350\277\236\347\273\255\346\250\241\345\274\217\351\207\207\346\240\267\347\202\271\346\225\260\351\234\200\345\260\217\344\272\216SD\345\215\241\345\256\271\351\207\217</span></p><p><span style=\" font-family:'\345\256\213\344\275\223'; font-size:12pt;\">\350\277\236\347\273\255\346\250\241\345\274\217\351\207\207\346\240\267\347\202\271\346\225\260\350\276\203\345\244\247\346\227\266\357\274\214\351\200\211\346\213\251\344\270\212\345\217\221\345\220\216\357\274\214</span></p><p><span style=\" font-family:'\345\256\213\344\275\223'; font-size:12pt;\">\346\225\260\346\215\256\344\274\240\350\276\223\346\227\266\351\227\264\344\274\232\345\276\210\351\225\277</span></p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        label_8->setText(QApplication::translate("MultiChannel", "AD\351\207\207\346\240\267\347\216\207\357\274\232", Q_NULLPTR));
        adC1->setText(QApplication::translate("MultiChannel", "1", Q_NULLPTR));
        adC3->setText(QApplication::translate("MultiChannel", "3", Q_NULLPTR));
        adC7->setText(QApplication::translate("MultiChannel", "7", Q_NULLPTR));
        adC4->setText(QApplication::translate("MultiChannel", "4", Q_NULLPTR));
        adC8->setText(QApplication::translate("MultiChannel", "8", Q_NULLPTR));
        adC5->setText(QApplication::translate("MultiChannel", "5", Q_NULLPTR));
        adSure->setText(QApplication::translate("MultiChannel", "\347\241\256\345\256\232", Q_NULLPTR));
        adC6->setText(QApplication::translate("MultiChannel", "6", Q_NULLPTR));
        adC2->setText(QApplication::translate("MultiChannel", "2", Q_NULLPTR));
        label_10->setText(QApplication::translate("MultiChannel", "AD\351\207\207\346\240\267\347\202\271\357\274\232", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("MultiChannel", "\347\241\256\345\256\232", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        tip->setToolTip(QApplication::translate("MultiChannel", "<html><head/><body><p><span style=\" font-family:'\345\256\213\344\275\223'; font-size:12pt;\">\350\257\264\346\230\216\357\274\232</span></p><p><span style=\" font-family:'\345\256\213\344\275\223'; font-size:12pt;\">\350\277\236\347\273\255\346\250\241\345\274\217\351\207\207\346\240\267\347\202\271\346\225\260\351\234\200\345\260\217\344\272\216SD\345\215\241\345\256\271\351\207\217</span></p><p><span style=\" font-family:'\345\256\213\344\275\223'; font-size:12pt;\">\350\277\236\347\273\255\346\250\241\345\274\217\351\207\207\346\240\267\347\202\271\346\225\260\350\276\203\345\244\247\346\227\266\357\274\214\351\200\211\346\213\251\344\270\212\345\217\221\345\220\216\357\274\214</span></p><p><span style=\" font-family:'\345\256\213\344\275\223'; font-size:12pt;\">\346\225\260\346\215\256\344\274\240\350\276\223\346\227\266\351\227\264\344\274\232\345\276\210\351\225\277</span></p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        tip->setText(QApplication::translate("MultiChannel", "?", Q_NULLPTR));
        adC9->setText(QApplication::translate("MultiChannel", "9", Q_NULLPTR));
        adC10->setText(QApplication::translate("MultiChannel", "10", Q_NULLPTR));
        adC11->setText(QApplication::translate("MultiChannel", "11", Q_NULLPTR));
        adC12->setText(QApplication::translate("MultiChannel", "12", Q_NULLPTR));
        adC13->setText(QApplication::translate("MultiChannel", "13", Q_NULLPTR));
        sendTime->setText(QApplication::translate("MultiChannel", "\347\241\256\345\256\232", Q_NULLPTR));
        light1->setText(QApplication::translate("MultiChannel", "\347\201\2571", Q_NULLPTR));
        light2->setText(QApplication::translate("MultiChannel", "\347\201\2572", Q_NULLPTR));
        groupBox_4->setTitle(QString());
        label_2->setText(QApplication::translate("MultiChannel", "  \351\200\232\351\201\223\351\200\211\346\213\251\357\274\232", Q_NULLPTR));
        label_9->setText(QApplication::translate("MultiChannel", "DA\350\275\254\346\215\242\347\216\207\357\274\232", Q_NULLPTR));
        daC1->setText(QApplication::translate("MultiChannel", "1", Q_NULLPTR));
        daC3->setText(QApplication::translate("MultiChannel", "3", Q_NULLPTR));
        daC7->setText(QApplication::translate("MultiChannel", "7", Q_NULLPTR));
        daC4->setText(QApplication::translate("MultiChannel", "4", Q_NULLPTR));
        daC8->setText(QApplication::translate("MultiChannel", "8", Q_NULLPTR));
        daC5->setText(QApplication::translate("MultiChannel", "5", Q_NULLPTR));
        daSure->setText(QApplication::translate("MultiChannel", "\347\241\256\345\256\232", Q_NULLPTR));
        daC2->setText(QApplication::translate("MultiChannel", "2", Q_NULLPTR));
        daC6->setText(QApplication::translate("MultiChannel", "6", Q_NULLPTR));
        stopPB->setText(QApplication::translate("MultiChannel", "\345\201\234\346\255\242\346\222\255\351\237\263", Q_NULLPTR));
        startPB->setText(QApplication::translate("MultiChannel", "\345\274\200\345\247\213\346\222\255\351\237\263", Q_NULLPTR));
        sigleCheck->setText(QApplication::translate("MultiChannel", "\344\270\212\345\217\221", Q_NULLPTR));
        mutiCheck->setText(QApplication::translate("MultiChannel", "\344\270\212\345\217\221", Q_NULLPTR));
        tabWidget_3->setTabText(tabWidget_3->indexOf(configure), QApplication::translate("MultiChannel", "\351\207\207\351\233\206\345\217\202\346\225\260\350\256\276\347\275\256", Q_NULLPTR));
        groupBox->setTitle(QString());
        label_43->setText(QApplication::translate("MultiChannel", "\342\206\221", Q_NULLPTR));
        Stop->setText(QApplication::translate("MultiChannel", "Stop", Q_NULLPTR));
        label_46->setText(QApplication::translate("MultiChannel", "\342\206\222", Q_NULLPTR));
        label_44->setText(QApplication::translate("MultiChannel", "\342\206\223", Q_NULLPTR));
        label_vspeed->setText(QApplication::translate("MultiChannel", "0.0%", Q_NULLPTR));
        doubleSpinBox->setSuffix(QApplication::translate("MultiChannel", "%", Q_NULLPTR));
        label_hspeed->setText(QApplication::translate("MultiChannel", "0.0%", Q_NULLPTR));
        doubleSpinBox_2->setSuffix(QApplication::translate("MultiChannel", "%", Q_NULLPTR));
        label_45->setText(QApplication::translate("MultiChannel", "\342\206\220", Q_NULLPTR));
        tabWidget_3->setTabText(tabWidget_3->indexOf(motorCtrl), QApplication::translate("MultiChannel", "\347\224\265\346\234\272\346\216\247\345\210\266", Q_NULLPTR));
        sendPB->setText(QApplication::translate("MultiChannel", "\344\270\213\345\217\221\346\214\207\344\273\244", Q_NULLPTR));
        hexCheck->setText(QApplication::translate("MultiChannel", "HEX", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        sendFile->setToolTip(QApplication::translate("MultiChannel", "<html><head/><body><p><span style=\" font-family:'\345\256\213\344\275\223'; font-size:12pt;\">\350\257\264\346\230\216\357\274\232</span></p><p><span style=\" font-family:'\345\256\213\344\275\223'; font-size:12pt;\">\344\270\213\345\217\221\346\226\207\344\273\266\344\270\212\351\231\220\344\270\272**\357\274\214</span></p><p><span style=\" font-family:'\345\256\213\344\275\223'; font-size:12pt;\">\350\213\245\346\211\200\351\234\200\346\226\207\344\273\266\350\266\205\350\277\207\346\255\244\344\270\212\351\231\220\357\274\214</span></p><p><span style=\" font-family:'\345\256\213\344\275\223'; font-size:12pt;\">\347\224\250\346\210\267\350\207\252\350\241\214\345\210\206\345\244\232\344\270\252\346\226\207\344\273\266\344\270\213\345\217\221</span></p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        sendFile->setText(QApplication::translate("MultiChannel", "\344\270\213\345\217\221\346\226\207\344\273\266", Q_NULLPTR));
        clearInfor->setText(QApplication::translate("MultiChannel", " \346\270\205\351\231\244", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MultiChannel: public Ui_MultiChannel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MULTICHANNEL_H
