#ifndef MY_H
#define MY_H

#include <QWidget>

class my : public QWidget
{
    Q_OBJECT
public:
    explicit my(QWidget *parent = nullptr);

signals:


public slots:
};

#endif // MY_H
