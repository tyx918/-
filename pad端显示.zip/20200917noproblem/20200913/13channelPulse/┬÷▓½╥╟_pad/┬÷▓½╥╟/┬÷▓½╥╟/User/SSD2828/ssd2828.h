#ifndef _SSD2828_H_
#define _SSD2828_H_

#include "stm32f4xx.h"

//SSD SPI
#define SSD_SPI_SCLK_H   GPIO_SetBits(GPIOE,GPIO_Pin_2)//PC5
#define SSD_SPI_SCLK_L   GPIO_ResetBits(GPIOE,GPIO_Pin_2)

#define SSD_SPI_SDO_H   GPIO_SetBits(GPIOE,GPIO_Pin_3)//PC6
#define SSD_SPI_SDO_L   GPIO_ResetBits(GPIOE,GPIO_Pin_3)

#define SSD_SPI_CS_H   GPIO_SetBits(GPIOI,GPIO_Pin_6)//SSD2828 CS; PA4
#define SSD_SPI_CS_L   GPIO_ResetBits(GPIOI,GPIO_Pin_6)

//#define SSD_SPI_SDC_H   GPIO_SetBits(GPIOE,GPIO_Pin_3)//SSD2828 SDC ; PC4
//#define SSD_SPI_SDC_L   GPIO_ResetBits(GPIOE,GPIO_Pin_3)


#define SSD_RST_H   GPIO_SetBits(GPIOH,GPIO_Pin_4)//SSD2828 RESET,PD0
#define SSD_RST_L   GPIO_ResetBits(GPIOH,GPIO_Pin_4)

//#define SSD_SHUT_L  GPIO_ResetBits(GPIOD,GPIO_Pin_4)


#define SSD_SPI_SDI   GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_1)//PA7


// 
void SSD2828_GPIO_Initial(void);
void SSD2828_Init3(void);
u8   SPI_READ_ID(void);
u16   SSD2828_READ_Dat(u8 reg);// SSD2828 Read Reg 

void BLJ_LCD_Init(void);

void MTF050HDI(void);// 5.0 �� 720*1280
void MIPI_Read_Init(void);
//--------- DSI Read Driver Data By  MIPI --------------//2006-10-20
u8 RD_DSI_BASICPAs(u8 Num,u8 addr,u8 Page);//LE Max. return packet is 255 bytes;a---reg addr; ye---page 
void LCD_CODE_YQ2(void);
#endif /* __STM8L_GPIO_H */
