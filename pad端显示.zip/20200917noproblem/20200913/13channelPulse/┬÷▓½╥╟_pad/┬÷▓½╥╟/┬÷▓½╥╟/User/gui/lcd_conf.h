#ifndef _LCD_CONF_H_
#define _LCD_CONF_H_

#include "stdio.h"

unsigned int GUI_Read_Point(unsigned short x,unsigned short y);
void GUI_Draw_Point(unsigned short x,unsigned short y,unsigned int color);
void GUI_Rect_Fill(unsigned short x1,unsigned short y1,unsigned short x2,unsigned short y2,unsigned int color);
void GUI_Rect_Color_Fill(unsigned short x1,unsigned short y1,unsigned short x2,unsigned short y2,unsigned short *color);

#endif 
