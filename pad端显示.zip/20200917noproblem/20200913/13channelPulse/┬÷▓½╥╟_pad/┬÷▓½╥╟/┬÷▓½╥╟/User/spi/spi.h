#ifndef __SPI_H
#define __SPI_H
 

/////ģ�� SPI 3�� 
#define  SPI_3CS_H   GPIO_SetBits(GPIOA,  GPIO_Pin_4)    
#define  SPI_3CS_L   GPIO_ResetBits(GPIOA,  GPIO_Pin_4)

#define  SPI_3CLK_H   GPIO_SetBits(GPIOA,  GPIO_Pin_5) 
#define  SPI_3CLK_L   GPIO_ResetBits(GPIOA,  GPIO_Pin_5)

#define  SPI_3SDI_H    GPIO_SetBits(GPIOA,  GPIO_Pin_6) 
#define  SPI_3SDI_L    GPIO_ResetBits(GPIOA,  GPIO_Pin_6)

#define  SPI_3SDO_H   GPIO_SetBits(GPIOA,  GPIO_Pin_7) 
#define  SPI_3SDO_L   GPIO_ResetBits(GPIOA,  GPIO_Pin_7)

#define  SPI_3RES_H   GPIO_SetBits(GPIOB,  GPIO_Pin_12) 
#define  SPI_3RES_L   GPIO_ResetBits(GPIOB,  GPIO_Pin_12)

//#define  LCD_BACK_H   GPIO_SetBits(GPIOA,  GPIO_Pin_11) 
//#define  LCD_BACK_L   GPIO_ResetBits(GPIOA,  GPIO_Pin_11)

/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
//SPI�ӿ�ʱ��

void  MIPI_LCDsize (unsigned int size);

void SPI_3W_SET_Cmd(unsigned char cmd);
void SPI_3W_SET_PAs(unsigned char value);
void SPI_2828_WrCmd(unsigned char cmd);
void SPI_WriteData(unsigned char dat);
void SSD2828_REG_DATA_3L(unsigned char c,unsigned int value);

void SPI_senddata(char dat);


//void SSD2828_init (void);


void init_BOE7_8394C (void);
void int_OTM9605_50 (void);


void LCD_Init(void);




#endif
