#include "./malloc/malloc.h"

////////////////����8ͨ���������ĵ�ַ����//////////////////
char ReadBuffer_13_raw_cal[9*3*1024]__attribute__((at(0xD0200000)));//ԭʼ����
char ReadBuffer_13_process_cal[9*3*1024*2]__attribute__((at(0xD0200000+0x6C00)));//ת���������
int  all_data_cal[13824]__attribute__((at(0xD0200000+0x1B000+0xD800)));
int  channel_1_13_cal[1660]__attribute__((at(0xD0700000)));
int  channel_2_13_cal[1660]__attribute__((at(0xD0700000+1*0x19F0)));
int  channel_3_13_cal[1660]__attribute__((at(0xD0700000+2*0x19F0)));
int  channel_4_13_cal[1660]__attribute__((at(0xD0700000+3*0x19F0)));
int  channel_5_13_cal[1660]__attribute__((at(0xD0700000+4*0x19F0)));
int  channel_6_13_cal[1660]__attribute__((at(0xD0700000+5*0x19F0)));
int  channel_7_13_cal[1660]__attribute__((at(0xD0700000+6*0x19F0)));
int  channel_8_13_cal[1660]__attribute__((at(0xD0700000+7*0x19F0)));
////////////////����4ͨ���������ĵ�ַ����//////////////////
char ReadBuffer_13_raw_cal_4[3*1024]__attribute__((at(0xD0700000+8*0x19F0)));//ԭʼ����
char ReadBuffer_13_process_cal_4[3*1024*2]__attribute__((at(0xD0700000+8*0x19F0+0xC00)));//ת���������
int  all_data_cal_4[1536]__attribute__((at(0xD0700000+8*0x19F0+0xC00+0x1800)));
int  channel_1_13_cal_4[384]__attribute__((at(0xD0700000+8*0x19F0+0xC00+0x1800+0x1800)));
int  channel_2_13_cal_4[384]__attribute__((at(0xD0700000+8*0x19F0+0xC00+0x1800+0x1800+0x600*1)));
int  channel_3_13_cal_4[384]__attribute__((at(0xD0700000+8*0x19F0+0xC00+0x1800+0x1800+0x600*2)));
int  channel_4_13_cal_4[384]__attribute__((at(0xD0700000+8*0x19F0+0xC00+0x1800+0x1800+0x600*3)));


