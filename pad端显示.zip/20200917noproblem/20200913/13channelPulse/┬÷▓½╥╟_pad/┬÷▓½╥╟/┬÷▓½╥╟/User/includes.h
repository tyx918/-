#ifndef __INCLUDES_H
#define	__INCLUDES_H

#include "stm32f4xx.h"
#include "./led/bsp_led.h"
#include "./usart/bsp_debug_usart.h"
#include "./sdram/bsp_sdram.h"
#include "./lcd/bsp_lcd.h"
#include <string.h>
#include "ff.h"
#include "bsp_bmp.h"
#include "./xpt/xpt.h"
#include "shownote.h"
#include <stdio.h>
#include "stm32f4xx_it.h"
#include <stdlib.h>
#include "timer.h"
#include "./systick/bsp_SysTick.h"
//#include "./spi/ssi.h"
#include  "./ssd2828/ssd2828.h"
#include "bsp_GT9271.h"

#include "touch.h"
#include "starts.h"
#include "gui_button.h"
#include "touch_conf.h"
#include "gui_touch.h"
#include "song_select_deal.h"
#include "lcd_conf.h"
#include "gui_touch_deal.h"

#include "./music/musicPlayer.h"
#include "./spi_dma/bsp_spi_dma_comfig.h"
#include "./GPIO/bsp_gpio.h"  
#include "./wm8978/bsp_wm8978.h" 
#include "./433/433.h"
#include "./malloc/malloc.h"
#include "SYSTEM/sys/sys.h"  
#include "SYSTEM/delay/delay.h"

#include "./BTSCAN/btscan.h"

#endif



