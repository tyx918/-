#include "./others/calculate.h"
#include <stdio.h>
#include <math.h>
#include "picture.h"
#include "./malloc/malloc.h"
#include "./lcd/bsp_lcd.h"
#include "ui.h"
#include "./others/show.h"

double sigProcess_13(int* channel_13_ca,int size)
{
     int sum=0;
		 double average = 0.0;
		 //���
     for(int i=0;i<size;i++)
		 {
			  sum+=channel_13_ca[i];
		 }
		 average = sum/1660.0;//ȡƽ��
		 printf("average= %f\r\n",average);
		 //��������
		 double final_sum = 0;
		 double result = 0;
		 for(int j=0;j<size;j++)
		 {
			 final_sum +=((channel_13_ca[j]-average)*(channel_13_ca[j]-average));
		 }
		 printf("final_sum= %f\r\n",final_sum);
		 result = final_sum/1660.0;
		 printf("result= %f\r\n",result);
		 return result;
}

void para_space(int order_channel,int s,int poi){
	printf("poi= %d\r\n",poi);
	if(order_channel==1){
		move_Image_Asm_565(poi,10,27,15,num1+2);
		space_1 = s;
	}
	if(order_channel==2){
		move_Image_Asm_565(poi,10,27,15,num2+2);
		space_2 = s;
	}
	if(order_channel==3){
		move_Image_Asm_565(poi,10,27,15,num3+2);
		space_3 = s;
	}
	if(order_channel==4){
		move_Image_Asm_565(poi,10,27,15,num4+2);
		space_4 = s;
	}
	if(order_channel==5){
		space_5 = s;
		move_Image_Asm_565(poi,10,27,15,num5+2);
	}
	if(order_channel==6){
		space_6 = s;
		move_Image_Asm_565(poi,10,27,15,num6+2);
	}
	if(order_channel==7){
		space_7 = s;
		move_Image_Asm_565(poi,10,27,15,num7+2);
	}
	if(order_channel==8){
		space_8 = s;
		move_Image_Asm_565(poi,10,27,15,num8+2);
	}	
}
//315.0*2-40+10
void show_rank(int num,int posi)
{
	int order_channel = posi;
	switch(num)
	{
		case 0:
		{
      para_space(order_channel,0,630);
		  break;
		}//���ϵ�ͼ�꣬��ʼ
		case 1:
		{
      para_space(order_channel,-80*2,550);
		  break;
		}//���ϵ�ͼ�꣬��ͣ
		case 2:
		{
      para_space(order_channel,-160*2,470);
		  break;
		}
		case 3:
		{
			para_space(order_channel,-240*2,390);
		  break;
		}//���ϵ�ͼ��,�ϴ�  	
		case 4:
		{
			para_space(order_channel,0,310);
		  break;
		}
		case 5:
		{
			para_space(order_channel,-80*2,230);
		  break;
		}
		case 6:
		{
			para_space(order_channel,-160*2,150);
		  break;
		}
		case 7:
		{
			para_space(order_channel,-240*2,70);
		  break;
		} 
		default:
		break;
	}
}

void compare(double power_1,double power_2,double power_3,double power_4,double power_5,double power_6,double power_7,double power_8)
{
	printf("compaer: \r\n");
	double power[8] = {power_1,power_2,power_3,power_4,power_5,power_6,power_7,power_8};
	for(int j =0;j<8;j++)
	{
		 printf("ת��ǰ��power= %f\r\n",power[j]);
	}
	double temp = 0.0;
	//�������С���Ӵ�С
  for(int j=0;j<8;j++){
//				printf("\r\n");
//		printf("%d\r\n",power[j]);
  for(int k=j+1;k<8;k++){
//		printf("%d\r\n",power[k]);
  if(power[j]<power[k])//num[j]<num[k]
	{
   temp=power[j];
   power[j]=power[k];
   power[k]=temp;
   } }
	}
  		for(int k =0;k<8;k++)
	{
		 printf("ת�����power= %f\r\n",power[k]);
	}
	//����
	if(draw==2){
	for(int p =0;p<8;p++)
	{
		if(power[p]==power_1)
		{
			move_Image_Asm_565(u_begin.x,u_begin.y,u_begin.width,u_begin.height,begin_1+2);
 //		  show_rank(p,630);	
      show_rank(p,1);				
		}
		if(power[p]==power_2)
		{
			move_Image_Asm_565(u_stop.x,u_stop.y,u_stop.width,u_stop.height,halt_1+2);
//			show_rank(p,550);
			show_rank(p,2);	
		}
		if(power[p]==power_3)
			{
			move_Image_Asm_565(u_reset.x,u_stop.y,u_reset.width,u_reset.height,reset_1+2);
//			show_rank(p,470);
				show_rank(p,3);	
			}
	  if(power[p]==power_4)
		{
			move_Image_Asm_565(u_upload.x,u_upload.y,u_upload.width,u_upload.height,upload_1+2);
//			show_rank(p,390);
			show_rank(p,4);	
		}
			  if(power[p]==power_5)
		{
			move_Image_Asm_565(u_channel4.x,u_channel4.y,u_channel4.width,u_channel4.height,channel4_1+2);
//			show_rank(p,310);
			show_rank(p,5);	
		}
			  if(power[p]==power_6)
		{
			move_Image_Asm_565(u_heart.x,u_heart.y,u_heart.width,u_heart.height,heart_1+2);
//			show_rank(p,230);
			show_rank(p,6);	
		}
			  if(power[p]==power_7)
		{
			move_Image_Asm_565(u_rec.x,u_rec.y,u_rec.width,u_rec.height,rec_1+2);
//			show_rank(p,150);
			show_rank(p,7);	
		}
			  if(power[p]==power_8)
		{
			 move_Image_Asm_565(u_emit.x,u_emit.y,u_emit.width,u_emit.height,emit_1+2);
//			show_rank(p,70);
			show_rank(p,8);	
		}
	}	
			printf("space_1=%d\r\n,space_2=%d\r\n,space_3=%d\r\n,space_4=%d\r\n,space_5=%d\r\n,space_6=%d\r\n,space_7=%d\r\n,space_8=%d\r\n,",
	space_1,space_2,space_3,space_4,space_5,space_6,space_7,space_8);
}
}