#include  "./ssd2828/ssd2828.h"
#include <stdio.h>
//LCD ��Ƶ��ʾ����������LCD��ͬ����
#define LCD_VBPD		 12  
#define LCD_VFPD	 	 16
#define LCD_VSPW		 4

#define LCD_HBPD		 48
#define LCD_HFPD		 16
#define LCD_HSPW	   	 16

#define LCD_XSIZE_TFT    800 
#define LCD_YSIZE_TFT    1280

#define LCD_RES_H GPIO_SetBits(GPIOG,GPIO_Pin_13)
#define LCD_RES_L GPIO_ResetBits(GPIOG,GPIO_Pin_13)

//----  END  -------//

void SSD2828_GPIO_Initial(void)
{
//��ʼ��GPIO,����SSD2828 SPI 4��ģʽ
						GPIO_InitTypeDef  GPIO_InitStructure;

          

			
						RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE); 
						RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
							//SDI
							GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
						GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
						GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
//						GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
						GPIO_Init(GPIOC, &GPIO_InitStructure);
						//CS
						GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
						GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
						GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
						GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
						GPIO_Init(GPIOI, &GPIO_InitStructure);
						//SCK
						GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
						GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
						GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
						GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
						GPIO_Init(GPIOE, &GPIO_InitStructure);
						//SHUT
						GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
						GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
						GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
						GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
						GPIO_Init(GPIOD, &GPIO_InitStructure);
						
						//SDO
						GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
						GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
						GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
						GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
						GPIO_Init(GPIOE, &GPIO_InitStructure);
						//RES
						GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
						GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
						GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
						GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
						GPIO_Init(GPIOH, &GPIO_InitStructure);
						//DC
						GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
						GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
						GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
						GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
						GPIO_Init(GPIOE, &GPIO_InitStructure);
						//LCD_RST
						GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
						GPIO_InitStructure.GPIO_Speed = GPIO_Speed_25MHz;
						GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
						GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;
						GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
						GPIO_Init(GPIOG, &GPIO_InitStructure);
}

void SSD2828_Init3(void)
{
		SSD_RST_L;
//		SSD_SPI_SDC_L;
		SSD_SPI_CS_H;
		SSD_SPI_SCLK_L;
		SSD_SPI_SDO_L;
		LCD_RES_L;
		Delay_us(1200);
		LCD_RES_H;
		SSD_RST_H;
//		SSD_SPI_SDC_H;

}


void SPI_3W_SET_Cmd3(u8 cmd)
{
	u8 kk;
	
	SSD_SPI_SDO_L;//Set SDO-0 for writing to Command register in 3 wrie SPI	
	//SSD_SPI_SDC_L;	//Set DC=0, for writing to Command register
	SSD_SPI_SCLK_L;
	Delay_10us(1);//��ʱ10us
	SSD_SPI_SCLK_H;
	Delay_10us(1);//��ʱ10us
	SSD_SPI_SCLK_L;
	Delay_10us(1);//��ʱ10us
	for(kk=0;kk<8;kk++)
	{
		if((cmd&0x80)==0x80) //SSD_SPI_SDC_H;
			SSD_SPI_SDO_H;
		else        //SSD_SPI_SDC_L; 
			SSD_SPI_SDO_L;
		SSD_SPI_SCLK_H;
		Delay_10us(1);//��ʱ10us
		SSD_SPI_SCLK_L;
		Delay_10us(1);//��ʱ10us
		cmd = cmd<<1;	
	}
}


void SPI_3W_SET_PAs3(u8 value)
{
	u8 kk;

	SSD_SPI_SDO_H;	//Set SDO-0 for writing to Command register in 3 wrie SPI	
	//SSD_SPI_SDC_H;		//Set DC=1, for writing to Data register
	SSD_SPI_SCLK_L;
	Delay_10us(1);//��ʱ10us
	SSD_SPI_SCLK_H;
	Delay_10us(1);//��ʱ10us
	SSD_SPI_SCLK_L;
	Delay_10us(1);//��ʱ10us
	for(kk=0;kk<8;kk++)
	{
		if((value&0x80)==0x80) SSD_SPI_SDO_H;
			//SSD_SPI_SDC_H;
		else         					 SSD_SPI_SDO_L;
			//SSD_SPI_SDC_L;//
		SSD_SPI_SCLK_H;
		Delay_10us(1);//��ʱ10us
		SSD_SPI_SCLK_L;
		Delay_10us(1);//��ʱ10us
		value = value<<1;	
	}	
}
//-----------------------------------------------------
void Write_com(u16 vv)
{
	SSD_SPI_CS_L;
	SPI_3W_SET_Cmd3(vv&0xff);	
}

void Write_register(u16 vv)
{
	SPI_3W_SET_PAs3(vv&0xff);
	SPI_3W_SET_PAs3((vv>>8)&0xff);	
}
//-----------------------------------------------------

void writec(u8 cmd)
{
	SSD_SPI_CS_L;
	SPI_3W_SET_Cmd3(cmd);	
	SSD_SPI_CS_H;

}

void writed(u8 value)
{
	SSD_SPI_CS_L;
  SPI_3W_SET_PAs3(value);
	SSD_SPI_CS_H;
}

void SPI_2828_WrCmd3(u8 cmd)
{
	u8 i;
	
	SSD_SPI_CS_L;
	
	SSD_SPI_SDO_L;		//Set SDO-0 for writing to Command register in 3 wrie SPI	
	//SSD_SPI_SDC_L;			//Set DC=0, for writing to Command register
	SSD_SPI_SCLK_L;
		Delay_10us(1);//��ʱ10us
	SSD_SPI_SCLK_H;
	Delay_10us(1);//��ʱ10us
	SSD_SPI_SCLK_L;
	Delay_10us(1);//��ʱ10us
	for(i=0;i<8;i++)
	{
		if((cmd&0x80)==0x80) 
			//SSD_SPI_SDC_H;
			SSD_SPI_SDO_H;
		else       
			//SSD_SPI_SDC_L;
			SSD_SPI_SDO_L;
		
		SSD_SPI_SCLK_H;
		Delay_10us(1);//��ʱ10us
		SSD_SPI_SCLK_L;
	  Delay_10us(1);//��ʱ10us
		cmd = cmd<<1;	
	}
	
	SSD_SPI_CS_H;	
}

//void SPI_2828_WrCmd3(u8)
void SPI_2828_WrReg(u8 c,u16 value)
{
	SSD_SPI_CS_L;
	SPI_3W_SET_Cmd3(c);
	SPI_3W_SET_PAs3(value&0xff);
	SPI_3W_SET_PAs3((value>>8)&0xff);	
	SSD_SPI_CS_H;	
}

u8 Read_PAs(void)
{
	u8 i;
	u8  rdValue;

//	SSD_SPI_SCLK_L;
	rdValue = 0;
	for(i=0;i<8;i++)
	{
		rdValue = rdValue<<1;
		
		SSD_SPI_SCLK_H;
		Delay_10us(1);//��ʱ10us
		if(SSD_SPI_SDI==1)  rdValue |= 0x01;
		SSD_SPI_SCLK_L;
		Delay_10us(1);//��ʱ10us
	}
//	Set_CSX(0);

	return rdValue;	
}

u16 SPI_READ(void)//SSD2828 ID Read 
{
	u8  cmd,rdT;
	u16 reValue;
	u8 i;
	
	SSD_SPI_CS_L;
		cmd = 0xB0;
	SSD_SPI_SDO_L;//Set SDO-0 for writing to Command register in 3 wrie SPI				
//	SSD_SPI_SDC_L;//Set DC=0, for writing to Command register
	SSD_SPI_SCLK_L;
	Delay_10us(1);//��ʱ10us
	SSD_SPI_SCLK_H;
	Delay_10us(1);//��ʱ10us
	SSD_SPI_SCLK_L;
  Delay_10us(1);//��ʱ10us
	for(i=0;i<8;i++)
	{
		if((cmd&0x80)==0x80) //SSD_SPI_SDC_H;
		SSD_SPI_SDO_H;
		else        				 
		//SSD_SPI_SDC_L;
	  SSD_SPI_SDO_L;
		SSD_SPI_SCLK_H;
		Delay_10us(1);//��ʱ10us
		SSD_SPI_SCLK_L;
	  Delay_10us(1);//��ʱ10us
		cmd = cmd<<1;	
	}
	cmd = 0xFA;	
	SSD_SPI_SDO_L;//Set SDO-0 for writing to Command register in 3 wrie SPI				
	//SSD_SPI_SDC_L;//Set DC=0, for writing to Command register
	SSD_SPI_SCLK_L;	
	Delay_10us(1);//��ʱ10us
	SSD_SPI_SCLK_H;
	Delay_10us(1);//��ʱ10us
	SSD_SPI_SCLK_L;
	Delay_10us(1);//��ʱ10us
	for(i=0;i<8;i++)
	{
		if((cmd&0x80)==0x80) //SSD_SPI_SDC_H;			
		SSD_SPI_SDO_H;
		else    						 //SSD_SPI_SDC_L;    
		SSD_SPI_SDO_L;
		SSD_SPI_SCLK_H;
		Delay_10us(1);//��ʱ10us
		SSD_SPI_SCLK_L;
	  Delay_10us(1);//��ʱ10us
		cmd = cmd<<1;	
	}	
	
	rdT=0;
	for(i=0;i<8;i++)
	{
		rdT = rdT<<1;
		SSD_SPI_SCLK_H;
		if(SSD_SPI_SDI==0) 
                  rdT |= 0x00;
                else
                  rdT |= 0x01;
    Delay_10us(1);//��ʱ10us            
		SSD_SPI_SCLK_L;	
	  Delay_10us(1);//��ʱ10us								
	}
	
	reValue = rdT;
	//reValue = (reValue<<8)&0xFF00;
	
	rdT=0;
	for(i=0;i<8;i++)
	{
		rdT = rdT<<1;
		SSD_SPI_SCLK_H;
		if(SSD_SPI_SDI==0) 
                  rdT |= 0x00;
                else
                  rdT |= 0x01;
								
    Delay_10us(1);//��ʱ10us            
		SSD_SPI_SCLK_L;	
		Delay_10us(1);//��ʱ10us								
	}
	
	reValue += (rdT<<8);
	
	SSD_SPI_CS_H;
	
	return reValue;			
}

u8   SPI_READ_ID(void)
{
	//SPI_2828_WrReg(0xd4, 0x00FA);?
	u16 Read_ID;
	u8 Flag;
	//Read_ID=0x2825;
	Read_ID=SPI_READ();
	//printf("The Chip ID is : 0x%x\n",Read_ID);
	if(Read_ID == 0x2828)
			 Flag=1;
		else
			 Flag=0;
	return Flag;
}

u16 SSD2828_READ(u8 reg)//SSD2828 Read Reg 
{
	u8  cmd,rdT;
	u16 reValue;
	u8 i;
	
	SSD_SPI_CS_L;

	SSD_SPI_SDO_L;			//Set SDO-0 for writing to Command register in 3 wrie SPI	
	//SSD_SPI_SDC_L;      //Set DC=0, for writing to Command register
	cmd = reg;//cmd = 0xB0;//read address
	SSD_SPI_SCLK_L;
		Delay_10us(1);//��ʱ10us
	SSD_SPI_SCLK_H;
	 Delay_10us(1);//��ʱ10us
	SSD_SPI_SCLK_L;
	Delay_10us(1);//��ʱ10us
	for(i=0;i<8;i++)
	{
		if((cmd&0x80)==0x80) //SSD_SPI_SDC_H;
		SSD_SPI_SDO_H;
		else      //SSD_SPI_SDC_L;   
		SSD_SPI_SDO_L;
		SSD_SPI_SCLK_H;
	  Delay_10us(1);//��ʱ10us
		SSD_SPI_SCLK_L;
	  Delay_10us(1);//��ʱ10us
		cmd = cmd<<1;	
	}
	cmd = 0xFA;	
	SSD_SPI_SDO_L;		//Set SDO-0 for writing to Command register in 3 wrie SPI		
	//SSD_SPI_SDC_L; 		//Set DC=0, for writing to Command register
	SSD_SPI_SCLK_L;
	Delay_10us(1);//��ʱ10us
	SSD_SPI_SCLK_H;
	Delay_10us(1);//��ʱ10us
	SSD_SPI_SCLK_L;
	Delay_10us(1);//��ʱ10us
	for(i=0;i<8;i++)
	{
		if((cmd&0x80)==0x80) //SSD_SPI_SDC_H;
			SSD_SPI_SDO_H;
		else     //SSD_SPI_SDC_L;    
			SSD_SPI_SDO_L;
		SSD_SPI_SCLK_H;
	  Delay_10us(1);//��ʱ10us
		SSD_SPI_SCLK_L;
	  Delay_10us(1);//��ʱ10us
		cmd = cmd<<1;	
	}	
	
	rdT=0;
	for(i=0;i<8;i++)
	{
		rdT = rdT<<1;
		SSD_SPI_SCLK_H;
		
                if(SSD_SPI_SDI==0) 
                  rdT |= 0x00;
                else
                  rdT |= 0x01;
	  Delay_10us(1);//��ʱ10us            
		SSD_SPI_SCLK_L;	
	  Delay_10us(1);//��ʱ10us								
	}
	
	reValue = rdT;
	//reValue = (reValue<<8)&0xFF00;
	
	rdT=0;
	for(i=0;i<8;i++)
	{
		rdT = rdT<<1;
		SSD_SPI_SCLK_H;
		
                if(SSD_SPI_SDI==0) 
                  rdT |= 0x00;
                else
                  rdT |= 0x01;
	  Delay_10us(1);//��ʱ10us              
		SSD_SPI_SCLK_L;	
	  Delay_10us(1);//��ʱ10us								
	}
	
	reValue += (rdT<<8);
	
	SSD_SPI_CS_H;
	
	return reValue;			
}

u16   SSD2828_READ_Dat(u8 reg)// SSD2828 Read Reg 
{
	//SPI_2828_WrReg(0xd4, 0x00FA);?
	u16 Read_Dat;
	//Read_ID=0x2825;
	Read_Dat=SSD2828_READ(reg);
//	printf("SSD2828  Read  Reg  Address is  : 0x%x \r\n",(u16)reg);
//	printf("SSD2828  Read         Dat   is  : 0x%x \r\n",Read_Dat);
        return Read_Dat;
}

void SPI_WriteData3(u8 value)
{
//	printf("-%2x",value);
	SSD_SPI_CS_L;
	SPI_3W_SET_PAs3(value);
	SSD_SPI_CS_H;	
}

void GP_COMMAD_PA3(u16 num)//New
{
      SPI_2828_WrReg(0xbc, num);//Oxbc-0xbd---num 
	  //  Write_com(0x00bd);
		//	SPI_2828_WrReg(0xbe, num);
     // Write_com(0x00bf);
	  writec(0xbf);
      SSD_SPI_CS_H;	
}

//////////////////////////////////////////////////////////////////////////
u8   SPI_READ_new(void)
{
	u8  rdT;
	u8 reValue;
	u8 kk;
	
	SSD_SPI_CS_L;

	rdT=0;
	for(kk=0;kk<8;kk++)
	{
		rdT = rdT<<1;
		SSD_SPI_SCLK_H;
		if(SSD_SPI_SDI&0x0800) rdT |= 0x01;
		SSD_SPI_SCLK_L;				
	}
	
	reValue = rdT;
	//reValue = (reValue<<8)&0xFF00;
	
	SSD_SPI_CS_H;
	
	return reValue;			
}



void LCD_CODE_YQ2(void)
{

	//LCD driver initialization
	//========== Internal setting ==========
    
GP_COMMAD_PA3(5);SPI_WriteData3(0xFF);SPI_WriteData3(0xAA);SPI_WriteData3(0x55);SPI_WriteData3(0xA5);SPI_WriteData3(0x80);
GP_COMMAD_PA3(3);SPI_WriteData3(0x6F);SPI_WriteData3(0x11);SPI_WriteData3(0x00);
GP_COMMAD_PA3(3);SPI_WriteData3(0xF7);SPI_WriteData3(0x20);SPI_WriteData3(0x00);
GP_COMMAD_PA3(2);SPI_WriteData3(0x6F);SPI_WriteData3(0x06);
GP_COMMAD_PA3(2);SPI_WriteData3(0xF7);SPI_WriteData3(0xA0);
GP_COMMAD_PA3(2);SPI_WriteData3(0x6F);SPI_WriteData3(0x19);
GP_COMMAD_PA3(2);SPI_WriteData3(0xF7);SPI_WriteData3(0x12);
GP_COMMAD_PA3(2);SPI_WriteData3(0xF4);SPI_WriteData3(0x03);
GP_COMMAD_PA3(2);SPI_WriteData3(0x6F);SPI_WriteData3(0x08);
GP_COMMAD_PA3(2);SPI_WriteData3(0xFA);SPI_WriteData3(0x40);
GP_COMMAD_PA3(2);SPI_WriteData3(0x6F);SPI_WriteData3(0x11);
GP_COMMAD_PA3(2);SPI_WriteData3(0xF3);SPI_WriteData3(0x01);
GP_COMMAD_PA3(2);SPI_WriteData3(0x6F);SPI_WriteData3(0x06);
GP_COMMAD_PA3(2);SPI_WriteData3(0xFC);SPI_WriteData3(0x03);

	GP_COMMAD_PA3(6);
	SPI_WriteData3(0xF0);
	SPI_WriteData3(0x55);
	SPI_WriteData3(0xAA);
	SPI_WriteData3(0x52);
	SPI_WriteData3(0x08);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB1);
	SPI_WriteData3(0x68);
	SPI_WriteData3(0x01);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xB6);
	SPI_WriteData3(0x08);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0x6F);
	SPI_WriteData3(0x02);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xB8);
	SPI_WriteData3(0x08);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xBB);
	SPI_WriteData3(0x54);
	SPI_WriteData3(0x44);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xBC);
	SPI_WriteData3(0x05);
	SPI_WriteData3(0x05);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xC7);
	SPI_WriteData3(0x01);
	GP_COMMAD_PA3(6);
	SPI_WriteData3(0xBD);
	SPI_WriteData3(0x02);
	SPI_WriteData3(0xB0);
	SPI_WriteData3(0x1E);
	SPI_WriteData3(0x1E);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xC5);
	SPI_WriteData3(0x01);
	SPI_WriteData3(0x07);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xC8);
	SPI_WriteData3(0x83);
	GP_COMMAD_PA3(6);
	SPI_WriteData3(0xF0);
	SPI_WriteData3(0x55);
	SPI_WriteData3(0xAA);
	SPI_WriteData3(0x52);
	SPI_WriteData3(0x08);
	SPI_WriteData3(0x01);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB0);
	SPI_WriteData3(0x05);
	SPI_WriteData3(0x05);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB1);
	SPI_WriteData3(0x05);
	SPI_WriteData3(0x05);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xBC);
	SPI_WriteData3(0x80);
	SPI_WriteData3(0x01);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xBD);
	SPI_WriteData3(0x80);
	SPI_WriteData3(0x01);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xCA);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xC0);
	SPI_WriteData3(0x04);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB3);
	SPI_WriteData3(0x28);
	SPI_WriteData3(0x28);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB4);
	SPI_WriteData3(0x12);
	SPI_WriteData3(0x12);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB9);
	SPI_WriteData3(0x45);
	SPI_WriteData3(0x45);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xBA);
	SPI_WriteData3(0x24);
	SPI_WriteData3(0x24);
	GP_COMMAD_PA3(6);
	SPI_WriteData3(0xF0);
	SPI_WriteData3(0x55);
	SPI_WriteData3(0xAA);
	SPI_WriteData3(0x52);
	SPI_WriteData3(0x08);
	SPI_WriteData3(0x02);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xEE);
	SPI_WriteData3(0x01);
	GP_COMMAD_PA3(5);
	SPI_WriteData3(0xEF);
	SPI_WriteData3(0x09);
	SPI_WriteData3(0x06);
	SPI_WriteData3(0x15);
	SPI_WriteData3(0x18);
	GP_COMMAD_PA3(7);
	SPI_WriteData3(0xB0);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x11);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x2B);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0x6F);
	SPI_WriteData3(0x06);
	GP_COMMAD_PA3(7);
	SPI_WriteData3(0xB0);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x40);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x50);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x6E);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0x6F);
	SPI_WriteData3(0x0C);
	GP_COMMAD_PA3(5);
	SPI_WriteData3(0xB0);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x8E);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0xC5);
	GP_COMMAD_PA3(7);
	SPI_WriteData3(0xB1);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0xF1);
	SPI_WriteData3(0x01);
	SPI_WriteData3(0x3B);
	SPI_WriteData3(0x01);
	SPI_WriteData3(0x73);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0x6F);
	SPI_WriteData3(0x06);
	GP_COMMAD_PA3(7);
	SPI_WriteData3(0xB1);
	SPI_WriteData3(0x01);
	SPI_WriteData3(0xCD);
	SPI_WriteData3(0x02);
	SPI_WriteData3(0x15);
	SPI_WriteData3(0x02);
	SPI_WriteData3(0x18);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0x6F);
	SPI_WriteData3(0x0C);
	GP_COMMAD_PA3(5);
	SPI_WriteData3(0xB1);
	SPI_WriteData3(0x02);
	SPI_WriteData3(0x60);
	SPI_WriteData3(0x02);
	SPI_WriteData3(0xBD);
	GP_COMMAD_PA3(7);
	SPI_WriteData3(0xB2);
	SPI_WriteData3(0x02);
	SPI_WriteData3(0xF2);
	SPI_WriteData3(0x03);
	SPI_WriteData3(0x32);
	SPI_WriteData3(0x03);
	SPI_WriteData3(0x59);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0x6F);
	SPI_WriteData3(0x06);
	GP_COMMAD_PA3(7);
	SPI_WriteData3(0xB2);
	SPI_WriteData3(0x03);
	SPI_WriteData3(0x88);
	SPI_WriteData3(0x03);
	SPI_WriteData3(0x99);
	SPI_WriteData3(0x03);
	SPI_WriteData3(0xAC);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0x6F);
	SPI_WriteData3(0x0C);
	GP_COMMAD_PA3(5);
	SPI_WriteData3(0xB2);
	SPI_WriteData3(0x03);
	SPI_WriteData3(0xBD);
	SPI_WriteData3(0x03);
	SPI_WriteData3(0xE4);
	GP_COMMAD_PA3(5);
	SPI_WriteData3(0xB3);
	SPI_WriteData3(0x03);
	SPI_WriteData3(0xF7);
	SPI_WriteData3(0x03);
	SPI_WriteData3(0xFF);
	GP_COMMAD_PA3(6);
	SPI_WriteData3(0xF0);
	SPI_WriteData3(0x55);
	SPI_WriteData3(0xAA);
	SPI_WriteData3(0x52);
	SPI_WriteData3(0x08);
	SPI_WriteData3(0x06);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB0);
	SPI_WriteData3(0x0B);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB1);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB2);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x09);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB3);
	SPI_WriteData3(0x2A);
	SPI_WriteData3(0x29);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB4);
	SPI_WriteData3(0x1B);
	SPI_WriteData3(0x19);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB5);
	SPI_WriteData3(0x17);
	SPI_WriteData3(0x15);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB6);
	SPI_WriteData3(0x13);
	SPI_WriteData3(0x11);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB7);
	SPI_WriteData3(0x01);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB8);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB9);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xBA);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xBB);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xBC);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xBD);
	SPI_WriteData3(0x10);
	SPI_WriteData3(0x12);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xBE);
	SPI_WriteData3(0x14);
	SPI_WriteData3(0x16);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xBF);
	SPI_WriteData3(0x18);
	SPI_WriteData3(0x1A);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xC0);
	SPI_WriteData3(0x29);
	SPI_WriteData3(0x2A);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xC1);
	SPI_WriteData3(0x08);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xC2);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xC3);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x0A);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xE5);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xC4);
	SPI_WriteData3(0x0A);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xC5);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xC6);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xC7);
	SPI_WriteData3(0x2A);
	SPI_WriteData3(0x29);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xC8);
	SPI_WriteData3(0x10);
	SPI_WriteData3(0x12);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xC9);
	SPI_WriteData3(0x14);
	SPI_WriteData3(0x16);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xCA);
	SPI_WriteData3(0x18);
	SPI_WriteData3(0x1A);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xCB);
	SPI_WriteData3(0x08);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xCC);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xCD);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xCE);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xCF);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xD0);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x09);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xD1);
	SPI_WriteData3(0x1B);
	SPI_WriteData3(0x19);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xD2);
	SPI_WriteData3(0x17);
	SPI_WriteData3(0x15);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xD3);
	SPI_WriteData3(0x13);
	SPI_WriteData3(0x11);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xD4);
	SPI_WriteData3(0x29);
	SPI_WriteData3(0x2A);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xD5);
	SPI_WriteData3(0x01);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xD6);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xD7);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x0B);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xE6);
	SPI_WriteData3(0x2E);
	SPI_WriteData3(0x2E);
	GP_COMMAD_PA3(6);
	SPI_WriteData3(0xD8);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(6);
	SPI_WriteData3(0xD9);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xE7);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(6);
	SPI_WriteData3(0xF0);
	SPI_WriteData3(0x55);
	SPI_WriteData3(0xAA);
	SPI_WriteData3(0x52);
	SPI_WriteData3(0x08);
	SPI_WriteData3(0x03);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB0);
	SPI_WriteData3(0x20);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB1);
	SPI_WriteData3(0x20);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(6);
	SPI_WriteData3(0xB2);
	SPI_WriteData3(0x05);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(6);
	SPI_WriteData3(0xB6);
	SPI_WriteData3(0x05);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(6);
	SPI_WriteData3(0xB7);
	SPI_WriteData3(0x05);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(6);
	SPI_WriteData3(0xBA);
	SPI_WriteData3(0x57);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(6);
	SPI_WriteData3(0xBB);
	SPI_WriteData3(0x57);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(5);
	SPI_WriteData3(0xC0);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(5);
	SPI_WriteData3(0xC1);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xC4);
	SPI_WriteData3(0x60);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xC5);
	SPI_WriteData3(0x40);
	GP_COMMAD_PA3(6);
	SPI_WriteData3(0xF0);
	SPI_WriteData3(0x55);
	SPI_WriteData3(0xAA);
	SPI_WriteData3(0x52);
	SPI_WriteData3(0x08);
	SPI_WriteData3(0x05);
	GP_COMMAD_PA3(6);
	SPI_WriteData3(0xBD);
	SPI_WriteData3(0x03);
	SPI_WriteData3(0x01);
	SPI_WriteData3(0x03);
	SPI_WriteData3(0x03);
	SPI_WriteData3(0x03);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB0);
	SPI_WriteData3(0x17);
	SPI_WriteData3(0x06);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB1);
	SPI_WriteData3(0x17);
	SPI_WriteData3(0x06);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB2);
	SPI_WriteData3(0x17);
	SPI_WriteData3(0x06);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB3);
	SPI_WriteData3(0x17);
	SPI_WriteData3(0x06);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB4);
	SPI_WriteData3(0x17);
	SPI_WriteData3(0x06);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xB5);
	SPI_WriteData3(0x17);
	SPI_WriteData3(0x06);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xB8);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xB9);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xBA);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xBB);
	SPI_WriteData3(0x02);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xBC);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xC0);
	SPI_WriteData3(0x07);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xC4);
	SPI_WriteData3(0x80);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xC5);
	SPI_WriteData3(0xA4);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xC8);
	SPI_WriteData3(0x05);
	SPI_WriteData3(0x30);
	GP_COMMAD_PA3(3);
	SPI_WriteData3(0xC9);
	SPI_WriteData3(0x01);
	SPI_WriteData3(0x31);
	GP_COMMAD_PA3(4);
	SPI_WriteData3(0xCC);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x3C);
	GP_COMMAD_PA3(4);
	SPI_WriteData3(0xCD);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x3C);
	GP_COMMAD_PA3(6);
	SPI_WriteData3(0xD1);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x05);
	SPI_WriteData3(0x09);
	SPI_WriteData3(0x07);
	SPI_WriteData3(0x10);
	GP_COMMAD_PA3(6);
	SPI_WriteData3(0xD2);
	SPI_WriteData3(0x00);
	SPI_WriteData3(0x05);
	SPI_WriteData3(0x0E);
	SPI_WriteData3(0x07);
	SPI_WriteData3(0x10);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xE5);
	SPI_WriteData3(0x06);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xE6);
	SPI_WriteData3(0x06);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xE7);
	SPI_WriteData3(0x06);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xE8);
	SPI_WriteData3(0x06);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xE9);
	SPI_WriteData3(0x06);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xEA);
	SPI_WriteData3(0x06);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xED);
	SPI_WriteData3(0x30);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0x6F);
	SPI_WriteData3(0x11);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0xF3);
	SPI_WriteData3(0x01);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0x51);
	SPI_WriteData3(0xFF);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0x53);
	SPI_WriteData3(0x2C);
	GP_COMMAD_PA3(2);
	SPI_WriteData3(0x35);
	SPI_WriteData3(0x00);
	GP_COMMAD_PA3(1);
	SPI_WriteData3(0x11);
	Delay_10us(12000);
	GP_COMMAD_PA3(1);
	SPI_WriteData3(0x29);
	Delay_10us(20000);

}
//BLJ FHD MIPI LCD Initial Code
void BLJ_LCD_Init(void)
{

	Delay_10us(20000);
	SSD_RST_L;// ( rGPFDAT &= (~(1<<3))) ;
	;
	Delay_10us(5000);
	SSD_RST_H;//  ( rGPFDAT |= (1<<3) ) ;
	Delay_10us(15000);

		SPI_2828_WrCmd3(0xb7);
		SPI_WriteData3(0x50);//50=TX_CLK 70=PCLK
		SPI_WriteData3(0x00);   //Configuration Register

		SPI_2828_WrCmd3(0xb8);
		SPI_WriteData3(0x00);
		SPI_WriteData3(0x00);   //VC(Virtual ChannelID) Control Register

		SPI_2828_WrCmd3(0xb9);
		SPI_WriteData3(0x00);//1=PLL disable
		SPI_WriteData3(0x00);
		//TX_CLK/MS should be between 5Mhz to100Mhz
		SPI_2828_WrCmd3(0xBA);//PLL=(TX_CLK/MS)*NS 8228=480M 4428=240M  061E=120M 4214=240M 821E=360M 8219=300M
		SPI_WriteData3(0x14);//D7-0=NS(0x01 : NS=1)
		SPI_WriteData3(0x42);//D15-14=PLL��Χ 00=62.5-125 01=126-250 10=251-500 11=501-1000  DB12-8=MS(01:MS=1)

		SPI_2828_WrCmd3(0xBB);//LP Clock Divider LP clock = 400MHz / LPD / 8 = 240 / 8 / 4 = 7.5MHz
		SPI_WriteData3(0x03);//D5-0=LPD=0x1 �C Divide by 2
		SPI_WriteData3(0x00);

		SPI_2828_WrCmd3(0xb9);
		SPI_WriteData3(0x01);//1=PLL disable
		SPI_WriteData3(0x00);
		//MIPI lane configuration
		SPI_2828_WrCmd3(0xDE);//ͨ����
		SPI_WriteData3(0x03);//11=4LANE 10=3LANE 01=2LANE 00=1LANE
		SPI_WriteData3(0x00);

		SPI_2828_WrCmd3(0xc9);
		SPI_WriteData3(0x02);
		SPI_WriteData3(0x23);   //p1: HS-Data-zero  p2: HS-Data- prepare  --> 8031 issue
		Delay_10us(10000);
 
///////////////////////////////////////////////////////////////

			SPI_2828_WrCmd3(0xB7);
			SPI_WriteData3(0x10);//10=TX_CLK 30=PCLK
			SPI_WriteData3(0x02);


			SPI_2828_WrCmd3(0xBD);
			SPI_WriteData3(0x00);
			SPI_WriteData3(0x00);
			
			SPI_2828_WrCmd3(0xD9);// HS LP Tx Driver current 
		        SPI_WriteData3(0x22);
		
///////////////////////////////////////////////////////////////
//                   //    MTF050HDI();//LCD ��ʼ�����ţ�ͬ���ֱ�����ֻ�޸���飡��
      GP_COMMAD_PA3(1);
			SPI_WriteData3(0x29);
			Delay_10us(15000);
			
			GP_COMMAD_PA3(1);
			SPI_WriteData3(0x11);
			Delay_10us(20000);

///////////////////////////////////////////////////////////////	
//LCD_CODE_YQ2();

		//SSD2828_Initial
		SPI_2828_WrCmd3(0xb7);
		SPI_WriteData3(0x50);
		SPI_WriteData3(0x00);   //Configuration Register

		SPI_2828_WrCmd3(0xb8);
		SPI_WriteData3(0x00);
		SPI_WriteData3(0x00);   //VC(Virtual ChannelID) Control Register

		SPI_2828_WrCmd3(0xb9);
		SPI_WriteData3(0x00);//1=PLL disable
		SPI_WriteData3(0x00);

		SPI_2828_WrCmd3(0xBA);//PLL=(TX_CLK/MS)*NS 8228=480M 4428=240M  061E=120M 4214=240M 821E=360M 8219=300M 8225=444M 8224=432
		SPI_WriteData3(0x1C);//D7-0=NS(0x01 : NS=1)   //0X28
		SPI_WriteData3(0x81);//D15-14=PLL��Χ 00=62.5-125 01=126-250 10=251-500 11=501-1000  DB12-8=MS(01:MS=1) //0X82

		SPI_2828_WrCmd3(0xBB);//LP Clock Divider LP clock = 400MHz / LPD / 8 = 480 / 8/ 8 = 7.5MHz
		SPI_WriteData3(0x04);//D5-0=LPD=0x1 �C Divide by 2
		SPI_WriteData3(0x00);

		SPI_2828_WrCmd3(0xb9);
		SPI_WriteData3(0x01);//1=PLL disable
		SPI_WriteData3(0x00);

		SPI_2828_WrCmd3(0xc9);
		SPI_WriteData3(0x02); //0x02
		SPI_WriteData3(0x23);   //p1: HS-Data-zero  p2: HS-Data- prepare  --> 8031 issue  0x23
		Delay_10us(1000);

		SPI_2828_WrCmd3(0xCA);
		SPI_WriteData3(0x01);//CLK Prepare //0x01
		SPI_WriteData3(0x23);//Clk Zero   //0x23

		SPI_2828_WrCmd3(0xCB); //local_write_reg(addr=0xCB,data=0x0510)
		SPI_WriteData3(0x10); //Clk Post  //0x10
		SPI_WriteData3(0x05); //Clk Per    /0x05

		SPI_2828_WrCmd3(0xCC); //local_write_reg(addr=0xCC,data=0x100A)
		SPI_WriteData3(0x05); //HS Trail
		SPI_WriteData3(0x10); //Clk Trail
		Delay_10us(1000);

		SPI_2828_WrCmd3(0xD0); //local_write_reg(addr=0xCC,data=0x100A)
		SPI_WriteData3(0x00); //HS Trail
		SPI_WriteData3(0x00); //Clk Trail
		Delay_10us(1000);


		//RGB interface configuration

		SPI_2828_WrReg(0xb1,(LCD_VSPW<<8)|LCD_HSPW);	//Vertical sync and horizontal sync active period 
		SPI_2828_WrReg(0xb2,(LCD_VBPD<<8)|LCD_HBPD);	//Vertical and horizontal back porch period  
		SPI_2828_WrReg(0xb3,(LCD_VFPD<<8)|LCD_HFPD);	//Vertical and horizontal front porch period 
		SPI_2828_WrReg(0xb4, LCD_XSIZE_TFT);		//Horizontal active period 
		SPI_2828_WrReg(0xb5, LCD_YSIZE_TFT);		//Vertical active period
	//	SPI_2828_WrReg(0xb6, 0x001B);				//Video mode and video pixel format //HS=L,VS=L,PCLK=L;
	//	SPI_2828_WrReg(0xb6, 0xC01B);				//Video mode and video pixel format //HS=H,VS=H,PCLK=L;
	//	SPI_2828_WrReg(0xb6, 0x2007);				//Video mode and video pixel format //HS=H,VS=H,PCLK=L;	blj is ok	
		SPI_2828_WrReg(0xb6, 0xe01B);				//Video mode and video pixel format //HS=H,VS=H,PCLK=L;				
		//MIPI lane configuration
		SPI_2828_WrCmd3(0xDE);//ͨ����
		SPI_WriteData3(0x03);//11=4LANE 10=3LANE 01=2LANE 00=1LANE
		SPI_WriteData3(0x00);

		SPI_2828_WrCmd3(0xD6);//  05=BGR  04=RGB
		SPI_WriteData3(0x05);//D0=0=RGB 1:BGR D1=1=Most significant byte sent first
		SPI_WriteData3(0x00);

		SPI_2828_WrCmd3(0xB7);
		SPI_WriteData3(0x4B); //0X4B
		SPI_WriteData3(0x02);
		Delay_10us(10000);

		SPI_2828_WrCmd3(0x2C);

		Delay_10us(5000);
			

}


//void MIPI_Read_Init(void)
//{

//  
//  Delay_10us(20000);
//	SSD_RST_L;// ( rGPFDAT &= (~(1<<3))) ;
//	Delay_10us(5000);
//	SSD_RST_H;//  ( rGPFDAT |= (1<<3) ) ;
//	Delay_10us(15000);
//        
//  
//	SPI_2828_WrCmd3(0xb7);
//		SPI_WriteData3(0x50);//50=TX_CLK 70=PCLK
//		SPI_WriteData3(0x00);   //Configuration Register
// 
//		SPI_2828_WrCmd3(0xb8);
//		SPI_WriteData3(0x00);
//		SPI_WriteData3(0x00);   //VC(Virtual ChannelID) Control Register

//		SPI_2828_WrCmd3(0xb9);
//		SPI_WriteData3(0x00);//1=PLL disable
//		SPI_WriteData3(0x00);
//	 
//    SPI_2828_WrCmd3(0xBA);//PLL=(TX_CLK/MS)*NS 8228=480M 4428=240M  061E=120M 4214=240M 821E=360M 8219=300M
//		SPI_WriteData3(0x2b);//14//D7-0=NS(0x01 : NS=1)//11
//		SPI_WriteData3(0x82);//42//D15-14=PLL?? 00=62.5-125 01=126-250 10=251-500 11=501-1000  DB12-8=MS(01:MS=1)
//		
// //   SPI_2828_WrCmd3(0xBA);//PLL=(TX_CLK/MS)*NS 8228=480M 4428=240M  061E=120M 4214=240M 821E=360M 8219=300M
////		SPI_WriteData3(0x14);//14//D7-0=NS(0x01 : NS=1)//11
////		SPI_WriteData3(0x02);//42//D15-14=PLL?? 00=62.5-125 01=126-250 10=251-500 11=501-1000  DB12-8=MS(01:MS=1)
//		
//		SPI_2828_WrCmd3(0xBB);//LP Clock Divider LP clock = 400MHz / LPD / 8 = 240 / 8 / 4 = 7.5MHz
//		SPI_WriteData3(0x03);//D5-0=LPD=0x1 �C Divide by 2  //12
//		SPI_WriteData3(0x00);
//		
//		SPI_2828_WrCmd3(0xb9);
//		SPI_WriteData3(0x01);//1=PLL disable
//		SPI_WriteData3(0x00);
//	 
//		//MIPI lane configuration
//		SPI_2828_WrCmd3(0xDE);//???
//		SPI_WriteData3(0x03);//11=4LANE 10=3LANE 01=2LANE 00=1LANE
//		SPI_WriteData3(0x00);

//		SPI_2828_WrCmd3(0xc9);
//		SPI_WriteData3(0x02);
//		SPI_WriteData3(0x23);   //p1: HS-Data-zero  p2: HS-Data- prepare  --> 8031 issue
//		Delay_10us(10000);
// 
//	SPI_2828_WrCmd3(0xB7);
//	SPI_WriteData3(0x10);//10=TX_CLK 30=PCLK
//	SPI_WriteData3(0x02);


//	SPI_2828_WrCmd3(0xBD);
//	SPI_WriteData3(0x00);
//	SPI_WriteData3(0x00);

//}

//////////////////////////////////////////////////////////////////////////
void PassWord0() //CMD PAGE 0
{

    GP_COMMAD_PA3(2);SPI_WriteData3(0xFF);SPI_WriteData3(0x00);
   // GP_COMMAD_PA3(2);SPI_WriteData3(0xFB);SPI_WriteData3(0x00);
      
}

void PassWord1() //CMD PAGE 1
{

   GP_COMMAD_PA3(2);SPI_WriteData3(0xFF);SPI_WriteData3(0x01);
   //GP_COMMAD_PA3(2);SPI_WriteData3(0xFB);SPI_WriteData3(0x01);
      
}
void PassWord2() //CMD PAGE 2
{

   GP_COMMAD_PA3(2);SPI_WriteData3(0xFF);SPI_WriteData3(0x02);
   //GP_COMMAD_PA3(2);SPI_WriteData3(0xFB);SPI_WriteData3(0x01);
      
}


//u16 SSD2828_READ_MIPI(void)//SSD2828 Read Mipi
//{
//	u8  cmd,rdT;
//	u16 reValue;
//	u8 i;
//	
//	SSD_SPI_CS_L;
////	SSD_SPI_SDC_L;
//	//SSD_SPI_SDO_L;			//Set DC=0, for writing to Command register
//	SSD_SPI_SCLK_L;
//	SSD_SPI_SCLK_H;
//	
//	cmd = 0xFA;
//	SSD_SPI_SCLK_L;
//	for(i=0;i<8;i++)
//	{
//		if((cmd&0x80)==0x80) SSD_SPI_SDC_H;//SSD_SPI_SDO_H;
//		else         SSD_SPI_SDC_L;//SSD_SPI_SDO_L;
//		SSD_SPI_SCLK_H;
//		SSD_SPI_SCLK_L;
//		cmd = cmd<<1;	
//	}	
//	
//	rdT=0;
//	for(i=0;i<8;i++)
//	{
//		rdT = rdT<<1;
//		SSD_SPI_SCLK_H;
//                
//   if(SSD_SPI_SDI==0) 
//                  rdT |= 0x00;
//                else
//                  rdT |= 0x01;
//                
//                
//		SSD_SPI_SCLK_L;				
//	}
//	
//	reValue = rdT;
//	//reValue = (reValue<<8)&0xFF00;
//	
//	rdT=0;
//	for(i=0;i<8;i++)
//	{
//		rdT = rdT<<1;
//		SSD_SPI_SCLK_H;
//                
//		   if(SSD_SPI_SDI==0) 
//                  rdT |= 0x00;
//                else
//                  rdT |= 0x01;
//                
//		SSD_SPI_SCLK_L;				
//	}
//	
//	reValue += (rdT<<8);
//	
//	SSD_SPI_CS_H;
//	
//	return reValue;			
//}

//--------- DSI Read Driver Data By  MIPI --------------//2006-10-20
//u8 RD_DSI_BASICPAs(u8 Num,u8 addr,u8 Page)//LE Max. return packet is 255 bytes;a---reg addr; ye---page 
//{   
//     u8 PAs,LEs,i,j,m,read_dat0,read_dat1;
//     u16 oregist1,oregist2;
//	   
//     LEs = Num;
//     PAs = addr;
//	   
//     j = Num;
//     j = (j/2)+(j%2);
//	
//  do{ 
//			
//    switch(Page)
//    {
//       case 0: PassWord0();break;
//       case 1: PassWord1();break;
//       case 2: PassWord2();break;
//    } 
//		
//	// -- Read B7  --//
//		/*
//	  writec(0xBD);//
//    writed(0x00);
//    writed(0x00);
//		
//		writec(0xB7);
//    writec(0xFA);
//    oregist1 = SPI_READ_new();
//    oregist2 = SPI_READ_new();
//		printf("Read oregist1 Reg data is 0x%x\n\r",(uint)(oregist1));
//		printf("Read oregist2 Reg data is 0x%x\n\r",(uint)(oregist2));
//		delay1ms(10);
//  */
//		
//		SSD2828_READ_Dat(0xB7);
//		
////---MIPI Read ------------------//
//    writec(0xB7);//
//    writed(0x82);
//    writed(0x03);
//    
//    writec(0xBB);//
//	  writed(0x03);//
//	  writed(0x00);
//	
//    writec(0xC1);//Read Num
//    writed(LEs);
//    writed(0x00);
//    
//    writec(0xC0);
//    writed(0x01);
//    writed(0x00);
//    
//    writec(0xBC);
//    writed(0x01);
//    writed(0x00);
//printf("Read Driver IC Reg is 0x%x\n\r",(u16)PAs);   
//    writec(0xBF);// Send Read Driver IC Reg Addr
//    writed(PAs);
//    writed(0x00);
//    Delay_ms(20);

//    writec(0xD4);
//    writed(0xFA);//
//    writed(0x00);  //Read CMD
//    
//   oregist1=SSD2828_READ_Dat(0xC6);
//		
//    }
//    while(!((oregist1 & 0x01)==0x01));

//    writec(0xFF);

//    for(i = 0; i < j;i++)
//    {
//			oregist2=SSD2828_READ_MIPI();
//      printf("Read mipi data is (0x%x)\n",(u16)(oregist2));

//     }
//     
//		 
//		 
//		 /*
//     writec(0xB7);
//     writed(oregist1);
//     writed(oregist2);
//     
//     writec(0xB7);
//     writed(0x50);
//     writed(0x01);
//     
//     writec(0xB7);
//     writed(oregist1);
//     writed(oregist2);
//		 m=read_dat1;
//		 */
//		 
//     return 1;
//}
