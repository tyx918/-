#ifndef __CONVERTDATA_H
#define __CONVERTDATA_H
#include "stm32f4xx.h"

void convert(char* ReadBuffer_13_process,int* all_data,int num);

#endif