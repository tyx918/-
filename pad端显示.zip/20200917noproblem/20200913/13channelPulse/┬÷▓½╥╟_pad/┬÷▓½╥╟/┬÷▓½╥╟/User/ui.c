#include "ui.h"
#include "math.h"
#include "ff.h"
#include "dateReceive.h"
#include "./others/toHex.h"
#include <string.h>
#include "delay.h"
#include "dataprocess.h"
#include "./lcd/bsp_lcd.h"
#include "./others/show.h"
#include "musicPlayer.h"
#include "./showstring/showstring.h"

#include "picture.h"
#include "./Bsp/spi_dma/bsp_spi_dma_comfig.h"
#include "./Bsp/delay/delay.h" 
#include "Bsp/systick/bsp_SysTick.h"
#include "usart/bsp_debug_usart.h"
#include "./drawTrail/drawTrail.h"
#include "./calculation/calculation.h"
#include "13channel.h"
#include <stdio.h>


uint8_t linsi_status =0;

int enter_click = 0;//��¼��enter����Ĵ���
/***********��ͨ���ĸ�����ť�ĵ������**************/
static int u_heart_click = 0;//��¼�ڼ��ε��
static int u_emit_click = 0;
static int u_channel4_click = 0;
static int u_rec_click = 0;
static int u_begin_click = 0;
static int u_halt_click = 0;
static int u_reset_click = 0;
static int u_upload_click = 0;
static int con1_click = 0;static int con2_click = 0;static int con3_click = 0;static int con4_click = 0;
static int con5_click = 0;static int con6_click = 0;static int con7_click = 0;static int con8_click = 0;
int temp1=0;int temp2=0;int temp3=0;int temp4=0;int temp5=0;int temp6=0;int temp7=0;int temp8=0;
/********��ͨ��������ť�ĵ������***********/
static int u_four_1_click = 0;
static int u_four_2_click = 0;
static int u_four_3_click = 0;
static int u_four_4_click = 0;

static int show_click = 0;//�˱�־������ʼ�ļ���
static int show_click_play = 0;

int count5 = 0;//ѡȡǰ��KB����������������

//uint8_t showMap = 0;

int sta_clear = 0;

char rec[35*1024] = "";


////////////////////////������Ϣ////////////////////////////////
const int center_x=800/5;
const int center_y=1280/2;
const int height=100;
const int width=50;
//const int gap=80;
const int line_length=280;

////////////////////////��ť��Ϣ////////////////////////////////
const int but_width=70;
const int but_height=70;
const int but_gap=30;
const int but_left_x=703;
const int but_left_y=40;

const int but_left_x_upright=15;//����
const int but_left_y_upright=40;//����

int initial=0;//��ʼ���ı�־

const float command_dis=(line_length-width)/16.0;//���ֻ�������ͼ��

int send[2];//��¼���͹�������Լ�����֤��ָͬ��ֻ��һ��
extern uint8_t TX_Buff[SENDBUFF_SIZE];
/////////////////////////////�ļ��洢///////////////////////////////////
static FIL fnew;													/* �ļ����� */
static unsigned int fnum;            					  /* �ļ��ɹ���д���� */

struct object_info u_begin,u_stop,u_reset,u_upload,straight,turn,u_clear,u_emit,u_rec,u_heart,u_channel4,u_play,u_second,u_third,u_fourth,
u_enter,u_switch,straight,turn,u_fourChannel,u_eightChannel,u_four_1,u_four_2,u_four_3,u_four_4,u_four_previous,u_select_4,u_rank,u_again_4,u_load,
u_select_enter_pre,u_eight_con1,u_eight_con2,u_eight_con3,u_eight_con4,u_eight_con5,u_eight_con6,u_eight_con7,u_eight_con8,u_show,u_order,u_file;
//object_info *button[6]={&u_switch,&u_second,&u_third,&u_fourth,&u_play,&u_clear};//switchָ������ǿ����·�ź�
object_info *button[6]={&u_switch,&u_show,&u_play,&u_order,&u_clear,&u_file};//switchָ������ǿ����·�ź�
object_info *button_upright[8]={&u_emit,&u_rec,&u_heart,&u_channel4,&u_upload,&u_reset,&u_stop,&u_begin};//�˸�ͨ���İ�ť
object_info *button_enter[2]={&u_enter,&u_load};//����ҳ��İ�ť
object_info *button_channelMode[2] = {&u_fourChannel,&u_eightChannel};//ͨ��ѡ��ť
object_info *button_four[4] = {&u_four_1,&u_four_2,&u_four_3,&u_four_4};//�ĸ�ͨ���İ�ť
object_info *button_four_previous[1] = {&u_four_previous};//8,4ҳ��ķ�����һ��
object_info *button_rank[3] = {&u_select_4,&u_rank,&u_again_4};
object_info *button_select_enter_pre[1] = {&u_select_enter_pre};
object_info *button_eight_con[8] = {&u_eight_con1,&u_eight_con2,&u_eight_con3,&u_eight_con4,
&u_eight_con5,&u_eight_con6,&u_eight_con7,&u_eight_con8};


int select_rank = 0;//ѡ��ͨ�����ŵ�ǰselect_rank��
int channel_order = 0;
int clear = 0;// ����ߵı�־λ
int channel_space = 0;//ͨ���ļ��
int channel_order_cal=0;//�������������ı�־����ȡ����ͨ��������

int sort;//ѡ���ĸ�ͨ��������ʽ
int ratio;//�ֱ���
int channel_select;//��ͨ��
int extent;//���η���
int gap_coordinate;//�����ļ��
int return_previous = 0;//������һ����־��8ͨ����
int return_previous_4 = 0 ;//������һ���ı�־��4ͨ����
int initial_position = 0; //�����ʼ��λ��
int rank = 0;//ѡ��ǰ�����������ź�,8ͨ��
int rank_4 = 0;//4ͨ��������ǰ�����ź�
int circle = 0;//ѡȡ��ѭ����ȡ����
int select_enter_pre = 0;//������һ���ı�־
int enter_active = 1;//����ҳ�水ť����
int circle_begin=0;
int draw;//ѡ���������ǲ���
int file_order = 0;
//int mode_select_active = 1;//ģʽѡ��ҳ�漤��

void enter_initial()
 {
	 for(int i =0;i<2;i++){
	 	button_enter[i]->height=70;
		button_enter[i]->width=70;
		button_enter[i]->wake=0;
		button_enter[i]->y=560+i*(but_height+80);
		button_enter[i]->x=330;
		button_enter[i]->ID=i;
	  //Draw_ColorRect(button_enter[i]->x,button_enter[i]->y,button_enter[i]->width,button_enter[i]->height,LCD_COLOR565_BLACK);
	 }
}
 
void modeSelect_initial()
{
	  for(int i = 0;i<2;i++){
		  button_channelMode[i]->height=but_height;
			button_channelMode[i]->width=but_width;
			button_channelMode[i]->wake=0;
			button_channelMode[i]->x=400;
			button_channelMode[i]->y=530+i*(but_height+80);
			button_channelMode[i]->ID=i;
			//Draw_ColorRect(button_channelMode[i]->x,button_channelMode[i]->y,button_channelMode[i]->width,button_channelMode[i]->height,LCD_COLOR565_BLACK);
		}
	  button_select_enter_pre[0]->height=100;
		button_select_enter_pre[0]->width=80;
		button_select_enter_pre[0]->wake=0;
	  button_select_enter_pre[0]->y=0;
		button_select_enter_pre[0]->x=700;
		button_select_enter_pre[0]->ID=0;
}
//��ͨ���İ�ť��ʼ��
void controll_initial()//8ͨ��ģʽ��ť��ʼ��
{	
	//��ť��ʼ��
	for(int m =0;m<2;m++){
		  button[m]->height=but_height;
			button[m]->width=but_width;
			button[m]->wake=0;
			button[m]->x=700;
			button[m]->y=575-200+m*(but_height+30);
			button[m]->ID=0;
	}
	for(int i=2;i<6;i++)
		{
			button[i]->height=but_height;
			button[i]->width=but_width;
			button[i]->wake=0;
			button[i]->x=700;
			button[i]->y=575-200+i*(but_height+60);
			button[i]->ID=i;
			//Draw_ColorRect(button[i]->x,button[i]->y,button[i]->width,button[i]->height,LCD_COLOR565_BLACK);
		}		
		//��ߵİ�ť
		for(int j = 0;j<4;j++)
		{
		  button_upright[j]->height=but_height;//70
		  button_upright[j]->width=but_width;//70
		  button_upright[j]->wake=0;
		  button_upright[j]->y=0;
	  	button_upright[j]->x=(45+j*(but_height+10))*2;
		  button_upright[j]->ID=j;
		}
		//�ұߵİ�ť
		for(int j = 4;j<8;j++)
		{
		  button_upright[j]->height=but_height;//70
		  button_upright[j]->width=but_width;//70
		  button_upright[j]->wake=0;
		  button_upright[j]->y=640;
	  	button_upright[j]->x=(45+(j-4)*(but_height+10))*2;
		  button_upright[j]->ID=j;
		}
		
		for(int k=0;k<8;k++){
		  button_eight_con[k]->height=45;
		  button_eight_con[k]->width=45;
		  button_eight_con[k]->wake=0;
		  button_eight_con[k]->y=1230;
		  button_eight_con[k]->x=57.5+k*(45+35);
		  button_eight_con[k]->ID=k;
		 // Draw_ColorRect(button_eight_con[k]->x,button_eight_con[k]->y,button_eight_con[k]->width,button_eight_con[k]->height,LCD_COLOR565_BLACK);
}
		}
void previous()
{
	  button_four_previous[0]->height=100;
		button_four_previous[0]->width=80;
		button_four_previous[0]->wake=0;
	  button_four_previous[0]->y=20;
		button_four_previous[0]->x=700;
		button_four_previous[0]->ID=0;
		//Draw_ColorRect(button_four_previous[0]->x,button_four_previous[0]->y,button_four_previous[0]->width,button_four_previous[0]->height,LCD_COLOR565_BLACK);
}
	
void four_initial()
{
	for(int j =0;j<4;j++)
	{
	  button_four[j]->height=but_height;//70
		button_four[j]->width=but_width;//70
		button_four[j]->wake=0;
	  button_four[j]->y=but_left_y_upright;//40
		button_four[j]->x=80+j*(but_height+80);//40��
		button_four[j]->ID=j;
		//Draw_ColorRect(button_four[j]->x,button_four[j]->y,button_four[j]->width,button_four[j]->height,LCD_COLOR565_BLACK);
	}
	for(int k=0;k<3;k++){
		button_rank[k]->height=but_height;//70
		button_rank[k]->width=but_width;//70
		button_rank[k]->wake=0;
	  button_rank[k]->y=575+k*(but_height+80);
		button_rank[k]->x=700;//40��
		button_rank[k]->ID=k;
	  //Draw_ColorRect(button_rank[k]->x,button_rank[k]->y,button_rank[k]->width,button_rank[k]->height,LCD_COLOR565_BLACK);
	}
}

void dectect()//�ж��Ƿ��⵽����,���Ҽ�ⴥ�����ƶ���λ��,���밴ť����
{	
	static int u_switch_x;static int u_switch_y;static int u_second_x;static int u_second_y;static int u_third_x;static int u_third_y;
	static int u_fourth_x;static int u_fourth_y;static int u_play_x;static int u_play_y;static int u_clear_x;static int u_clear_y;
	static int u_show_x;static int u_show_y;static int u_order_x;static int u_order_y;
	static int u_file_x;static int u_file_y;
	for(int i=0;i<TPData.TouchNum;i++)
		{
				for(int j=0;j<6;j++)
				{
					if(button[j]->wake==0)
					{
						if(TPData.pre_x[i]>=button[j]->x&&TPData.pre_x[i]<=button[j]->x+button[j]->width&&TPData.pre_y[i]>=button[j]->y&&TPData.pre_y[i]<=button[j]->y+button[j]->height)
						{
							button[j]->wake=1;
							button[j]->ID=j;
								if(u_switch.wake==1)
							{
								if(TPData.pre_x[i]== u_switch_x&&TPData.pre_y[i]== u_switch_y)
									 u_switch.wake=0;
								else
								{
									 u_switch_x=TPData.pre_x[i];
									 u_switch_y=TPData.pre_y[i];
								}
							}
									if(u_show.wake)
								{
								if(TPData.pre_x[i]==u_show_x&&TPData.pre_y[i]==u_show_y)
									u_show.wake=0;
								else
								{
									u_show_x=TPData.pre_x[i];
									u_show_y=TPData.pre_y[i];
								}
							}
									if(u_play.wake)
								{
								if(TPData.pre_x[i]==u_play_x&&TPData.pre_y[i]==u_play_y)
									u_play.wake=0;
								else
								{
									u_play_x=TPData.pre_x[i];
									u_play_y=TPData.pre_y[i];
								}
							}
									if(u_order.wake)
								{
								if(TPData.pre_x[i]==u_order_x&&TPData.pre_y[i]==u_order_y)
									u_order.wake=0;
								else
								{
									u_order_x=TPData.pre_x[i];
									u_order_y=TPData.pre_y[i];
								}
							}
									if(u_clear.wake)
								{
								if(TPData.pre_x[i]==u_clear_x&&TPData.pre_y[i]==u_clear_y)
									u_clear.wake=0;
								else
								{
									u_clear_x=TPData.pre_x[i];
									u_clear_y=TPData.pre_y[i];
								}
							}
										if(u_file.wake)
								{
								if(TPData.pre_x[i]==u_file_x&&TPData.pre_y[i]==u_file_y)
									u_file.wake=0;
								else
								{
									u_file_x=TPData.pre_x[i];
									u_file_y=TPData.pre_y[i];
								}
							}
							break;
						}				
					}
				}
			}		
}

void detect_con()
{
//	static int u_eight_con1_x;static int u_eight_con1_y;static int u_eight_con2_x;static int u_eight_con2_y;static int u_eight_con3_x;static int u_eight_con3_y;
//	static int u_eight_con4_x;static int u_eight_con4_y;static int u_eight_con5_x;static int u_eight_con5_y;static int u_eight_con6_x;static int u_eight_con6_y;
//	static int u_eight_con7_x;static int u_eight_con7_y;static int u_eight_con8_x;static int u_eight_con8_y;
//	for(int i=0;i<TPData.TouchNum;i++)
//		{
//				for(int j=0;j<8;j++)
//				{
//					if(button_eight_con[j]->wake==0)
//					{
//						if(TPData.pre_x[i]>=button_eight_con[j]->x&&TPData.pre_x[i]<=(button_eight_con[j]->x+button_eight_con[j]->width+10)
//						&&TPData.pre_y[i]>=button_eight_con[j]->y&&TPData.pre_y[i]<=(button_eight_con[j]->y+button_eight_con[j]->height+10))
//						{
//							button_eight_con[j]->wake=1;
//							button_eight_con[j]->ID=j;
//							if(u_eight_con1.wake==1)//��¼u_reset��ť�����µ�λ��
//							{
//								if(TPData.pre_x[i]==u_eight_con1_x&&TPData.pre_y[i]==u_eight_con1_y)
//									u_eight_con1.wake=0;
//								else
//								{
//									u_eight_con1_x=TPData.pre_x[i];
//									u_eight_con1_y=TPData.pre_y[i];
//								}
//							}
//							if(u_eight_con2.wake==1)//��¼u_reset��ť�����µ�λ��
//							{
//								if(TPData.pre_x[i]==u_eight_con2_x&&TPData.pre_y[i]==u_eight_con2_y)
//									u_eight_con2.wake=0;
//								else
//								{
//									u_eight_con2_x=TPData.pre_x[i];
//									u_eight_con2_y=TPData.pre_y[i];
//								}
//							}
//							if(u_eight_con3.wake==1)//��¼u_reset��ť�����µ�λ��
//							{
//								if(TPData.pre_x[i]==u_eight_con3_x&&TPData.pre_y[i]==u_eight_con3_y)
//									u_eight_con3.wake=0;
//								else
//								{
//									u_eight_con3_x=TPData.pre_x[i];
//									u_eight_con3_y=TPData.pre_y[i];
//								}
//							}
//								if(u_eight_con4.wake==1)//��¼u_reset��ť�����µ�λ��
//							{
//								if(TPData.pre_x[i]==u_eight_con4_x&&TPData.pre_y[i]==u_eight_con4_y)
//									u_eight_con4.wake=0;
//								else
//								{
//									u_eight_con4_x=TPData.pre_x[i];
//									u_eight_con4_y=TPData.pre_y[i];
//								}
//							}
//							if(u_eight_con5.wake==1)//��¼u_reset��ť�����µ�λ��
//							{
//								if(TPData.pre_x[i]==u_eight_con5_x&&TPData.pre_y[i]==u_eight_con5_y)
//									u_eight_con5.wake=0;
//								else
//								{
//									u_eight_con5_x=TPData.pre_x[i];
//									u_eight_con5_y=TPData.pre_y[i];
//								}
//							}
//							if(u_eight_con6.wake==1)
//							{
//								if(TPData.pre_x[i]==u_eight_con6_x&&TPData.pre_y[i]==u_eight_con6_y)
//									u_eight_con6.wake=0;
//								else
//								{
//									u_eight_con6_x=TPData.pre_x[i];
//									u_eight_con6_y=TPData.pre_y[i];
//								}
//							}
//							if(u_eight_con7.wake==1)
//							{
//								if(TPData.pre_x[i]==u_eight_con7_x&&TPData.pre_y[i]==u_eight_con7_y)
//									u_eight_con7.wake=0;
//								else
//								{
//									u_eight_con7_x=TPData.pre_x[i];
//									u_eight_con7_y=TPData.pre_y[i];
//								}
//							}
//								if(u_eight_con8.wake==1)
//							{
//								if(TPData.pre_x[i]==u_eight_con8_x&&TPData.pre_y[i]==u_eight_con8_y)
//									u_eight_con8.wake=0;
//								else
//								{
//									u_eight_con8_x=TPData.pre_x[i];
//									u_eight_con8_y=TPData.pre_y[i];
//								}
//							}
//							break;
//						}				
//					}
//				}	
//		}
}

	
void detect_upright()
{
	static int u_emit_x;static int u_emit_y;static int u_rec_x;static int u_rec_y;static int u_heart_x;static int u_heart_y;
	static int u_channel4_x;static int u_channel4_y;static int u_reset_x;static int u_reset_y;static int u_stop_x;static int u_stop_y;
	static int u_begin_x;static int u_begin_y;static int u_upload_x;static int u_upload_y;
	for(int i=0;i<TPData.TouchNum;i++)
		{
			if(TPData.pre_x[i]>20)//����������޶��䴥����Ч�ķ�Χ
			{
				for(int j=0;j<8;j++)
				{
					if(button_upright[j]->wake==0)
					{
						if(TPData.pre_x[i]>=button_upright[j]->x&&TPData.pre_x[i]<=button_upright[j]->x+button_upright[j]->width
						&&TPData.pre_y[i]>=button_upright[j]->y&&TPData.pre_y[i]<=button_upright[j]->y+button_upright[j]->height)
						{
							button_upright[j]->wake=1;
							button_upright[j]->ID=j;
							if(u_begin.wake==1)//��¼u_reset��ť�����µ�λ��
							{
								if(TPData.pre_x[i]==u_begin_x&&TPData.pre_y[i]==u_begin_y)
									u_begin.wake=0;
								else
								{
									u_begin_x=TPData.pre_x[i];
									u_begin_y=TPData.pre_y[i];
								}
							}
							if(u_stop.wake==1)//��¼u_reset��ť�����µ�λ��
							{
								if(TPData.pre_x[i]==u_stop_x&&TPData.pre_y[i]==u_stop_y)
									u_stop.wake=0;
								else
								{
									u_stop_x=TPData.pre_x[i];
									u_stop_y=TPData.pre_y[i];
								}
							}
							if(u_reset.wake==1)//��¼u_reset��ť�����µ�λ��
							{
								if(TPData.pre_x[i]==u_reset_x&&TPData.pre_y[i]==u_reset_y)
									u_reset.wake=0;
								else
								{
									u_reset_x=TPData.pre_x[i];
									u_reset_y=TPData.pre_y[i];
								}
							}
								if(u_upload.wake==1)//��¼u_reset��ť�����µ�λ��
							{
								if(TPData.pre_x[i]==u_upload_x&&TPData.pre_y[i]==u_upload_y)
									u_upload.wake=0;
								else
								{
									u_upload_x=TPData.pre_x[i];
									u_upload_y=TPData.pre_y[i];
								}
							}
							if(u_emit.wake==1)//��¼u_reset��ť�����µ�λ��
							{
								if(TPData.pre_x[i]==u_emit_x&&TPData.pre_y[i]==u_emit_y)
									u_emit.wake=0;
								else
								{
									u_emit_x=TPData.pre_x[i];
									u_emit_y=TPData.pre_y[i];
								}
							}
							if(u_rec.wake==1)
							{
								if(TPData.pre_x[i]==u_rec_x&&TPData.pre_y[i]==u_rec_y)
									u_rec.wake=0;
								else
								{
									u_rec_x=TPData.pre_x[i];
									u_rec_y=TPData.pre_y[i];
								}
							}
							if(u_heart.wake==1)
							{
								if(TPData.pre_x[i]==u_heart_x&&TPData.pre_y[i]==u_heart_y)
									u_heart.wake=0;
								else
								{
									u_heart_x=TPData.pre_x[i];
									u_heart_y=TPData.pre_y[i];
								}
							}
								if(u_channel4.wake==1)
							{
								if(TPData.pre_x[i]==u_channel4_x&&TPData.pre_y[i]==u_channel4_y)
									u_channel4.wake=0;
								else
								{
									u_channel4_x=TPData.pre_x[i];
									u_channel4_y=TPData.pre_y[i];
								}
							}
							break;
						}				
					}
				}
		}		
		}
}

void dectect_enter()
{
	static int u_enter_x,u_enter_y;
	static int u_load_x,u_load_y;
	static int u_select_enter_pre_x,u_select_enter_pre_y;
	for(int i=0;i<TPData.TouchNum;i++)
		{
					for(int j=0;j<2;j++)
			  {
					if(button_enter[j]->wake==0)
					{
						if(TPData.pre_x[i]>=button_enter[j]->x&&TPData.pre_x[i]<=button_enter[j]->x+button_enter[j]->width
						&&TPData.pre_y[i]>=button_enter[j]->y&&TPData.pre_y[j]<=button_enter[j]->y+button_enter[j]->height)
						{
							button_enter[j]->wake=1;
							button_enter[j]->ID=0;
							if(u_enter.wake==1)//��¼u_reset��ť�����µ�λ��
							{
								if(TPData.pre_x[i]==u_enter_x&&TPData.pre_y[i]==u_enter_y)
									u_enter.wake=0;
								else
								{
									u_enter_x=TPData.pre_x[i];
									u_enter_y=TPData.pre_y[i];
								}
							}
						    if(u_load.wake==1)//��¼u_reset��ť�����µ�λ��
							{
								if(TPData.pre_x[i]==u_load_x&&TPData.pre_y[i]==u_load_y)
									u_load.wake=0;
								else
								{
									u_load_x=TPData.pre_x[i];
									u_load_y=TPData.pre_y[i];
								}
							}
	           break;	
						}					
					}
				}
					 if(button_select_enter_pre[0]->wake==0)
				{ 
					if(TPData.pre_x[i]>=button_select_enter_pre[0]->x&&TPData.pre_x[i]<=button_select_enter_pre[0]->x+button_select_enter_pre[0]->width
						&&TPData.pre_y[i]>=button_select_enter_pre[0]->y&&TPData.pre_y[i]<=button_select_enter_pre[0]->y+button_select_enter_pre[0]->height)
						{
							button_select_enter_pre[0]->wake=1;
							button_select_enter_pre[0]->ID=0;
							if(u_select_enter_pre.wake==1)//��¼u_reset��ť�����µ�λ��
							{
								if(TPData.pre_x[i]==u_select_enter_pre_x&&TPData.pre_y[i]==u_select_enter_pre_y)
									u_select_enter_pre.wake=0;
								else
								{
									u_select_enter_pre_x=TPData.pre_x[i];
									u_select_enter_pre_y=TPData.pre_y[i];
								}
							}
							break;
						}	
		}}
}

void dectect_rank()
{
	static int u_select_4_x,u_select_4_y,u_rank_x,u_rank_y;
	static int u_again_4_x,u_again_4_y;
	for(int i=0;i<TPData.TouchNum;i++)
		{
				for(int j=0;j<3;j++)
			  {
					if(button_rank[j]->wake==0)
					{ 
						if(TPData.pre_x[i]>=button_rank[j]->x&&TPData.pre_x[i]<=button_rank[j]->x+button_rank[j]->width
						&&TPData.pre_y[i]>=button_rank[j]->y&&TPData.pre_y[i]<=button_rank[j]->y+button_rank[j]->height)
						{
							button_rank[j]->wake=1;
							button_rank[j]->ID=j;
							if(u_select_4.wake==1)//��¼u_reset��ť�����µ�λ��
							{
								if(TPData.pre_x[i]==u_select_4_x&&TPData.pre_y[i]==u_select_4_y)
									u_select_4.wake=0;
								else
								{
									u_select_4_x=TPData.pre_x[i];
									u_select_4_y=TPData.pre_y[i];
								}
							}
							if(u_rank.wake==1)
							{
								if(TPData.pre_x[i]==u_rank_x&&TPData.pre_y[i]==u_rank_y)
									u_rank.wake=0;
								else
								{
									u_rank_x=TPData.pre_x[i];
									u_rank_y=TPData.pre_y[i];
								}
							}
								if(u_again_4.wake==1)
							{
								if(TPData.pre_x[i]==u_again_4_x&&TPData.pre_y[i]==u_again_4_y)
									u_again_4.wake=0;
								else
								{
									u_again_4_x=TPData.pre_x[i];
									u_again_4_y=TPData.pre_y[i];
								}
							}
							break;
						}				
					}
				}
			}
}

void dectect_four()
{
	dectect_rank();
	static int u_four_1_x,u_four_1_y,u_four_2_x,u_four_2_y;
	static int u_four_3_x,u_four_3_y,u_four_4_x,u_four_4_y;
	static int u_four_previous_x,u_four_previous_y;
	static int u_rank_x,u_rank_y;
	for(int i=0;i<TPData.TouchNum;i++)
		{
//			if(TPData.pre_x[i]>20)//����������޶��䴥����Ч�ķ�Χ
//			{
				for(int j=0;j<4;j++)
			  {
					if(button_four[j]->wake==0)
					{ 
						if(TPData.pre_x[i]>=button_four[j]->x&&TPData.pre_x[i]<=button_four[j]->x+button_four[j]->width
						&&TPData.pre_y[i]>=button_four[j]->y&&TPData.pre_y[i]<=button_four[j]->y+button_four[j]->height)
						{
							button_four[j]->wake=1;
							button_four[j]->ID=j;
							if(u_four_1.wake==1)//��¼u_reset��ť�����µ�λ��
							{
								if(TPData.pre_x[i]==u_four_1_x&&TPData.pre_y[i]==u_four_1_y)
									u_four_1.wake=0;
								else
								{
									u_four_1_x=TPData.pre_x[i];
									u_four_1_y=TPData.pre_y[i];
								}
							}
							if(u_four_2.wake==1)
							{
								if(TPData.pre_x[i]==u_four_2_x&&TPData.pre_y[i]==u_four_2_y)
									u_four_2.wake=0;
								else
								{
									u_four_2_x=TPData.pre_x[i];
									u_four_2_y=TPData.pre_y[i];
								}
							}
								if(u_four_3.wake==1)
							{
								if(TPData.pre_x[i]==u_four_3_x&&TPData.pre_y[i]==u_four_3_y)
									u_four_3.wake=0;
								else
								{
									u_four_3_x=TPData.pre_x[i];
									u_four_3_y=TPData.pre_y[i];
								}
							}
								if(u_four_4.wake==1)
							{
								if(TPData.pre_x[i]==u_four_4_x&&TPData.pre_y[i]==u_four_4_y)
									u_four_4.wake=0;
								else
								{
									u_four_4_x=TPData.pre_x[i];
									u_four_4_y=TPData.pre_y[i];
								}
							}
							break;
						}				
					}
				}
			}
			for(int i=0;i<TPData.TouchNum;i++){
			  if(button_four_previous[0]->wake==0)
					{
						if(TPData.pre_x[i]>=button_four_previous[0]->x&&TPData.pre_x[i]<=button_four_previous[0]->x+button_four_previous[0]->width
						&&TPData.pre_y[i]>=button_four_previous[0]->y&&TPData.pre_y[i]<=button_four_previous[0]->y+button_four_previous[0]->height)
						  {
							   button_four_previous[0]->wake=1;
							   button_four_previous[0]->ID=0;
				         if(u_four_previous.wake==1)
				            {
					             if(TPData.pre_x[i]==u_four_previous_x&&TPData.pre_y[i]==u_four_previous_y)
							              u_four_previous.wake=0;
					              else
				                {
					                  u_four_previous_x=TPData.pre_x[i];
					                  u_four_previous_y=TPData.pre_y[i];
				                }
				            }	
	               break;	
					     }					
					 }
		} 
}

void dectect_modeSelect()
{
	
	static int u_fourChannel_x,u_fourChannel_y,u_eightChannel_x,u_eightChannel_y;
	for(int i=0;i<TPData.TouchNum;i++)
		{
//			if(TPData.pre_x[i]>20)//����������޶��䴥����Ч�ķ�Χ
//			{
				for(int j=0;j<2;j++)
			  {
					if(button_channelMode[j]->wake==0)
					{ 
						if(TPData.pre_x[i]>=button_channelMode[j]->x&&TPData.pre_x[i]<=button_channelMode[j]->x+button_channelMode[j]->width
						&&TPData.pre_y[i]>=button_channelMode[j]->y&&TPData.pre_y[i]<=button_channelMode[j]->y+button_channelMode[j]->height)
						{
							button_channelMode[j]->wake=1;
							button_channelMode[j]->ID=j;
							if(u_fourChannel.wake==1)//��¼u_reset��ť�����µ�λ��
							{
								if(TPData.pre_x[i]==u_fourChannel_x&&TPData.pre_y[i]==u_fourChannel_y)
									u_fourChannel.wake=0;
								else
								{
									u_fourChannel_x=TPData.pre_x[i];
									u_fourChannel_y=TPData.pre_y[i];
								}
							}
							if(u_eightChannel.wake==1)
							{
								if(TPData.pre_x[i]==u_eightChannel_x&&TPData.pre_y[i]==u_eightChannel_y)
									u_eightChannel.wake=0;
								else
								{
									u_eightChannel_x=TPData.pre_x[i];
									u_eightChannel_y=TPData.pre_y[i];
								}
							}
							break;
						}				
					}
				}
//		}		
		}
}

void show_Pattern_8()
{
//	move_Image_Asm_565(u_begin.x,u_begin.y,u_begin.width,u_begin.height,begin_0+2);//1
//	move_Image_Asm_565(u_stop.x,u_stop.y,u_stop.width,u_stop.height,halt_0+2);//2
//	move_Image_Asm_565(u_reset.x,u_reset.y,u_reset.width,u_reset.height,reset_0+2);//3
//	move_Image_Asm_565(u_upload.x,u_upload.y,u_upload.width,u_upload.height,upload_0+2);//4
//	move_Image_Asm_565(u_emit.x,u_emit.y,u_emit.width,u_emit.height,emit_0+2);//8
//	move_Image_Asm_565(u_rec.x,u_rec.y,u_rec.width,u_rec.height,rec_0+2);//7
//	move_Image_Asm_565(u_heart.x,u_heart.y,u_heart.width,u_heart.height,heart_0+2);//6
//	move_Image_Asm_565(u_channel4.x,u_channel4.y,u_channel4.width,u_channel4.height,channel4_0+2);//5
	
	
	move_Image_Asm_565(u_begin.x,u_begin.y,u_begin.width,u_begin.height,channel4_0+2);//1
	move_Image_Asm_565(u_stop.x,u_stop.y,u_stop.width,u_stop.height,heart_0+2);//2
	move_Image_Asm_565(u_reset.x,u_reset.y,u_reset.width,u_reset.height,rec_0+2);//3
	move_Image_Asm_565(u_upload.x,u_upload.y,u_upload.width,u_upload.height,emit_0+2);//4
	move_Image_Asm_565(u_emit.x,u_emit.y,u_emit.width,u_emit.height,upload_0+2);//8
	move_Image_Asm_565(u_rec.x,u_rec.y,u_rec.width,u_rec.height,reset_0+2);//7
	move_Image_Asm_565(u_heart.x,u_heart.y,u_heart.width,u_heart.height,halt_0+2);//6
	move_Image_Asm_565(u_channel4.x,u_channel4.y,u_channel4.width,u_channel4.height,begin_0+2);//5
	
	move_Image_Asm_565(u_play.x,u_play.y,u_play.width,u_play.height,play_0+2);
	move_Image_Asm_565(u_clear.x,u_clear.y,u_clear.width,u_clear.height,clear_0+2);
	//move_Image_Asm_565(700,400-200,70,140,info+2);
	move_Image_Asm_565(u_switch.x,u_switch.y,u_switch.width,u_switch.height,select_0+2);
	move_Image_Asm_565(u_clear.x,u_clear.y,u_clear.width,u_clear.height,clear_0+2);	
	move_Image_Asm_565(u_four_previous.x,u_four_previous.y,u_four_previous.height,u_four_previous.width,left_0+2);
	move_Image_Asm_565(u_show.x,u_show.y,u_show.height,u_show.width,show_0+2);
	move_Image_Asm_565(u_order.x,u_order.y,u_order.height,u_order.width,order_0+2);
//	move_Image_Asm_565(u_eight_con1.x,u_eight_con1.y,u_eight_con1.height,u_eight_con1.width,con_play_0+2);
//	move_Image_Asm_565(u_eight_con2.x,u_eight_con2.y,u_eight_con2.height,u_eight_con2.width,con_play_0+2);
//	move_Image_Asm_565(u_eight_con3.x,u_eight_con3.y,u_eight_con3.height,u_eight_con3.width,con_play_0+2);
//	move_Image_Asm_565(u_eight_con4.x,u_eight_con4.y,u_eight_con4.height,u_eight_con4.width,con_play_0+2);
//	move_Image_Asm_565(u_eight_con5.x,u_eight_con5.y,u_eight_con5.height,u_eight_con5.width,con_play_0+2);
//	move_Image_Asm_565(u_eight_con6.x,u_eight_con6.y,u_eight_con6.height,u_eight_con6.width,con_play_0+2);
//	move_Image_Asm_565(u_eight_con7.x,u_eight_con7.y,u_eight_con7.height,u_eight_con7.width,con_play_0+2);
//	move_Image_Asm_565(u_eight_con8.x,u_eight_con8.y,u_eight_con8.height,u_eight_con8.width,con_play_0+2);
	move_Image_Asm_565(u_file.x,u_file.y,u_file.height,u_file.width,file_0+2);
}

void show_Pattern_4()
{
	move_Image_Asm_565(700,400,70,140,info+2);
	move_Image_Asm_565(u_four_previous.x,u_four_previous.y,u_four_previous.height,u_four_previous.width,left_0+2);
	move_Image_Asm_565(u_four_1.x,u_four_1.y,u_four_1.width,u_four_1.height,begin_0+2);
	move_Image_Asm_565(u_four_2.x,u_four_2.y,u_four_2.width,u_four_2.height,halt_0+2);
	move_Image_Asm_565(u_four_3.x,u_four_3.y,u_four_3.width,u_four_3.height,reset_0+2);
	move_Image_Asm_565(u_four_4.x,u_four_4.y,u_four_4.width,u_four_4.height,upload_0+2);
	move_Image_Asm_565(u_select_4.x,u_select_4.y,u_select_4.width,u_select_4.height,select_0+2);
	move_Image_Asm_565(u_rank.x,u_rank.y,u_rank.width,u_rank.height,play_0+2);
	move_Image_Asm_565(u_again_4.x,u_again_4.y,u_again_4.width,u_again_4.height,clear_0+2);
}
		
/*������ָ���Ƿ��͵�ָ��*/
void send_command(int num)
{
}

void move()//�ƶ�
{
}

void save_data()
{
}

void gui_enter()
{
	 enter_initial();
	move_Image_Asm_565(0,0,800,1280,bg+2);
	 move_Image_Asm_565(330,560,70,70,enter_0+2);	//���ӽ��밴ť
	 move_Image_Asm_565(u_load.x,u_load.y,u_load.width,u_load.height,load_0+2);
}

void gui_channel_selct()
{
	LCD_Clear(LCD_COLOR_WHITE);
	move_Image_Asm_565(0,0,800,1280,channelMode+2);
	modeSelect_initial();
	move_Image_Asm_565(u_fourChannel.x,u_fourChannel.y,u_fourChannel.width,u_fourChannel.height,mode4+2);
	move_Image_Asm_565(u_eightChannel.x,u_eightChannel.y,u_eightChannel.width,u_eightChannel.height,mode8+2);
	move_Image_Asm_565(700,0,100,80,left_0+2);
	select_enter_pre = 0;//���ť
}

void gui_channel_4()
{
	LCD_Clear(LCD_COLOR_WHITE);
	move_Image_Asm_565(0,0,800,1280,background+2);
	GUI_Init_my_chart_4();
	coordinate();
	four_initial();
	previous();
	show_Pattern_4();
	u_four_1_click= 0;
	u_four_2_click = 0;
	u_four_3_click =0;
	u_four_4_click = 0;
	//printf("u_four_prevoius.x= %d,u_four_prevoius.x= %d",u_four_previous.x,u_four_previous.y);
}

void gui_channel_8()
{
	LCD_Clear(LCD_COLOR_WHITE);
	move_Image_Asm_565(0,0,800,1280,background+2);
	controll_initial();
	previous();
	GUI_Init_my_chart();
	//GUI_Init_my_chart();
	coordinate();
	show_Pattern_8();
	u_begin_click = 0;
  u_halt_click=0;
	u_reset_click=0;
	u_upload_click=0;
  u_heart_click = 0;
  u_emit_click = 0;
  u_channel4_click = 0;
  u_rec_click = 0;//�����ص�ʱ���õ��������Ϊ��
}

void delay(u32 time)
{    
   u32 i=0;  
   while(time--)
   {
      i=120000; 
      while(i--);    
   }
}

void show_message(int num)
{
	switch(num)
	{
		case 1:
		{move_Image_Asm_565(722,550-200,27,15,num1+2);break;}//���ϵ�ͼ�꣬��ʼ
		case 2:
		{move_Image_Asm_565(722,550-200,27,15,num2+2);break;}//���ϵ�ͼ�꣬��ͣ
		case 3:
		{move_Image_Asm_565(722,550-200,27,15,num3+2);break;}//���ϵ�ͼ�꣬����
		case 4:
		{move_Image_Asm_565(722,550-200,27,15,num4+2);break;}//���ϵ�ͼ��,�ϴ�  	
		case 5:
		{move_Image_Asm_565(722,550-200,27,15,num5+2);break;}
		case 6:
		{move_Image_Asm_565(722,550-200,27,15,num6+2);break;}
		case 7:
		{move_Image_Asm_565(722,550-200,27,15,num7+2);break;}
		case 8:
		{move_Image_Asm_565(722,550-200,27,15,num8+2);break;} 
		default:
		break;
	}
}

void draw_channel_1()
{
	    channel_space = 320;
			clear = 0;//�����
			channel_order = 0;
			read_data();
}

void draw_channel_2()
{
	   channel_space = 240;
		clear = 0;//�����
		channel_order = 1;
	  read_data();
}

void draw_channel_3()
{
	  channel_space = 160;clear = 0;//�����
	  channel_order = 2;
	  read_data();
}

void draw_channel_4()
{
	channel_space = 80;
	clear = 0;//�����
	channel_order = 3;
	read_data();
}

void draw_channel_5()
{
	channel_space = 0;
	clear = 0;//�����
	channel_order = 4;
	read_data();
}

void draw_channel_6()
{
	channel_space = -80;
	clear = 0;//�����
	channel_order = 5;
	read_data();
}

void draw_channel_7()
{
		channel_space = -160;
	clear = 0;//�����
	channel_order = 6;
	read_data();
}

void draw_channel_8()
{
	channel_space = -240;
	clear = 0;//�����
	channel_order = 7;
	read_data();
}


void button_act_8()//�����Ĳ���
{
	//��ʼ
	if(u_begin.wake)
	{
		if(return_previous==0)
		{
	  u_begin_click++;
		u_begin.wake=0;
		if(u_begin_click%2==0)
		{
		  move_Image_Asm_565(u_begin.x,u_begin.y,u_begin.width,u_begin.height,begin_1+2);
			channel_space = 320;
			clear = 0;//�����
			channel_order = 0;
		  circle_begin=0;
			read_data();
		}
	  else
	  {
			Draw_ColorRect(280+320,125,80,1025,LCD_COLOR565_WHITE);
      GUI_Init_my_chart();
      move_Image_Asm_565(u_begin.x,u_begin.y,u_begin.width,u_begin.height,begin_0+2);
	  }
	}
	}

	
	 //��ͣ
	if(u_stop.wake)
	{	
		if(return_previous==0){
		u_halt_click++;
		u_stop.wake = 0;
		if(u_halt_click%2==0){
		channel_space = 240;
		clear = 0;//�����
		channel_order = 1;
		move_Image_Asm_565(u_stop.x,u_stop.y,u_stop.width,u_stop.height,halt_1+2);	
			circle_begin=0;
		read_data();
		show_click++;
		//order = 0;	
	  }
	  else
	  {
	   move_Image_Asm_565(u_stop.x,u_stop.y,u_stop.width,u_stop.height,halt_0+2);	
		 Draw_ColorRect(280+240,125,80,1025,LCD_COLOR565_WHITE);
     GUI_Init_my_chart();
	 }
     }
}
	
	//��λ
		if(u_reset.wake)
	{
		if(return_previous==0){
			  u_reset_click++;
			  u_reset.wake=0;
		  if(u_reset_click%2==0){
		     channel_space = 160;
			   clear = 0;//�����
			   channel_order = 2;
				move_Image_Asm_565(u_reset.x,u_stop.y,u_reset.width,u_reset.height,reset_1+2);
         circle_begin=0;				
			   read_data();        	
	   }
	else
	{
		move_Image_Asm_565(u_reset.x,u_reset.y,u_reset.width,u_reset.height,reset_0+2);
		Draw_ColorRect(280+160,125,80,1025,LCD_COLOR565_WHITE);
    GUI_Init_my_chart();
	}
    }
}
	
//�ϴ�
	if(u_upload.wake)
  { 
		if(return_previous==0)
		{
			  u_upload_click++;
			  u_upload.wake=0;
		  if(u_upload_click%2==0){
		     channel_space = 80;
			   clear = 0;//�����
			   channel_order = 3;
				 move_Image_Asm_565(u_upload.x,u_upload.y,u_upload.width,u_upload.height,upload_1+2);
				circle_begin=0;
			   read_data();
//		   W_download_SD();
	   }
	    else
	   {	
	     move_Image_Asm_565(u_upload.x,u_upload.y,u_upload.width,u_upload.height,upload_0+2);
			 Draw_ColorRect(280+80,125,80,1025,LCD_COLOR565_WHITE);
       GUI_Init_my_chart();
	   }
	 }
 }
	
	//���
	if(u_clear.wake)
	{		if(return_previous==0)
		{
		   move_Image_Asm_565(u_clear.x,u_clear.y,u_clear.width,u_clear.height,clear_1+2);
		   delay(100);
		   move_Image_Asm_565(u_clear.x,u_clear.y,u_clear.width,u_clear.height,clear_0+2);
		   gui_channel_8();
		   rank= 0;
       circle_begin=0;
			 temp1=temp2=temp3=temp4=temp5=temp6=temp7=temp8=0;
			 file_order = 0;
		   space_1 = 320;space_2 = 240;space_3 = 160;space_4 = 80;space_5 = 0;
       space_6 = -80;space_7 = -160;space_8 = -240;
			 printf("space_1 = %d,space_2 =  = %d,space_3 =  = %d,space_4 =  = %d,space_5 =  = %d,space_6 =  = %d,space_7 =  = %d,space_8 =  = %d",
			space_1 ,space_2 ,space_3 ,space_4 ,space_5, space_6 ,space_7 ,space_8 );
		   u_clear.wake=0;
	}
}
	
	//����
	if(1==u_emit.wake)
{
		if(return_previous==0)
	  {
		u_emit_click++;
		u_emit.wake = 0;
		if(u_emit_click%2==0)
		{
			channel_space = -240;
		  move_Image_Asm_565(u_emit.x,u_emit.y,u_emit.width,u_emit.height,emit_1+2);
			clear = 0;//�����
			channel_order = 7;
			circle_begin=0;
			read_data();
	  }
		else
	  {
       Draw_ColorRect(280-240,125,80,1025,LCD_COLOR565_WHITE);
       GUI_Init_my_chart();
		   move_Image_Asm_565(u_emit.x,u_emit.y,u_emit.width,u_emit.height,emit_0+2);
    }
}}
	
	//����
		if(u_rec.wake)
	{
		if(return_previous==0)
	{
		u_rec_click++;
		u_rec.wake = 0;
		if(u_rec_click%2==0)
		{
			channel_space = -160;
			clear = 0;//�����
			channel_order = 6;
			move_Image_Asm_565(u_rec.x,u_rec.y,u_rec.width,u_rec.height,rec_1+2);
			circle_begin=0;
			read_data();
		//sigProcess_1();
		}
	else
	{
    Draw_ColorRect(280-160,125,80,1025,LCD_COLOR565_WHITE);
    GUI_Init_my_chart();
		//clear_read_File_channel_1();
		move_Image_Asm_565(u_rec.x,u_rec.y,u_rec.width,u_rec.height,rec_0+2);
	}
}}
	
	//����
	if(u_heart.wake)
	{
		if(return_previous==0)
	{
		u_heart_click++;
		u_heart.wake = 0;
		if(u_heart_click%2==0)
		{
		channel_space = -80;
		move_Image_Asm_565(u_heart.x,u_heart.y,u_heart.width,u_heart.height,heart_1+2);
		clear = 0;//�����
		channel_order = 5;
		circle_begin=0;
		read_data();
		u_heart.wake = 0;
	}else
	{
		Draw_ColorRect(280-80,125,80,1025,LCD_COLOR565_WHITE);
    GUI_Init_my_chart();
		move_Image_Asm_565(u_heart.x,u_heart.y,u_heart.width,u_heart.height,heart_0+2);
	}
}
	}
	
	//ͨ��4
	if(u_channel4.wake)
	{
		if(return_previous==0)
	{
		u_channel4_click++;
		u_channel4.wake = 0;
		printf("click=%d\r\n",u_channel4_click);
		if(u_channel4_click%2==0)
		{
			channel_space = 0;
			clear = 0;//�����
			channel_order = 4;
			move_Image_Asm_565(u_channel4.x,u_channel4.y,u_channel4.width,u_channel4.height,channel4_1+2);
			circle_begin=0;
			read_data();
		}
	  else
	  {
			printf("okd");
		  move_Image_Asm_565(u_channel4.x,u_channel4.y,u_channel4.width,u_channel4.height,channel4_0+2);
		  Draw_ColorRect(280,125,80,1025,LCD_COLOR565_WHITE);
      GUI_Init_my_chart();
	  }
}}
	//��ʾǰ���Ĳ��εİ�ť
		if(u_show.wake)
{
		if(return_previous==0)
	{
		move_Image_Asm_565(u_show.x,u_show.y,u_show.width,u_show.height,show_1+2);
		delay(100);
		move_Image_Asm_565(u_show.x,u_show.y,u_show.width,u_show.height,show_0+2);
		clear_line();//���ȫ��������
		GUI_Init_my_chart();
		coordinate_con();
		draw_channel_1();
//		draw =1;//��ͼ
//		read_data_for_cal();
//	  printf("show\r\n");
//    read_data_for_cal();
		
		u_show.wake = 0;
  }
}
	//ѡ��ͨ����ť
	if(u_switch.wake)
	{
		if(return_previous==0)
	{
		move_Image_Asm_565(u_switch.x,u_switch.y,u_switch.width,u_switch.height,select_1+2);
		delay(100);
		move_Image_Asm_565(u_switch.x,u_switch.y,u_switch.width,u_switch.height,select_0+2);
//    rank ++;
//		show_message(rank);	
		
	  u_switch.wake = 0;
	}
 }
	
	//���򲥷�
   		if(u_order.wake)
	{
		if(return_previous==0)
	{
		move_Image_Asm_565(u_order.x,u_order.y,u_order.width,u_order.height,order_1+2);
		delay(100);
		move_Image_Asm_565(u_order.x,u_order.y,u_order.width,u_order.height,order_0+2);
		clear_line();
		GUI_Init_my_chart();//��ԭ����
		draw= 2;//����
		read_data_for_cal();
		read_data();
		//Rocker(1);
		printf("order\r\n");
//    read_data_for_cal();
		u_order.wake = 0;
}}

	//����
	if(u_play.wake)
	{
		if(return_previous==0)
	{
		//Rocker(1);
		show_click_play++;
		move_Image_Asm_565(u_play.x,u_play.y,u_play.width,u_play.height,play_1+2);	
//		draw_channel_1();draw_channel_2();draw_channel_3();draw_channel_4();
//		draw_channel_5();draw_channel_6();draw_channel_7();draw_channel_8();
		clear = 0;//�����
		read_data();
		move_Image_Asm_565(u_play.x,u_play.y,u_play.width,u_play.height,play_0+2);	
		u_play.wake = 0;
}
}

	if(u_file.wake)
	{
		if(return_previous==0)
	{
		move_Image_Asm_565(u_file.x,u_file.y,u_file.width,u_file.height,file_1+2);
		delay(100);
		move_Image_Asm_565(u_file.x,u_file.y,u_file.width,u_file.height,file_0+2);
		file_order++;
		printf("%d",file_order);
		//printf("sizeof ��Ļ����:%d\r\n",sizeof(LCD_FRAME_BUFFER)/4);
		u_file.wake = 0;
}
	}
	//���밴ť
		if(u_enter.wake)
	{
		if(enter_active ==1)
		{
  		LCD_Clear(LCD_COLOR_WHITE);//����	
			gui_channel_selct();//ͨ��ѡ��ҳ��
			enter_active = 0;//ʹ֮ʧЧ
			u_enter.wake = 0;
		}
	}
	  //���հ�ť
		if(u_load.wake)
	{
				if(enter_active ==1)
		{
     //printf("load\r\n");
		 move_Image_Asm_565(u_load.x,u_load.y,u_load.width,u_load.height,load_1+2);
		 delay(100);
		 move_Image_Asm_565(u_load.x,u_load.y,u_load.width,u_load.height,load_0+2);
		 linsi_status = 1;//wifi���ر�־
		 //delay(2500);
		 //move_Image_Asm_565(345,820,40,160,rec_finished+2);
		 u_load.wake=0;
	}
}
	if(u_select_enter_pre.wake)
	{
		if(select_enter_pre ==0)
		{
		printf("previous");
		LCD_Clear(LCD_COLOR_WHITE);
		select_enter_pre = 1;//������һ���ð�ťʧЧ
		gui_enter();
		enter_active = 1;//������һ����ʱ����Ч
		u_select_enter_pre.wake = 0;
	}
}
	
	if(u_fourChannel.wake)
	{
		if(select_enter_pre ==0)
		{
		  printf("u_fourChannel\r\n");
		  gui_channel_4();
		  sort=4;//ѡ���ĸ�ͨ��������ʽ
      ratio = 1;//�ֱ���
		  channel_select = 4;//ѡ��ͨ�����ļ�
		  extent = 20;//���εķ���
		  gap_coordinate = 2;//������ļ��
		  initial_position = 53+40;//��ʼλ��
		  return_previous_4 = 0 ;
			select_enter_pre = 1;//�ý���İ�ťʧЧ
		  circle = 10;
		  u_fourChannel.wake = 0;
		  rank_4= 0;
	}
}
	
		if(u_eightChannel.wake)
	{
		if(select_enter_pre == 0)
		{
		  LCD_Clear(LCD_COLOR_WHITE);
		  gui_channel_8();
		  sort=8;//ѡ���ĸ�ͨ��������ʽ
      ratio = 6;//�ֱ���12�����õĲ�����4,
		  channel_select = 8;//ѡ��ͨ�����ļ�
		  extent = 60;//���εķ��ȣ�֮ǰ��60
		  gap_coordinate = 1;//������ļ��
		  initial_position = 315.0*2-40+10;//��ʼλ��,���
		  return_previous = 0;
			select_enter_pre = 1;//�ý����ʧЧ
		  circle = 200;
		  rank = 0;
		  u_eightChannel.wake = 0;
		}
	}
}

void button_act_con()
{
	//������
	if(u_eight_con1.wake)
	{		
		if(return_previous==0)
	   {	
			 move_Image_Asm_565(u_eight_con1.x,u_eight_con1.y,u_eight_con1.height,u_eight_con1.width,con_play_1+2);
			 delay(100);
			 move_Image_Asm_565(u_eight_con1.x,u_eight_con1.y,u_eight_con1.height,u_eight_con1.width,con_play_0+2);
       con8_click++;		 
			 if(con8_click==1)
			 {
				 printf("16");
				 circle_begin = 102;//�ֱ���Ϊ1��ʱ��,Ϊ16
			 }
			 else{
				   printf("else");
				   circle_begin = temp8;
				 	 circle_begin+=102;
			 }
			 Draw_ColorRect(280-240,125,80,1025,LCD_COLOR565_WHITE);
			 GUI_Init_my_chart();
			 draw_channel_8();
			 u_eight_con1.wake= 0;
		 }
	}
		if(u_eight_con2.wake)
	{		
		if(return_previous==0)
	   {
			 move_Image_Asm_565(u_eight_con2.x,u_eight_con2.y,u_eight_con2.height,u_eight_con2.width,con_play_1+2);
			 delay(100);
			 move_Image_Asm_565(u_eight_con2.x,u_eight_con2.y,u_eight_con2.height,u_eight_con2.width,con_play_0+2);
			 	con7_click++;
			 //��һ�ε�������������ĵ���֮����circle_begin���ܴ�ͷ��ʼ
			 if(con7_click==1)
			 {
				 printf("16\r\n");
				 circle_begin = 102;
			 }
			 else{
				 printf("else\r\n");
				   circle_begin = temp7;
				 	 circle_begin+=102;
			 }
			 printf("circle_begin= %d\r\n",circle_begin);
			 temp7=circle_begin;//������circle
			 Draw_ColorRect(280-160,125,80,1025,LCD_COLOR565_WHITE);
			 GUI_Init_my_chart();
			 draw_channel_7();
			 u_eight_con2.wake= 0;
		 }
	}
		if(u_eight_con3.wake)
	{		
		if(return_previous==0)
	   {
			 move_Image_Asm_565(u_eight_con3.x,u_eight_con3.y,u_eight_con3.height,u_eight_con3.width,con_play_1+2);
			 delay(100);
			 move_Image_Asm_565(u_eight_con3.x,u_eight_con3.y,u_eight_con3.height,u_eight_con3.width,con_play_0+2);
			 	con6_click++;
			 //��һ�ε�������������ĵ���֮����circle_begin���ܴ�ͷ��ʼ
			 if(con6_click==1)
			 {
				 printf("16\r\n");
				 circle_begin = 102;
			 }
			 else{
				 printf("else\r\n");
				   circle_begin = temp6;
				 	 circle_begin+=102;
			 }
			 printf("circle_begin= %d\r\n",circle_begin);
			 temp6=circle_begin;//������circle
			 Draw_ColorRect(280-80,125,80,1025,LCD_COLOR565_WHITE);
			 GUI_Init_my_chart();
			 draw_channel_6();
			 u_eight_con3.wake= 0;
		 }
	}
		if(u_eight_con4.wake)
	{		
		if(return_previous==0)
	   {
			 move_Image_Asm_565(u_eight_con4.x,u_eight_con4.y,u_eight_con4.height,u_eight_con4.width,con_play_1+2);
			 delay(100);
			 move_Image_Asm_565(u_eight_con4.x,u_eight_con4.y,u_eight_con4.height,u_eight_con4.width,con_play_0+2);
			 	con5_click++;
			 //��һ�ε�������������ĵ���֮����circle_begin���ܴ�ͷ��ʼ
			 if(con5_click==1)
			 {
				 printf("16\r\n");
				 circle_begin = 102;
			 }
			 else{
				 printf("else\r\n");
				   circle_begin = temp5;
				 	 circle_begin+=102;
			 }
			 printf("circle_begin= %d\r\n",circle_begin);
			 temp5=circle_begin;//������circle
			 Draw_ColorRect(280,125,80,1025,LCD_COLOR565_WHITE);
			 GUI_Init_my_chart();
			 draw_channel_5();
			 u_eight_con4.wake= 0;
		 }
	}
		if(u_eight_con5.wake)
	{		
			 move_Image_Asm_565(u_eight_con5.x,u_eight_con5.y,u_eight_con5.height,u_eight_con5.width,con_play_1+2);
			 delay(100);
			 move_Image_Asm_565(u_eight_con5.x,u_eight_con5.y,u_eight_con5.height,u_eight_con5.width,con_play_0+2);
		if(return_previous==0)
	   {
			 con4_click++;
			 //��һ�ε�������������ĵ���֮����circle_begin���ܴ�ͷ��ʼ
			 if(con4_click==1)
			 {
				 printf("16\r\n");
				 circle_begin = 102;
			 }
			 else{
				 printf("else\r\n");
				   circle_begin = temp4;
				 	 circle_begin+=102;
			 }
			 printf("circle_begin= %d\r\n",circle_begin);
			 temp4=circle_begin;//������circle
			 Draw_ColorRect(280+80,125,80,1025,LCD_COLOR565_WHITE);
			 GUI_Init_my_chart();
			 draw_channel_4();
			 u_eight_con5.wake= 0;
		 }
	}
		if(u_eight_con6.wake)
	{		
		if(return_previous==0)
	   {
			 move_Image_Asm_565(u_eight_con6.x,u_eight_con6.y,u_eight_con6.height,u_eight_con6.width,con_play_1+2);
			 delay(100);
			 move_Image_Asm_565(u_eight_con6.x,u_eight_con6.y,u_eight_con6.height,u_eight_con6.width,con_play_0+2);
			 	con3_click++;
			 //��һ�ε�������������ĵ���֮����circle_begin���ܴ�ͷ��ʼ
			 if(con3_click==1)
			 {
				 printf("16\r\n");
				 circle_begin = 102;//16��ָ���ǲ�����Ϊ1
			 }
			 else{
				 printf("else\r\n");
				   circle_begin = temp3;
				 	 circle_begin+=102;
			 }
			 printf("circle_begin= %d\r\n",circle_begin);
			 temp3=circle_begin;//������circle
			 Draw_ColorRect(280+160,125,80,1025,LCD_COLOR565_WHITE);
			 GUI_Init_my_chart();
			 draw_channel_3();
			 u_eight_con6.wake= 0;
		 }
	}
		if(u_eight_con7.wake)
	{		
		if(return_previous==0)
	   {
			 move_Image_Asm_565(u_eight_con7.x,u_eight_con7.y,u_eight_con7.height,u_eight_con7.width,con_play_1+2);
			 delay(100);
			 move_Image_Asm_565(u_eight_con7.x,u_eight_con7.y,u_eight_con7.height,u_eight_con7.width,con_play_0+2);
			 con2_click++;
			 //��һ�ε�������������ĵ���֮����circle_begin���ܴ�ͷ��ʼ
			 if(con2_click==1)
			 {
				 printf("16\r\n");
				 circle_begin = 102;
			 }
			 else{
				 printf("else\r\n");
				   circle_begin = temp2;
				 	 circle_begin+=102;
			 }
			 printf("circle_begin= %d\r\n",circle_begin);
			 temp2=circle_begin;//������circle
			 Draw_ColorRect(280+240,125,80,1025,LCD_COLOR565_WHITE);
			 GUI_Init_my_chart();
			 draw_channel_2();
			 u_eight_con7.wake= 0;
		 }
	}
		if(u_eight_con8.wake)
	{		
		if(return_previous==0)
	   {
			 move_Image_Asm_565(u_eight_con8.x,u_eight_con8.y,u_eight_con8.height,u_eight_con8.width,con_play_1+2);
			 delay(100);
			 move_Image_Asm_565(u_eight_con8.x,u_eight_con8.y,u_eight_con8.height,u_eight_con8.width,con_play_0+2);
			 printf("test\r\n");
			 con1_click++;
			 //��һ�ε�������������ĵ���֮����circle_begin���ܴ�ͷ��ʼ
			 if(con1_click==1)
			 {
				 printf("16\r\n");
				 circle_begin = 102;
			 }
			 else{
				 printf("else\r\n");
				   circle_begin = temp1;
				 	 circle_begin+=102;
			 }
			 printf("circle_begin= %d\r\n",circle_begin);
			 temp1=circle_begin;//������circle
  		 Draw_ColorRect(280+320,127,78,1025,LCD_COLOR565_WHITE);//125,80
			 //Draw_ColorRect(0,125,36,1025,LCD_COLOR565_WHITE);//125,80
			 GUI_Init_my_chart();
			 coordinate_con();
			 draw_channel_1();
			 u_eight_con8.wake= 0;
		 }
	}
}

void button_act_4()
{
	if(u_four_1.wake)
	{	
		if(return_previous_4 ==0){
     u_four_1_click ++;
		 u_four_1.wake=0;
     if(u_four_1_click%2==0){
		    channel_space = 0;
		    clear = 0;//�����
		    channel_order = 0;
			  move_Image_Asm_565(u_four_1.x,u_four_1.y,u_four_1.width,u_four_1.height,begin_1+2);
		    read_data();
		}
		 else{
			  move_Image_Asm_565(u_four_1.x,u_four_1.y,u_four_1.width,u_four_1.height,begin_0+2);
			  Draw_ColorRect(0+40+5,125,140,1155,LCD_COLOR565_WHITE);
        GUI_Init_my_chart_4();
		 }
	}
}
		if(u_four_2.wake)
	{			
		if(return_previous_4 ==0){	
    u_four_2_click ++;
		u_four_2.wake=0;
		if(u_four_2_click%2==0){
		   channel_space = 150*1;
		   clear = 0;//�����
		   channel_order = 1;
			 move_Image_Asm_565(u_four_2.x,u_four_2.y,u_four_2.width,u_four_2.height,halt_1+2);
		   read_data();
		}
		else{
				move_Image_Asm_565(u_four_2.x,u_four_2.y,u_four_2.width,u_four_2.height,halt_0+2);
			  Draw_ColorRect(150+40+5,125,140,1155,LCD_COLOR565_WHITE);
        GUI_Init_my_chart_4();
		}
	}
}
		if(u_four_3.wake)
	{	
		if(return_previous_4 ==0){
			 u_four_3_click ++;
		   u_four_3.wake=0;
		   if(u_four_3_click%2==0){
		      channel_space = 150*2;
		      clear = 0;//�����
		      channel_order = 2;
				  move_Image_Asm_565(u_four_3.x,u_four_3.y,u_four_3.width,u_four_3.height,reset_1+2); 
		      read_data();		
	     }
			 else{
				move_Image_Asm_565(u_four_3.x,u_four_3.y,u_four_3.width,u_four_3.height,reset_0+2);
			  Draw_ColorRect(150*2+40+5,125,140,1155,LCD_COLOR565_WHITE);
        GUI_Init_my_chart_4();
			 }
	}
}
		if(u_four_4.wake)
	{	
		if(return_previous_4 ==0){	
		   u_four_4_click ++;
		   u_four_4.wake=0;
		   if(u_four_4_click%2==0){
		      channel_space = 150*3;
		      clear = 0;//�����
		      channel_order = 3;
				  move_Image_Asm_565(u_four_4.x,u_four_4.y,u_four_4.width,u_four_4.height,upload_1+2);
		      read_data();
		      u_four_4.wake=0;
    	}
			 else{
				move_Image_Asm_565(u_four_4.x,u_four_4.y,u_four_4.width,u_four_4.height,upload_0+2);
			  Draw_ColorRect(150*3+40+5,125,140,1155,LCD_COLOR565_WHITE);
        GUI_Init_my_chart_4();
			 }
		}
}
	
	 if(u_four_previous.wake)
	 {
		 if(return_previous_4 ==0|return_previous==0){
		 gui_channel_selct();
		 return_previous_4 = 1;
		 return_previous = 1;//������һ�����ø�����ťʧЧ,8ͨ���İ�ť
		 circle = 0;
		 file_order = 0;
		 temp1=temp2=temp3=temp4=temp5=temp6=temp7=temp8=0;
		 u_four_previous.wake = 0;
	 }
}
	 if(u_select_4.wake)
	 {
		if(return_previous_4 ==0){
		   move_Image_Asm_565(u_select_4.x,u_select_4.y,u_select_4.width,u_select_4.height,select_1+2);
		   delay(100);
		   move_Image_Asm_565(u_select_4.x,u_select_4.y,u_select_4.width,u_select_4.height,select_0+2);
		   rank_4++;
		   show_message(rank_4);
		   u_select_4.wake=0;
	 }
 }
	 if(u_rank.wake)
	 {
		 if(return_previous_4 ==0){
		   read_data_for_cal_4();
			 printf("paixu");
		   u_rank.wake=0;
	 }
 }
	 	 if(u_again_4.wake)
	 {
		 if(return_previous_4 ==0){
		   move_Image_Asm_565(u_again_4.x,u_again_4.y,u_again_4.width,u_again_4.height,clear_1+2);
		   delay(100);
		   move_Image_Asm_565(u_again_4.x,u_again_4.y,u_again_4.width,u_again_4.height,clear_0+2);
		   gui_channel_4();
		   rank_4= 0;
		   u_again_4.wake=0;
	 }
 }
}

void remote_act()//��Ӧ�Ķ���
{
	if(initial)
{
//    move_Image_Asm_565(u_begin.x,u_begin.y,u_begin.width,u_begin.height,begin_0+2);
//	  move_Image_Asm_565(u_enter.x,u_emit.y,u_emit.width,u_emit.height,emit_0+2);
//	  move_Image_Asm_565(u_rec.x,u_rec.y,u_rec.width,u_rec.height,rec_0+2);
//    move_Image_Asm_565(u_heart.x,u_heart.y,u_heart.width,u_heart.height,heart_0+2);
//	  move_Image_Asm_565(u_channel4.x,u_channel4.y,u_channel4.width,u_channel4.height,channel4_0+2);
//  	move_Image_Asm_565(u_reset.x,u_reset.y,u_reset.width,u_reset.height,reset_0+2);
//		move_Image_Asm_565(u_stop.x,u_stop.y,u_stop.width,u_stop.height,halt_0+2);	
//	  move_Image_Asm_565(u_reset.x,u_reset.y,u_reset.width,u_reset.height,reset_0+2);
//	  move_Image_Asm_565(u_upload.x,u_upload.y,u_upload.width,u_upload.height,upload_0+2);
//    move_Image_Asm_565(u_emit.x,u_emit.y,u_emit.width,u_emit.height,emit_0+2);
//	  move_Image_Asm_565(u_switch.x,u_switch.y,u_switch.width,u_switch.height,emit_0+2);
		initial=0;
}
	              
	dectect();//̽����ˮƽ��ť
  detect_upright();//̽���䴹ֱ��ť
  dectect_enter();//̽������밴ť
  dectect_modeSelect();//̽����ͨ��ѡ��ť
  dectect_four();
  detect_con();
	//save_data();
	button_act_8();
  button_act_4();
  button_act_con();
}

