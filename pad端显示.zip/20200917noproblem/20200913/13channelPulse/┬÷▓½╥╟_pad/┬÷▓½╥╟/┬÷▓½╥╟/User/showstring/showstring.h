#ifndef __SHOWSTRING_H
#define	__SHOWSTRING_H
#include "stm32f4xx.h"
extern uint16_t ASCII[20*2756+2];
void KeyBoard_Init(void); 
void DisplayString(int x_pos, int y_pos, char *string);

#endif /* __SHOWSTRING_H */

