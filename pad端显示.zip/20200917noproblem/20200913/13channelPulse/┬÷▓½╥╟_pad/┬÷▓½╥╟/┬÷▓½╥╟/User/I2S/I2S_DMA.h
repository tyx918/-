#ifndef __I2S_DMA_H
#define __I2S_DMA_H
#include "stm32f4xx.h"




/*---------------------------------------------------------------------------------------------*/
/*------------------------   I2S�������ݴ��䲿��  ---------------------------------------------*/																					
/**
	* I2S���ߴ�����Ƶ���ݿ���
	* PB9/I2S2_WS
	* PD3/I2S2_CK
	* PC2/I2S2ext_SD
	* PI3/I2S2_SD
	*/
#define I2S2_CLK                       RCC_APB1Periph_SPI2
#define I2S2_I2Sx_SPI                  SPI2
#define I2S2_I2Sx_ext                  I2S2ext

#define I2S2_WS_GPIO_CLK               RCC_AHB1Periph_GPIOB
#define I2S2_WS_PORT            	     GPIOB
#define I2S2_WS_PIN             	     GPIO_Pin_9
#define I2S2_WS_AF                     GPIO_AF_SPI2
#define I2S2_WS_SOURCE                 GPIO_PinSource9

#define I2S2_CK_GPIO_CLK               RCC_AHB1Periph_GPIOD
#define I2S2_CK_PORT            	     GPIOD
#define I2S2_CK_PIN             	     GPIO_Pin_3
#define I2S2_CK_AF                     GPIO_AF_SPI2
#define I2S2_CK_SOURCE                 GPIO_PinSource3

#define I2S2ext_SD_GPIO_CLK            RCC_AHB1Periph_GPIOC
#define I2S2ext_SD_PORT                GPIOC
#define I2S2ext_SD_PIN                 GPIO_Pin_2
#define I2S2ext_SD_AF                  GPIO_AF_SPI3    //���� GPIO_AF6_SPI2 -> AF6
#define I2S2ext_SD_SOURCE              GPIO_PinSource2

#define I2S2_SD_GPIO_CLK               RCC_AHB1Periph_GPIOI
#define I2S2_SD_PORT                   GPIOI
#define I2S2_SD_PIN                    GPIO_Pin_3
#define I2S2_SD_AF                     GPIO_AF_SPI2
#define I2S2_SD_SOURCE                 GPIO_PinSource3
 
#define I2Sx_DMA                       DMA1
#define I2Sx_DMA_CLK                   RCC_AHB1Periph_DMA1
#define I2Sx_TX_DMA_CHANNEL            DMA_Channel_0
#define I2Sx_TX_DMA_STREAM             DMA1_Stream4
#define I2Sx_TX_DMA_IT_TCIF            DMA_IT_TCIF4
#define I2Sx_TX_DMA_STREAM_IRQn        DMA1_Stream4_IRQn 
#define I2Sx_TX_DMA_STREAM_IRQFUN			 DMA1_Stream4_IRQHandler

#define I2Sxext_RX_DMA_CHANNEL         DMA_Channel_3
#define I2Sxext_RX_DMA_STREAM          DMA1_Stream3
#define I2Sxext_RX_DMA_IT_TCIF         DMA_IT_TCIF3
#define I2Sxext_RX_DMA_STREAM_IRQn     DMA1_Stream3_IRQn 
#define I2Sxext_RX_DMA_STREAM_IRQFUN	 DMA1_Stream3_IRQHandler

extern void (*I2S_DMA_TX_Callback)(void);		//I2S DMA TX�ص�����ָ��  
extern void (*I2S_DMA_RX_Callback)(void);	  //I2S DMA RX�ص�����

void I2S_GPIO_Config(void);
void I2S_Stop(void);
void I2Sx_Mode_Config(const uint16_t _usStandard, const uint16_t _usWordLen,const uint32_t _usAudioFreq);
void I2Sx_TX_DMA_Init(const uint16_t *buffer0,const uint16_t *buffer1,const uint32_t num);
void I2S_Play_Start(void);
void I2S_Play_Stop(void);

void I2Sxext_Mode_Config(const uint16_t _usStandard, const uint16_t _usWordLen,const uint32_t _usAudioFreq);
void I2Sxext_RX_DMA_Init(const uint16_t *buffer0,const uint16_t *buffer1,const uint32_t num);
void I2Sxext_Recorde_Start(void);
void I2Sxext_Recorde_Stop(void);

#endif










