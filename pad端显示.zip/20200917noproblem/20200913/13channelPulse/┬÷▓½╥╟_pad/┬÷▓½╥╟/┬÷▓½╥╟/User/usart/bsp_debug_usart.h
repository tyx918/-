#ifndef __DEBUG_USART_H
#define	__DEBUG_USART_H

#include "stm32f4xx.h"
#include <stdio.h>
#include "./Bsp/spi_dma/bsp_spi_dma_comfig.h"

//����1���Ŷ���
/*******************************************************/
#define DEBUG_USART1                             USART1
#define DEBUG_USART1_CLK                         RCC_APB2Periph_USART1
#define DEBUG_USART1_BAUDRATE                    115200  //���ڲ�����

#define DEBUG_USART1_RX_GPIO_PORT                GPIOA
#define DEBUG_USART1_RX_GPIO_CLK                 RCC_AHB1Periph_GPIOA
#define DEBUG_USART1_RX_PIN                      GPIO_Pin_10
#define DEBUG_USART1_RX_AF                       GPIO_AF_USART1
#define DEBUG_USART1_RX_SOURCE                   GPIO_PinSource10

#define DEBUG_USART1_TX_GPIO_PORT                GPIOA
#define DEBUG_USART1_TX_GPIO_CLK                 RCC_AHB1Periph_GPIOA
#define DEBUG_USART1_TX_PIN                      GPIO_Pin_9
#define DEBUG_USART1_TX_AF                       GPIO_AF_USART1
#define DEBUG_USART1_TX_SOURCE                   GPIO_PinSource9

#define DEBUG_USART1_IRQHandler                  USART1_IRQHandler
#define DEBUG_USART1_IRQ                 				USART1_IRQn
/************************************************************/

//����2���Ŷ���
/*******************************************************/
#define DEBUG_USART2                             USART2
#define DEBUG_USART2_CLK                         RCC_APB1Periph_USART2
#define DEBUG_USART2_BAUDRATE                    115200  //���ڲ�����

#define DEBUG_USART2_RX_GPIO_PORT                GPIOD
#define DEBUG_USART2_RX_GPIO_CLK                 RCC_AHB1Periph_GPIOD
#define DEBUG_USART2_RX_PIN                      GPIO_Pin_6
#define DEBUG_USART2_RX_AF                       GPIO_AF_USART2
#define DEBUG_USART2_RX_SOURCE                   GPIO_PinSource6

#define DEBUG_USART2_TX_GPIO_PORT                GPIOD
#define DEBUG_USART2_TX_GPIO_CLK                 RCC_AHB1Periph_GPIOD
#define DEBUG_USART2_TX_PIN                      GPIO_Pin_5
#define DEBUG_USART2_TX_AF                       GPIO_AF_USART2
#define DEBUG_USART2_TX_SOURCE                   GPIO_PinSource5

#define DEBUG_USART2_IRQHandler                  USART2_IRQHandler
#define DEBUG_USART2_IRQ                 				USART2_IRQn
/************************************************************/



//����4���Ŷ���
/*******************************************************/
#define DEBUG_UART4                             UART4
#define DEBUG_UART4_CLK                         RCC_APB1Periph_UART4
#define DEBUG_UART4_ClockCmd                    RCC_APB1PeriphClockCmd
#define DEBUG_UART4_BAUDRATE                    115200  //���ڲ�����

#define DEBUG_UART4_RX_GPIO_PORT                GPIOA
#define DEBUG_UART4_RX_GPIO_CLK                 RCC_AHB1Periph_GPIOA
#define DEBUG_UART4_RX_PIN                      GPIO_Pin_1
#define DEBUG_UART4_RX_AF                       GPIO_AF_UART4
#define DEBUG_UART4_RX_SOURCE                   GPIO_PinSource1

#define DEBUG_UART4_TX_GPIO_PORT                GPIOA
#define DEBUG_UART4_TX_GPIO_CLK                 RCC_AHB1Periph_GPIOA
#define DEBUG_UART4_TX_PIN                      GPIO_Pin_0
#define DEBUG_UART4_TX_AF                       GPIO_AF_UART4
#define DEBUG_UART4_TX_SOURCE                   GPIO_PinSource0

#define DEBUG_UART4_IRQHandler                  UART4_IRQHandler
#define DEBUG_UART4_IRQ                 				UART4_IRQn
/************************************************************/

//����6���Ŷ���
/*******************************************************/
#define DEBUG_USART6                             USART6
#define DEBUG_USART6_CLK                         RCC_APB2Periph_USART6
#define DEBUG_USART6_ClockCmd                    RCC_APB2PeriphClockCmd
#define DEBUG_USART6_BAUDRATE                    115200 //���ڲ�����

#define DEBUG_USART6_RX_GPIO_PORT                GPIOG
#define DEBUG_USART6_RX_GPIO_CLK                 RCC_AHB1Periph_GPIOG
#define DEBUG_USART6_RX_PIN                      GPIO_Pin_9
#define DEBUG_USART6_RX_AF                       GPIO_AF_USART6
#define DEBUG_USART6_RX_SOURCE                   GPIO_PinSource9

#define DEBUG_USART6_TX_GPIO_PORT                GPIOC
#define DEBUG_USART6_TX_GPIO_CLK                 RCC_AHB1Periph_GPIOC
#define DEBUG_USART6_TX_PIN                      GPIO_Pin_6
#define DEBUG_USART6_TX_AF                       GPIO_AF_USART6
#define DEBUG_USART6_TX_SOURCE                   GPIO_PinSource6

#define DEBUG_USART6_IRQHandler                  USART6_IRQHandler
#define DEBUG_USART6_IRQ                 				USART6_IRQn
/************************************************************/

//���ڳ�ʼ��
void USART_Comfig(void);

void Usart_SendByte( USART_TypeDef * pUSARTx, uint8_t ch);
void Usart_SendString( USART_TypeDef * pUSARTx, char *str);

void Usart_SendHalfWord( USART_TypeDef * pUSARTx, uint16_t ch);


#endif /* __USART_H */

