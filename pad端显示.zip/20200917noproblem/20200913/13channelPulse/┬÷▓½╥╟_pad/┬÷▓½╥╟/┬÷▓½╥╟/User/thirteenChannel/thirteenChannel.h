#ifndef __THIRTEENCHANNEL_H
#define	__THIRTEENCHANNEL_H
#include "stm32f4xx.h"

void dataProcess_13();
void display();

#endif /* THIRTEENCHANNEL */