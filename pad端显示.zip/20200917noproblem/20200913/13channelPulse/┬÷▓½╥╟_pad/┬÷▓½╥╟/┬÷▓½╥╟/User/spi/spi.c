#include "./spi/spi.h"
#include "stm32f4xx.h"

unsigned int LCDXI,LCDYI,VBPV,VFPV,VSWV,HBPH,HFPH,HSWH;

// void delay_ms(int count)  // /* X1ms */
//{
//        int i,j;
//        for(i=0;i<count;i++)
//	
//            	{
//                for(j=0;j<40000;j++);	
//              }
//}


 
void  MIPI_LCDsize (unsigned int size)
{
  if  (size == 51) /////480x800
{
  LCDXI =  480;
  LCDYI =  800;
	
 VBPV		= 22 ;// 23
 VFPV	 =	 2;//18
 VSWV		= 2 ; //6
 HBPH		= 18;//80
 HFPH		= 18;//80
 HSWH	  = 5;//4
}

else if (size==52)//540X960
{

  LCDXI =  540;
  LCDYI =  960;
	
 VBPV		= 16;//11
 VFPV	  =	15;
 VSWV		= 1 ; 
 HBPH		= 32;//32
 HFPH		= 33;//32
 HSWH	  = 4;


}

	else if (size==55)//720x1280
{

//  LCDXI =  720;
//  LCDYI =  1280;
//	
// VBPV		= 23;//11
// VFPV	  =	18;
// VSWV		= 4 ; 
// HBPH		= 35;//32
// HFPH		= 35;//32
// HSWH	  = 4;
//	
	
//  LCDXI =  720;
//  LCDYI =  1280;
//	
// VBPV		= 23;//11
// VFPV	  =	18;
// VSWV		= 4 ; 
// HBPH		= 80;//32
// HFPH		= 80;//32
// HSWH	  = 4;



////INX55
  LCDXI =  720;
  LCDYI =  1280;
	
 VBPV		= 10;//11
 VFPV	  =	15;
 VSWV		= 6 ; 
 HBPH		= 35;//32
 HFPH		= 35;//32
 HSWH	  = 4;
	

}

else if(size==7)//SIZE 7 In this case , The pixel for 30P display is 1024*600.
	{
			
	 /////1024x600
 LCDXI =   1024;
 LCDYI  =  600;

 VBPV	=	 23 ; 
 VFPV	= 	 12;
 VSWV	=	 6 ; 
 HBPH	=	 160;
 HFPH	=	 160;
 HSWH	=  4;	
		
  }		

  else if (size==79)
	{
 /////768x1024
 LCDXI =   768;
 LCDYI  =  1024;

 VBPV	=	 23 ; 
 VFPV	= 	 18;
 VSWV	=	 6 ; 
 HBPH	=	 80;
 HFPH	=	 80;
 HSWH	=  4;
		
	//	////B  OTA 	
//	 HSYNC = 80;
//	 VSYNC = 18;
//   HBP   = 59;
//	 VBP   = 19;
//		
//	 AW = 827;    //848
//	 AH = 1043;  //1047
//		
//	 TW = 928;  //928
//	 TH = 1065;	//1065	
//		
//		 LCDX =	 768;
// 	   LCDY =  1024;	
		
	}

	  else if (size==8) /////800x1280
	{
 ////HX8394C
 LCDXI =   800;
 LCDYI  =  1280;

 VBPV	=	 8 ; 
 VFPV	=  4;
 VSWV	=	 4 ; 
 HBPH	=	 79;
 HFPH	=	 79;
 HSWH	=  36;
	}
	
	 else if (size==101)/////1280x800
	 {
 LCDXI  =  1280;
 LCDYI  =  800;

 VBPV	=	 9 ; 
 VFPV	=	9;
 VSWV	=	 6;  
 HBPH	= 80;
 HFPH	= 80;
 HSWH	 = 4;
	
////ips
// LCDXI  =  1280;
// LCDYI  =  800;

// VBPV	=	 8 ; 
// VFPV	=	4;
// VSWV	=	 4;  
// HBPH	= 21;
// HFPH	= 147;
// HSWH	 = 32;		 
//		 
		 
	 }
	 
}

/////////////////////////////////////
///   ģ�� 3 line SPI  /////////////////
/////////////////////////////////////

void SPI_3W_SET_Cmd(unsigned char cmd)
{
	unsigned int kk;
	
	SPI_3SDI_L;			//Set DC=0, for writing to Command register
	SPI_3CLK_L;
	SPI_3CLK_H;
	

	SPI_3CLK_L;
	for(kk=0;kk<8;kk++)
	{
		if((cmd&0x80)==0x80) SPI_3SDI_H;
		else        SPI_3SDI_L;  
		SPI_3CLK_H;
		SPI_3CLK_L;
		cmd = cmd<<1;	
	}
}


void SPI_3W_SET_PAs(unsigned char value)
{
	unsigned int kk;

	SPI_3SDI_H;			//Set DC=1, for writing to Data register
	SPI_3CLK_L;
	SPI_3CLK_H;
	
	SPI_3CLK_L;
	for(kk=0;kk<8;kk++)
	{
		if((value&0x80)==0x80) SPI_3SDI_H;
		else                   SPI_3SDI_L;
		SPI_3CLK_H;
		SPI_3CLK_L;
		value = value<<1;	
	}	
}

void SPI_2828_WrCmd(unsigned char cmd)
{
	unsigned int kk;
	
	SPI_3CS_L;
	
	SPI_3SDI_L;			//Set DC=0, for writing to Command register
	SPI_3CLK_L;
	SPI_3CLK_H;
	

	SPI_3CLK_L;
	for(kk=0;kk<8;kk++)
	{
		if((cmd&0x80)==0x80) SPI_3SDI_H;
		else         SPI_3SDI_L;        
		SPI_3CLK_H;
		SPI_3CLK_L;
		cmd = cmd<<1;	
	}
	
	SPI_3CS_H;	
}

void SPI_WriteData(unsigned char dat)
{
  
	SPI_3CS_L;
	SPI_3W_SET_PAs(dat);
	SPI_3CS_H;	
}


void SSD2828_REG_DATA_3L(unsigned char c,unsigned int value)
{
	SPI_3CS_L;
	SPI_3W_SET_Cmd(c);
	SPI_3W_SET_PAs(value&0xff);
	SPI_3W_SET_PAs((value>>8)&0xff);	
	SPI_3CS_H;	
}


void GP_COMMAD_PA(unsigned int num)
{      	

  SSD2828_REG_DATA_3L(0xBC,num);
	SPI_2828_WrCmd(0xBF);
    	
}
 
////////////////////////////////////////

void SSD2828_init (void)
{
	
	GPIO_InitTypeDef  GPIO_InitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);//�������ó�SPIģʽ1
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	
//	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
//	GPIO_InitStructure.GPIO_Pin =   GPIO_Pin_11;// CS,SCK,SDI
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
//	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
//	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
//	GPIO_Init(GPIOA, &GPIO_InitStructure);
//#define  SPI_3CS_H   GPIO_SetBits(GPIOA,  GPIO_Pin_4)    
//#define  SPI_3CS_L   GPIO_ResetBits(GPIOA,  GPIO_Pin_4)

//#define  SPI_3CLK_H   GPIO_SetBits(GPIOA,  GPIO_Pin_5) 
//#define  SPI_3CLK_L   GPIO_ResetBits(GPIOA,  GPIO_Pin_5)

//#define  SPI_3SDI_H    GPIO_SetBits(GPIOA,  GPIO_Pin_6) 
//#define  SPI_3SDI_L    GPIO_ResetBits(GPIOA,  GPIO_Pin_6)

//#define  SPI_3SDO_H   GPIO_SetBits(GPIOA,  GPIO_Pin_7) 
//#define  SPI_3SDO_L   GPIO_ResetBits(GPIOA,  GPIO_Pin_7)

//#define  SPI_3RES_H   GPIO_SetBits(GPIOB,  GPIO_Pin_12) 
//#define  SPI_3RES_L   GPIO_ResetBits(GPIOB,  GPIO_Pin_12)
		GPIO_InitStructure.GPIO_Pin =   GPIO_Pin_4 |GPIO_Pin_5| GPIO_Pin_6|GPIO_Pin_7;// CS,SCK,SDI
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
 	  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	 GPIO_InitStructure.GPIO_Pin =      GPIO_Pin_12 ;  //SDO RESET
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
 	  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	//LCD_BACK_H;//LED����ʹ��
//	  MIPI_LCDsize(7);  ///���ֱ��ʴ�Сѡ�� size 7  1024 * 600
  SPI_3CS_H;
	SPI_3RES_H; 
	delay_ms(20);
  SPI_3RES_L; 
  delay_ms(200); // Delay 10ms  
  SPI_3RES_H; 
  delay_ms(120); // Delay 120 ms
	SPI_3CS_L;
 
////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////

	
SPI_2828_WrCmd(0xb7);
SPI_WriteData(0x50);//  LP mode(DCS mode & HS clk disable) 
SPI_WriteData(0x00);    


SPI_2828_WrCmd(0xb8);
SPI_WriteData(0x00);
SPI_WriteData(0x00);   //VC(Virtual ChannelID) Control Register

SPI_2828_WrCmd(0xb9);
SPI_WriteData(0x00);//1=PLL disable
SPI_WriteData(0x00);
delay_ms(10);
//TX_CLK/MS should be between 5Mhz to100Mhz
SPI_2828_WrCmd(0xBA);
SPI_WriteData(0x2f);
SPI_WriteData(0x80);
delay_ms(10);
SPI_2828_WrCmd(0xBB);
SPI_WriteData(0x03);
SPI_WriteData(0x00);
delay_ms(10);
SPI_2828_WrCmd(0xb9);
SPI_WriteData(0x01);//1=PLL disable
SPI_WriteData(0x00);
delay_ms(100);

SPI_2828_WrCmd(0xDE);
SPI_WriteData(0x03);   //01 2LINE  02  3LINE  03 4LINE
SPI_WriteData(0x00);  
delay_ms(10);

SPI_2828_WrCmd(0xc9);
SPI_WriteData(0x02);
SPI_WriteData(0x23);
delay_ms(120);


	/***********��ʼ��Һ����********/
	
	 //init_BOE7_8394C ();//MIPI ����ʼ������ 7�� 800X1280
	// int_OTM9605_50 ();//5.0�� 540X960


		
		 ///////7�� 10.1��MIPI ����ֻ�����´���///
//	///**********************************//
//	SSD2828_REG_DATA_3L(0xBC,1);SPI_2828_WrCmd(0xBF);
//	 SPI_WriteData(0x11);
//	 delay_ms(100);
//	 SSD2828_REG_DATA_3L(0xBC,1);SPI_2828_WrCmd(0xBF);
//	 SPI_WriteData(0x29);
//       delay_ms(10);
// /// ********************************///	
		
		
///****************************//////
//SSD2828_Initial
SPI_2828_WrCmd(0xb7);
SPI_WriteData(0x50);
SPI_WriteData(0x00);  
 
SPI_2828_WrCmd(0xb8);
SPI_WriteData(0x00);
SPI_WriteData(0x00);   

SPI_2828_WrCmd(0xb9);
SPI_WriteData(0x00);
SPI_WriteData(0x00);

SPI_2828_WrCmd(0xBA);
SPI_WriteData(0x2f);
SPI_WriteData(0x80);

SPI_2828_WrCmd(0xBB);
SPI_WriteData(0x07);
SPI_WriteData(0x00);

SPI_2828_WrCmd(0xb9);
SPI_WriteData(0x01);
SPI_WriteData(0x00);

SPI_2828_WrCmd(0xc9);
SPI_WriteData(0x02);
SPI_WriteData(0x23); 
delay_ms(5);

SPI_2828_WrCmd(0xCA);
SPI_WriteData(0x01);
SPI_WriteData(0x23);

SPI_2828_WrCmd(0xCB); 
SPI_WriteData(0x10);
SPI_WriteData(0x05);

SPI_2828_WrCmd(0xCC); 
SPI_WriteData(0x05);
SPI_WriteData(0x10);
delay_ms(5);

SPI_2828_WrCmd(0xD0); 
SPI_WriteData(0x00);
SPI_WriteData(0x00);
delay_ms(5);


///LoadLcdParameterConfig(); 
	///////////////RGB interface configuration /////////////////////
	SPI_2828_WrCmd(0xb1); //Vertical sync and horizontal sync active period 
  SPI_WriteData(HSWH); 
  SPI_WriteData(VSWV); 

		SPI_2828_WrCmd(0xb2); //Vertical and horizontal back porch period 
  SPI_WriteData(HBPH); 
  SPI_WriteData(VBPV); 

	SPI_2828_WrCmd(0xb3); //Vertical and horizontal front porch period 
  SPI_WriteData(VFPV); 
  SPI_WriteData(HFPH); 
	
	SPI_2828_WrCmd(0xb4); //Horizontal active period 
  SPI_WriteData(LCDXI&0xff); 
  SPI_WriteData((LCDXI>>8)&0xff); 
	SPI_2828_WrCmd(0xb5); //Vertical active period
  SPI_WriteData(LCDYI&0xff); 
  SPI_WriteData((LCDYI>>8)&0xff); 
	SPI_2828_WrCmd(0xb6); //Video mode and video pixel format  1b=LP 0b=HS
  SPI_WriteData(0x07); 
  SPI_WriteData(0xe1);	
////////////////////////////////////////////////////////////////



SPI_2828_WrCmd(0xDE);
SPI_WriteData(0x03);  //01 2LINE  02  3LINE  03 4LINE
SPI_WriteData(0x00);

SPI_2828_WrCmd(0xD6);
SPI_WriteData(0x04);
SPI_WriteData(0x00);//SET BGR

SPI_2828_WrCmd(0xB7);
SPI_WriteData(0x4B);
SPI_WriteData(0x02);delay_ms(100);

SPI_2828_WrCmd(0x2C);


}


void int_OTM9605_50 (void)
{

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
	GP_COMMAD_PA(4);
SPI_WriteData(0xFF);
SPI_WriteData(0x96);
SPI_WriteData(0x05);
SPI_WriteData(0x01);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x80);
	GP_COMMAD_PA(3);
SPI_WriteData(0xFF);
SPI_WriteData(0x96);
SPI_WriteData(0x05);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
	GP_COMMAD_PA(2);
SPI_WriteData(0xA0);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xC5);
	GP_COMMAD_PA(2);
SPI_WriteData(0xB0);
SPI_WriteData(0x03);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x83);
	GP_COMMAD_PA(2);
SPI_WriteData(0xB2);
SPI_WriteData(0x80);

	///////////////////HG-qin///////////  
						GP_COMMAD_PA(2);
						SPI_WriteData(0x00);
						SPI_WriteData(0x90);
						GP_COMMAD_PA(2);
						SPI_WriteData(0xB3);
						SPI_WriteData(0x00);//540X960
						
						GP_COMMAD_PA(2);
						SPI_WriteData(0x00);
						SPI_WriteData(0x91);
						GP_COMMAD_PA(2);
						SPI_WriteData(0xB3);
						SPI_WriteData(0x20);//00RGB  20BGR
								
					 GP_COMMAD_PA(2);
						SPI_WriteData(0x00);
						SPI_WriteData(0xa6);
						GP_COMMAD_PA(2);
						SPI_WriteData(0xB3);
						SPI_WriteData(0x07);//RGB2BGR
						
						
						GP_COMMAD_PA(2);
						SPI_WriteData(0x00);
						SPI_WriteData(0xa6);
						GP_COMMAD_PA(2);
						SPI_WriteData(0xB7);
						SPI_WriteData(0x01);//ENABLE D3A6
	///////////////////////////////////////////					
						
	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x89);
	GP_COMMAD_PA(2);
SPI_WriteData(0xC0);
SPI_WriteData(0x01);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xB4);
	GP_COMMAD_PA(2);
SPI_WriteData(0xC0);/////Panel Driving Mode  INV
SPI_WriteData(0x50);  //00 1dot, 50 column

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x80);
	GP_COMMAD_PA(3);
SPI_WriteData(0xC1);
SPI_WriteData(0x36);
SPI_WriteData(0x66);

           /////////OSC    HG-QIN
								GP_COMMAD_PA(2);
							SPI_WriteData(0x00);
							SPI_WriteData(0x81);
								GP_COMMAD_PA(2);
							SPI_WriteData(0xC1);
							SPI_WriteData(0x54);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xA0);
	GP_COMMAD_PA(2);
SPI_WriteData(0xC1);
SPI_WriteData(0x00);

//////Source Driver Precharge Control
	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x80);
	GP_COMMAD_PA(2);
SPI_WriteData(0xC4);
SPI_WriteData(0x9c);//9c

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x80);
	GP_COMMAD_PA(5);
SPI_WriteData(0xC5);
SPI_WriteData(0x08);
SPI_WriteData(0x00);
SPI_WriteData(0xA0);
SPI_WriteData(0x11);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x90);
	GP_COMMAD_PA(8);
SPI_WriteData(0xC5);
SPI_WriteData(0x96);
SPI_WriteData(0x76);//VGH,VGL
SPI_WriteData(0x01);
SPI_WriteData(0x76);
SPI_WriteData(0x33);
SPI_WriteData(0x33);
SPI_WriteData(0x34);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xB0);
	GP_COMMAD_PA(3);
SPI_WriteData(0xC5);//DC Voltage
SPI_WriteData(0x04);
SPI_WriteData(0x28);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xC0);
	GP_COMMAD_PA(2);
SPI_WriteData(0xC5);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
	GP_COMMAD_PA(2);
SPI_WriteData(0xD0);
SPI_WriteData(0x40);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
	GP_COMMAD_PA(3);
SPI_WriteData(0xD1);
SPI_WriteData(0x00);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xB2);
	GP_COMMAD_PA(5);
SPI_WriteData(0xF5);
SPI_WriteData(0x15);
SPI_WriteData(0x00);
SPI_WriteData(0x15);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x80);
	GP_COMMAD_PA(11);
SPI_WriteData(0xCB);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x90);
	GP_COMMAD_PA(16);
SPI_WriteData(0xCB);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xA0);
	GP_COMMAD_PA(16);
SPI_WriteData(0xCB);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xB0);
	GP_COMMAD_PA(11);
SPI_WriteData(0xCB);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xC0);
	GP_COMMAD_PA(16);
SPI_WriteData(0xCB);
SPI_WriteData(0x04);
SPI_WriteData(0x04);
SPI_WriteData(0x04);
SPI_WriteData(0x04);
SPI_WriteData(0x00);
SPI_WriteData(0x04);
SPI_WriteData(0x00);
SPI_WriteData(0x04);
SPI_WriteData(0x00);
SPI_WriteData(0x04);
SPI_WriteData(0x00);
SPI_WriteData(0x04);
SPI_WriteData(0x04);
SPI_WriteData(0x04);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xD0);
	GP_COMMAD_PA(16);
SPI_WriteData(0xCB);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x04);
SPI_WriteData(0x04);
SPI_WriteData(0x04);
SPI_WriteData(0x04);
SPI_WriteData(0x00);
SPI_WriteData(0x04);
SPI_WriteData(0x00);
SPI_WriteData(0x04);
SPI_WriteData(0x00);
SPI_WriteData(0x04);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xE0);
	GP_COMMAD_PA(11);
SPI_WriteData(0xCB);
SPI_WriteData(0x00);
SPI_WriteData(0x04);
SPI_WriteData(0x04);
SPI_WriteData(0x04);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xF0);
	GP_COMMAD_PA(11);
SPI_WriteData(0xCB);
SPI_WriteData(0x00);
SPI_WriteData(0xCC);
SPI_WriteData(0xCC);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0xCC);
SPI_WriteData(0xCC);
SPI_WriteData(0x0F);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x80);
	GP_COMMAD_PA(11);
SPI_WriteData(0xCC);
SPI_WriteData(0x26);
SPI_WriteData(0x25);
SPI_WriteData(0x21);
SPI_WriteData(0x22);
SPI_WriteData(0x00);
SPI_WriteData(0x0C);
SPI_WriteData(0x00);
SPI_WriteData(0x0A);
SPI_WriteData(0x00);
SPI_WriteData(0x10);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x90);
	GP_COMMAD_PA(16);
SPI_WriteData(0xCC);
SPI_WriteData(0x00);
SPI_WriteData(0x0E);
SPI_WriteData(0x02);
SPI_WriteData(0x04);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x26);
SPI_WriteData(0x25);
SPI_WriteData(0x21);
SPI_WriteData(0x22);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xA0);
	GP_COMMAD_PA(16);
SPI_WriteData(0xCC);
SPI_WriteData(0x0B);
SPI_WriteData(0x00);
SPI_WriteData(0x09);
SPI_WriteData(0x00);
SPI_WriteData(0x0F);
SPI_WriteData(0x00);
SPI_WriteData(0x0D);
SPI_WriteData(0x01);
SPI_WriteData(0x03);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xB0);
	GP_COMMAD_PA(11);
SPI_WriteData(0xCC);
SPI_WriteData(0x25);
SPI_WriteData(0x26);
SPI_WriteData(0x21);
SPI_WriteData(0x22);
SPI_WriteData(0x00);
SPI_WriteData(0x0D);
SPI_WriteData(0x00);
SPI_WriteData(0x0F);
SPI_WriteData(0x00);
SPI_WriteData(0x09);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xC0);
	GP_COMMAD_PA(16);
SPI_WriteData(0xCC);
SPI_WriteData(0x00);
SPI_WriteData(0x0B);
SPI_WriteData(0x03);
SPI_WriteData(0x01);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x25);
SPI_WriteData(0x26);
SPI_WriteData(0x21);
SPI_WriteData(0x22);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xD0);
	GP_COMMAD_PA(16);
SPI_WriteData(0xCC);
SPI_WriteData(0x0E);
SPI_WriteData(0x00);
SPI_WriteData(0x10);
SPI_WriteData(0x00);
SPI_WriteData(0x0A);
SPI_WriteData(0x00);
SPI_WriteData(0x0C);
SPI_WriteData(0x04);
SPI_WriteData(0x02);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x80);
	GP_COMMAD_PA(13);
SPI_WriteData(0xCE);
SPI_WriteData(0x8B);
SPI_WriteData(0x03);
SPI_WriteData(0x28);
SPI_WriteData(0x8A);
SPI_WriteData(0x03);
SPI_WriteData(0x28);
SPI_WriteData(0x89);
SPI_WriteData(0x03);
SPI_WriteData(0x28);
SPI_WriteData(0x88);
SPI_WriteData(0x03);
SPI_WriteData(0x28);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x90);
	GP_COMMAD_PA(15);
SPI_WriteData(0xCE);
SPI_WriteData(0xF0);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0xF0);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0xF0);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0xF0);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xA0);
	GP_COMMAD_PA(15);
SPI_WriteData(0xCE);
SPI_WriteData(0x38);
SPI_WriteData(0x07);
SPI_WriteData(0x03);
SPI_WriteData(0xC0);
SPI_WriteData(0x00);
SPI_WriteData(0x18);
SPI_WriteData(0x00);
SPI_WriteData(0x38);
SPI_WriteData(0x06);
SPI_WriteData(0x03);
SPI_WriteData(0xC1);
SPI_WriteData(0x00);
SPI_WriteData(0x18);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xB0);
	GP_COMMAD_PA(15);
SPI_WriteData(0xCE);
SPI_WriteData(0x38);
SPI_WriteData(0x05);
SPI_WriteData(0x03);
SPI_WriteData(0xC2);
SPI_WriteData(0x00);
SPI_WriteData(0x18);
SPI_WriteData(0x00);
SPI_WriteData(0x38);
SPI_WriteData(0x04);
SPI_WriteData(0x03);
SPI_WriteData(0xC3);
SPI_WriteData(0x00);
SPI_WriteData(0x18);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xC0);
	GP_COMMAD_PA(15);
SPI_WriteData(0xCE);
SPI_WriteData(0x38);
SPI_WriteData(0x03);
SPI_WriteData(0x03);
SPI_WriteData(0xC4);
SPI_WriteData(0x00);
SPI_WriteData(0x18);
SPI_WriteData(0x00);
SPI_WriteData(0x38);
SPI_WriteData(0x02);
SPI_WriteData(0x03);
SPI_WriteData(0xC5);
SPI_WriteData(0x00);
SPI_WriteData(0x18);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xD0);
	GP_COMMAD_PA(15);
SPI_WriteData(0xCE);
SPI_WriteData(0x38);
SPI_WriteData(0x01);
SPI_WriteData(0x03);
SPI_WriteData(0xC6);
SPI_WriteData(0x00);
SPI_WriteData(0x18);
SPI_WriteData(0x00);
SPI_WriteData(0x38);
SPI_WriteData(0x00);
SPI_WriteData(0x03);
SPI_WriteData(0xC7);
SPI_WriteData(0x00);
SPI_WriteData(0x18);
SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xC0);
	GP_COMMAD_PA(2);
SPI_WriteData(0xCF);
SPI_WriteData(0x02);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xC7);
	GP_COMMAD_PA(2);
SPI_WriteData(0xCF);
SPI_WriteData(0x80);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0xC9);
	GP_COMMAD_PA(2);
SPI_WriteData(0xCF);
SPI_WriteData(0x08);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
	GP_COMMAD_PA(3);
SPI_WriteData(0xD8);//GVDD GNVDD
SPI_WriteData(0x97);//6f
SPI_WriteData(0x97);//6f

    ////////////         //////
					 GP_COMMAD_PA(2);
					 SPI_WriteData(0x00);
					 SPI_WriteData(0x80);
					 GP_COMMAD_PA(2);
					 SPI_WriteData(0xD6);// COLOR Enhancemant
					 SPI_WriteData(0x68);// 	 
			 
	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
	GP_COMMAD_PA(2);
SPI_WriteData(0xD9);//////VCOM
SPI_WriteData(0x3b);


	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
	GP_COMMAD_PA(17);
SPI_WriteData(0xE1);
SPI_WriteData(0x01);
SPI_WriteData(0x08);
SPI_WriteData(0x0D);
SPI_WriteData(0x0D);
SPI_WriteData(0x06);
SPI_WriteData(0x0C);
SPI_WriteData(0x0A);
SPI_WriteData(0x09);
SPI_WriteData(0x05);
SPI_WriteData(0x08);
SPI_WriteData(0x10);
SPI_WriteData(0x08);
SPI_WriteData(0x0F);
SPI_WriteData(0x10);
SPI_WriteData(0x09);
SPI_WriteData(0x04);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
	GP_COMMAD_PA(17);
SPI_WriteData(0xE2);
SPI_WriteData(0x01);
SPI_WriteData(0x08);
SPI_WriteData(0x0D);
SPI_WriteData(0x0D);
SPI_WriteData(0x06);
SPI_WriteData(0x0C);
SPI_WriteData(0x0A);
SPI_WriteData(0x09);
SPI_WriteData(0x05);
SPI_WriteData(0x08);
SPI_WriteData(0x10);
SPI_WriteData(0x08);
SPI_WriteData(0x0F);
SPI_WriteData(0x10);
SPI_WriteData(0x09);
SPI_WriteData(0x04);

	GP_COMMAD_PA(2);
SPI_WriteData(0x00);
SPI_WriteData(0x00);
	GP_COMMAD_PA(4);
SPI_WriteData(0xFF);
SPI_WriteData(0xFF);
SPI_WriteData(0xFF);
SPI_WriteData(0xFF);


	GP_COMMAD_PA(1);
	SPI_WriteData(0x11);
	delay_ms(120);
	GP_COMMAD_PA(1);
	SPI_WriteData(0x29);
	delay_ms(10);

}

