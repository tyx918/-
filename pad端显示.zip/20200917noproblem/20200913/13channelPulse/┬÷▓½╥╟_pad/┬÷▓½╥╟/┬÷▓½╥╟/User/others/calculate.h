#ifndef __CALCULATE_H
#define __CALCULATE_H
extern struct object_info u_begin;
extern struct object_info u_stop;
extern struct object_info u_reset;
extern struct object_info u_upload;
extern struct object_info u_heart;
extern struct object_info u_rec;
extern struct object_info u_channel4;
extern struct object_info u_emit;
extern int draw;
void para_space(int order_channel,int s,int poi);
void show_rank(int num,int posi);
void compare(double power_1,double power_2,double power_3,double power_4,double power_5,double power_6,double power_7,double power_8);
double sigProcess_13(int* channel_13_ca,int size);
#endif