#include "./spi/ssi.h"
#include "./systick/bsp_SysTick.h"
/*******************************************************************************
* Function Name  : SPI_Init
* Description    : Initializes the peripherals used by the SPI Peripheral driver.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SPI1_Init(void)
{
  SPI_InitTypeDef  SPI_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;
	
  
  /* Enable SPIx and GPIO clocks */
  /*!< SPI_SPI_CS_GPIO, SPI_SPI_MOSI_GPIO, SPI_SPI_MISO_GPIO, and SPI_SPI_SCK_GPIO Periph clock enable */
  /*!< SPI_SPI Periph clock enable */
	RCC_APB2PeriphClockCmd ( macSPI_CLK , ENABLE );
	
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO | RCC_APB2Periph_SPI1, ENABLE);
	/*!< Configure SPI_SPI_CS_PIN pin: CS */
	macSPI_CS_APBxClock_FUN ( macSPI_CS_CLK, ENABLE );
  GPIO_InitStructure.GPIO_Pin = macSPI_CS_PIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_Init(macSPI_CS_PORT, &GPIO_InitStructure);
	
  /*!< Configure SPI_SPI pins: SCK */
	macSPI_SCK_APBxClock_FUN ( macSPI_SCK_CLK, ENABLE );
  GPIO_InitStructure.GPIO_Pin = macSPI_SCK_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_Init(macSPI_SCK_PORT, &GPIO_InitStructure);

  /*!< Configure SPI_SPI pins: MISO */
	macSPI_MISO_APBxClock_FUN ( macSPI_MISO_CLK, ENABLE );
  GPIO_InitStructure.GPIO_Pin = macSPI_MISO_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;	//GPIO_Mode_AF_PP GPIO_Mode_IN_FLOATING
  GPIO_Init(macSPI_MISO_PORT, &GPIO_InitStructure);

  /*!< Configure SPI_SPI pins: MOSI */
	macSPI_MOSI_APBxClock_FUN ( macSPI_MOSI_CLK, ENABLE );
  GPIO_InitStructure.GPIO_Pin = macSPI_MOSI_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;	//GPIO_Mode_AF_PP Send CMD; GPIO_Mode_AF_OD Send DUMMY_BYTE
  GPIO_Init(macSPI_MOSI_PORT, &GPIO_InitStructure);

  /*!< Configure SPI_SPI pins: RES */
	macSPI_RES_APBxClock_FUN ( macSPI_RES_CLK, ENABLE );
  GPIO_InitStructure.GPIO_Pin = macSPI_RES_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;	//GPIO_Mode_AF_PP Send CMD; GPIO_Mode_AF_OD Send DUMMY_BYTE
  GPIO_Init(macSPI_RES_PORT, &GPIO_InitStructure);
  /* Deselect the SPI Slave device: Chip Select high */
	
	  /*!< Configure SPI_SPI pins:SDC */
	macSPI_SDC_APBxClock_FUN ( macSPI_SDC_CLK, ENABLE );
  GPIO_InitStructure.GPIO_Pin = macSPI_SDC_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;	//GPIO_Mode_AF_PP Send CMD; GPIO_Mode_AF_OD Send DUMMY_BYTE
  GPIO_Init(macSPI_SDC_PORT, &GPIO_InitStructure);
	
  macSPIx_CS_DISABLE();

  /* SPIx configuration */
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;	//����˫��ȫ˫��
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;		//MSTR = 1, SSI = 1
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;	//SPI_CPHA_1Edge ������
  SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;				//SSM = 1����������ģʽ
  SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_16;  //16��Ƶ��SPI1 9M,SPI2 4.5M
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
  SPI_InitStructure.SPI_CRCPolynomial = 0;
  SPI_Init(macSPIx, &SPI_InitStructure);

  /* Disable SPIx CRC calculation */
  SPI_CalculateCRC(macSPIx, DISABLE);
//	SPI1->CR2 |=((1<<6)|(1<<7));
  /* Enable macSPIx */
  SPI_Cmd(macSPIx, ENABLE);

//  /* Enable DMA1 clock */
//  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE); 	// DMA1�˴�ֻ��ʱ�ӣ�ʹ��ʱ�ٳ�ʼ��

//  /* Enable macSPIx DMA Tx request */
//  SPI_I2S_DMACmd(macSPIx, SPI_I2S_DMAReq_Tx, ENABLE);

//  /* Enable macSPIx DMA Rx request */
//  SPI_I2S_DMACmd(macSPIx, SPI_I2S_DMAReq_Rx, ENABLE);		
}

/*******************************************************************************
* Function Name  : SPIx_RdWrByte
* Description    : Sends a byte through the SPI interface and return the byte
*                  received from the SPI bus.
* Input          : SPIx, byte : byte to send.
* Output         : None
* Return         : The value of the received byte.
*******************************************************************************/
uint16_t  SPIx_RdWr_Byte(SPI_TypeDef* SPIx, uint8_t byte)
{
  uint16_t u16Temp = 0;
	
//	printf("\r\n @Sky [SPIx_RdWr_Byte] write��0x%x \r\n", byte);
  /* Loop while DR register in not emplty */
  while (SPI_I2S_GetFlagStatus(SPIx, SPI_I2S_FLAG_TXE) == RESET);
  
  if (SPI_I2S_GetFlagStatus(SPIx, SPI_I2S_FLAG_RXNE) == SET)
  {
    SPI_I2S_ReceiveData(SPIx);                                            // ���SPI_DR ���գ������
  }

  /* Send byte through the SPIx peripheral */
  SPI_I2S_SendData(SPIx, byte);

	
  /* Wait to receive a byte */
  while (SPI_I2S_GetFlagStatus(SPIx, SPI_I2S_FLAG_RXNE) == RESET);
 
  u16Temp = SPI_I2S_ReceiveData(SPIx);

  /* Wait to RXNE ���� */
  while (SPI_I2S_GetFlagStatus(SPIx, SPI_I2S_FLAG_RXNE) == SET);
 
	
	
//	printf("\r\n @Sky [SPIx_RdWr_Byte] read��0x%x \r\n", (uint8_t)u16Temp);
  /* Return the byte read from the SPI bus */
  return (uint16_t)(u16Temp);
}

void SPI_Set_byte(u8 byte)
{

				

}
void SSD2828_Write_Data(SPI_TypeDef* SPIx,u8 dat)
{
//		macSPIx_CS_DISABLE();
		
		macSPIx_CS_ENABLE();
	//	delay_us(1);
		macSPIx_SDC_DATA_ENABLE();
	//	delay_us(1);
		SPIx_RdWr_Byte(SPIx,dat);
	//	delay_us(1);
		macSPIx_CS_DISABLE();
}
void SSD2828_Write_Command(SPI_TypeDef* SPIx,u8 dat)
{
//		macSPIx_CS_DISABLE();

		macSPIx_CS_ENABLE();
	  macSPIx_SDC_COMMAND_ENABLE();
		SPIx_RdWr_Byte(SPIx,dat);
		macSPIx_CS_DISABLE();
		
}
void SSD2828_Write_Data1(u16 dat)
{
//		macSPIx_CS_DISABLE();
		
		macSPIx_CS_ENABLE();
	//	delay_us(1);
		macSPIx_SDC_DATA_ENABLE();
	//	delay_us(1);
		SPIx_RdWr_Byte(SPI1,dat);
	//	delay_us(1);
		macSPIx_CS_DISABLE();
}
void SSD2828_Write_Reg(u8 com,u16 dat)
{
			
		macSPIx_CS_ENABLE();
		macSPIx_SDC_COMMAND_ENABLE();
		SPIx_RdWr_Byte(SPI1,com);
	  macSPIx_SDC_DATA_ENABLE(); 
		SPIx_RdWr_Byte(SPI1,(dat&0xff));
		SPIx_RdWr_Byte(SPI1,((dat>>8)&0xff));
		macSPIx_CS_DISABLE();
		
}

void GP_COMMAD_PA1(u16 num)
{

	SSD2828_Write_Reg(0xbc,num);
	SSD2828_Write_Command(SPI1,0XBF);

}
void LCD_CODE_Init(void)
{
	GP_COMMAD_PA1(5);SSD2828_Write_Data1(0xFF);SSD2828_Write_Data1(0xAA);SSD2828_Write_Data1(0x55);SSD2828_Write_Data1(0xA5);SSD2828_Write_Data1(0x80);
	GP_COMMAD_PA1(3);SSD2828_Write_Data1(0x6F);SSD2828_Write_Data1(0x11);SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(3);SSD2828_Write_Data1(0xF7);SSD2828_Write_Data1(0x20);SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(2);SSD2828_Write_Data1(0x6F);SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(2);SSD2828_Write_Data1(0xF7);SSD2828_Write_Data1(0xA0);
	GP_COMMAD_PA1(2);SSD2828_Write_Data1(0x6F);SSD2828_Write_Data1(0x19);
	GP_COMMAD_PA1(2);SSD2828_Write_Data1(0xF7);SSD2828_Write_Data1(0x12);
	GP_COMMAD_PA1(2);SSD2828_Write_Data1(0xF4);SSD2828_Write_Data1(0x03);
	GP_COMMAD_PA1(2);SSD2828_Write_Data1(0x6F);SSD2828_Write_Data1(0x08);
	GP_COMMAD_PA1(2);SSD2828_Write_Data1(0xFA);SSD2828_Write_Data1(0x40);
	GP_COMMAD_PA1(2);SSD2828_Write_Data1(0x6F);SSD2828_Write_Data1(0x11);
	GP_COMMAD_PA1(2);SSD2828_Write_Data1(0xF3);SSD2828_Write_Data1(0x01);
	GP_COMMAD_PA1(2);SSD2828_Write_Data1(0x6F);SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(2);SSD2828_Write_Data1(0xFC);SSD2828_Write_Data1(0x03);

	GP_COMMAD_PA1(6);
	SSD2828_Write_Data1(0xF0);
	SSD2828_Write_Data1(0x55);
	SSD2828_Write_Data1(0xAA);
	SSD2828_Write_Data1(0x52);
	SSD2828_Write_Data1(0x08);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB1);
	SSD2828_Write_Data1(0x68);
	SSD2828_Write_Data1(0x01);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xB6);
	SSD2828_Write_Data1(0x08);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0x6F);
	SSD2828_Write_Data1(0x02);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xB8);
	SSD2828_Write_Data1(0x08);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xBB);
	SSD2828_Write_Data1(0x54);
	SSD2828_Write_Data1(0x44);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xBC);
	SSD2828_Write_Data1(0x05);
	SSD2828_Write_Data1(0x05);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xC7);
	SSD2828_Write_Data1(0x01);
	GP_COMMAD_PA1(6);
	SSD2828_Write_Data1(0xBD);
	SSD2828_Write_Data1(0x02);
	SSD2828_Write_Data1(0xB0);
	SSD2828_Write_Data1(0x1E);
	SSD2828_Write_Data1(0x1E);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xC5);
	SSD2828_Write_Data1(0x01);
	SSD2828_Write_Data1(0x07);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xC8);
	SSD2828_Write_Data1(0x83);
	GP_COMMAD_PA1(6);
	SSD2828_Write_Data1(0xF0);
	SSD2828_Write_Data1(0x55);
	SSD2828_Write_Data1(0xAA);
	SSD2828_Write_Data1(0x52);
	SSD2828_Write_Data1(0x08);
	SSD2828_Write_Data1(0x01);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB0);
	SSD2828_Write_Data1(0x05);
	SSD2828_Write_Data1(0x05);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB1);
	SSD2828_Write_Data1(0x05);
	SSD2828_Write_Data1(0x05);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xBC);
	SSD2828_Write_Data1(0x80);
	SSD2828_Write_Data1(0x01);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xBD);
	SSD2828_Write_Data1(0x80);
	SSD2828_Write_Data1(0x01);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xCA);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xC0);
	SSD2828_Write_Data1(0x04);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB3);
	SSD2828_Write_Data1(0x28);
	SSD2828_Write_Data1(0x28);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB4);
	SSD2828_Write_Data1(0x12);
	SSD2828_Write_Data1(0x12);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB9);
	SSD2828_Write_Data1(0x45);
	SSD2828_Write_Data1(0x45);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xBA);
	SSD2828_Write_Data1(0x24);
	SSD2828_Write_Data1(0x24);
	GP_COMMAD_PA1(6);
	SSD2828_Write_Data1(0xF0);
	SSD2828_Write_Data1(0x55);
	SSD2828_Write_Data1(0xAA);
	SSD2828_Write_Data1(0x52);
	SSD2828_Write_Data1(0x08);
	SSD2828_Write_Data1(0x02);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xEE);
	SSD2828_Write_Data1(0x01);
	GP_COMMAD_PA1(5);
	SSD2828_Write_Data1(0xEF);
	SSD2828_Write_Data1(0x09);
	SSD2828_Write_Data1(0x06);
	SSD2828_Write_Data1(0x15);
	SSD2828_Write_Data1(0x18);
	GP_COMMAD_PA1(7);
	SSD2828_Write_Data1(0xB0);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x11);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x2B);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0x6F);
	SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(7);
	SSD2828_Write_Data1(0xB0);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x40);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x50);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x6E);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0x6F);
	SSD2828_Write_Data1(0x0C);
	GP_COMMAD_PA1(5);
	SSD2828_Write_Data1(0xB0);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x8E);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0xC5);
	GP_COMMAD_PA1(7);
	SSD2828_Write_Data1(0xB1);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0xF1);
	SSD2828_Write_Data1(0x01);
	SSD2828_Write_Data1(0x3B);
	SSD2828_Write_Data1(0x01);
	SSD2828_Write_Data1(0x73);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0x6F);
	SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(7);
	SSD2828_Write_Data1(0xB1);
	SSD2828_Write_Data1(0x01);
	SSD2828_Write_Data1(0xCD);
	SSD2828_Write_Data1(0x02);
	SSD2828_Write_Data1(0x15);
	SSD2828_Write_Data1(0x02);
	SSD2828_Write_Data1(0x18);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0x6F);
	SSD2828_Write_Data1(0x0C);
	GP_COMMAD_PA1(5);
	SSD2828_Write_Data1(0xB1);
	SSD2828_Write_Data1(0x02);
	SSD2828_Write_Data1(0x60);
	SSD2828_Write_Data1(0x02);
	SSD2828_Write_Data1(0xBD);
	GP_COMMAD_PA1(7);
	SSD2828_Write_Data1(0xB2);
	SSD2828_Write_Data1(0x02);
	SSD2828_Write_Data1(0xF2);
	SSD2828_Write_Data1(0x03);
	SSD2828_Write_Data1(0x32);
	SSD2828_Write_Data1(0x03);
	SSD2828_Write_Data1(0x59);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0x6F);
	SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(7);
	SSD2828_Write_Data1(0xB2);
	SSD2828_Write_Data1(0x03);
	SSD2828_Write_Data1(0x88);
	SSD2828_Write_Data1(0x03);
	SSD2828_Write_Data1(0x99);
	SSD2828_Write_Data1(0x03);
	SSD2828_Write_Data1(0xAC);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0x6F);
	SSD2828_Write_Data1(0x0C);
	GP_COMMAD_PA1(5);
	SSD2828_Write_Data1(0xB2);
	SSD2828_Write_Data1(0x03);
	SSD2828_Write_Data1(0xBD);
	SSD2828_Write_Data1(0x03);
	SSD2828_Write_Data1(0xE4);
	GP_COMMAD_PA1(5);
	SSD2828_Write_Data1(0xB3);
	SSD2828_Write_Data1(0x03);
	SSD2828_Write_Data1(0xF7);
	SSD2828_Write_Data1(0x03);
	SSD2828_Write_Data1(0xFF);
	GP_COMMAD_PA1(6);
	SSD2828_Write_Data1(0xF0);
	SSD2828_Write_Data1(0x55);
	SSD2828_Write_Data1(0xAA);
	SSD2828_Write_Data1(0x52);
	SSD2828_Write_Data1(0x08);
	SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB0);
	SSD2828_Write_Data1(0x0B);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB1);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB2);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x09);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB3);
	SSD2828_Write_Data1(0x2A);
	SSD2828_Write_Data1(0x29);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB4);
	SSD2828_Write_Data1(0x1B);
	SSD2828_Write_Data1(0x19);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB5);
	SSD2828_Write_Data1(0x17);
	SSD2828_Write_Data1(0x15);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB6);
	SSD2828_Write_Data1(0x13);
	SSD2828_Write_Data1(0x11);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB7);
	SSD2828_Write_Data1(0x01);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB8);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB9);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xBA);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xBB);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xBC);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xBD);
	SSD2828_Write_Data1(0x10);
	SSD2828_Write_Data1(0x12);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xBE);
	SSD2828_Write_Data1(0x14);
	SSD2828_Write_Data1(0x16);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xBF);
	SSD2828_Write_Data1(0x18);
	SSD2828_Write_Data1(0x1A);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xC0);
	SSD2828_Write_Data1(0x29);
	SSD2828_Write_Data1(0x2A);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xC1);
	SSD2828_Write_Data1(0x08);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xC2);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xC3);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x0A);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xE5);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xC4);
	SSD2828_Write_Data1(0x0A);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xC5);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xC6);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xC7);
	SSD2828_Write_Data1(0x2A);
	SSD2828_Write_Data1(0x29);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xC8);
	SSD2828_Write_Data1(0x10);
	SSD2828_Write_Data1(0x12);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xC9);
	SSD2828_Write_Data1(0x14);
	SSD2828_Write_Data1(0x16);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xCA);
	SSD2828_Write_Data1(0x18);
	SSD2828_Write_Data1(0x1A);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xCB);
	SSD2828_Write_Data1(0x08);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xCC);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xCD);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xCE);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xCF);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xD0);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x09);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xD1);
	SSD2828_Write_Data1(0x1B);
	SSD2828_Write_Data1(0x19);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xD2);
	SSD2828_Write_Data1(0x17);
	SSD2828_Write_Data1(0x15);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xD3);
	SSD2828_Write_Data1(0x13);
	SSD2828_Write_Data1(0x11);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xD4);
	SSD2828_Write_Data1(0x29);
	SSD2828_Write_Data1(0x2A);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xD5);
	SSD2828_Write_Data1(0x01);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xD6);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xD7);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x0B);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xE6);
	SSD2828_Write_Data1(0x2E);
	SSD2828_Write_Data1(0x2E);
	GP_COMMAD_PA1(6);
	SSD2828_Write_Data1(0xD8);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(6);
	SSD2828_Write_Data1(0xD9);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xE7);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(6);
	SSD2828_Write_Data1(0xF0);
	SSD2828_Write_Data1(0x55);
	SSD2828_Write_Data1(0xAA);
	SSD2828_Write_Data1(0x52);
	SSD2828_Write_Data1(0x08);
	SSD2828_Write_Data1(0x03);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB0);
	SSD2828_Write_Data1(0x20);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB1);
	SSD2828_Write_Data1(0x20);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(6);
	SSD2828_Write_Data1(0xB2);
	SSD2828_Write_Data1(0x05);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(6);
	SSD2828_Write_Data1(0xB6);
	SSD2828_Write_Data1(0x05);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(6);
	SSD2828_Write_Data1(0xB7);
	SSD2828_Write_Data1(0x05);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(6);
	SSD2828_Write_Data1(0xBA);
	SSD2828_Write_Data1(0x57);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(6);
	SSD2828_Write_Data1(0xBB);
	SSD2828_Write_Data1(0x57);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(5);
	SSD2828_Write_Data1(0xC0);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(5);
	SSD2828_Write_Data1(0xC1);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xC4);
	SSD2828_Write_Data1(0x60);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xC5);
	SSD2828_Write_Data1(0x40);
	GP_COMMAD_PA1(6);
	SSD2828_Write_Data1(0xF0);
	SSD2828_Write_Data1(0x55);
	SSD2828_Write_Data1(0xAA);
	SSD2828_Write_Data1(0x52);
	SSD2828_Write_Data1(0x08);
	SSD2828_Write_Data1(0x05);
	GP_COMMAD_PA1(6);
	SSD2828_Write_Data1(0xBD);
	SSD2828_Write_Data1(0x03);
	SSD2828_Write_Data1(0x01);
	SSD2828_Write_Data1(0x03);
	SSD2828_Write_Data1(0x03);
	SSD2828_Write_Data1(0x03);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB0);
	SSD2828_Write_Data1(0x17);
	SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB1);
	SSD2828_Write_Data1(0x17);
	SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB2);
	SSD2828_Write_Data1(0x17);
	SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB3);
	SSD2828_Write_Data1(0x17);
	SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB4);
	SSD2828_Write_Data1(0x17);
	SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xB5);
	SSD2828_Write_Data1(0x17);
	SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xB8);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xB9);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xBA);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xBB);
	SSD2828_Write_Data1(0x02);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xBC);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xC0);
	SSD2828_Write_Data1(0x07);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xC4);
	SSD2828_Write_Data1(0x80);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xC5);
	SSD2828_Write_Data1(0xA4);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xC8);
	SSD2828_Write_Data1(0x05);
	SSD2828_Write_Data1(0x30);
	GP_COMMAD_PA1(3);
	SSD2828_Write_Data1(0xC9);
	SSD2828_Write_Data1(0x01);
	SSD2828_Write_Data1(0x31);
	GP_COMMAD_PA1(4);
	SSD2828_Write_Data1(0xCC);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x3C);
	GP_COMMAD_PA1(4);
	SSD2828_Write_Data1(0xCD);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x3C);
	GP_COMMAD_PA1(6);
	SSD2828_Write_Data1(0xD1);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x05);
	SSD2828_Write_Data1(0x09);
	SSD2828_Write_Data1(0x07);
	SSD2828_Write_Data1(0x10);
	GP_COMMAD_PA1(6);
	SSD2828_Write_Data1(0xD2);
	SSD2828_Write_Data1(0x00);
	SSD2828_Write_Data1(0x05);
	SSD2828_Write_Data1(0x0E);
	SSD2828_Write_Data1(0x07);
	SSD2828_Write_Data1(0x10);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xE5);
	SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xE6);
	SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xE7);
	SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xE8);
	SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xE9);
	SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xEA);
	SSD2828_Write_Data1(0x06);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xED);
	SSD2828_Write_Data1(0x30);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0x6F);
	SSD2828_Write_Data1(0x11);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0xF3);
	SSD2828_Write_Data1(0x01);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0x51);
	SSD2828_Write_Data1(0xFF);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0x53);
	SSD2828_Write_Data1(0x2C);
	GP_COMMAD_PA1(2);
	SSD2828_Write_Data1(0x35);
	SSD2828_Write_Data1(0x00);
	GP_COMMAD_PA1(1);
	SSD2828_Write_Data1(0x11);
	delay_us(120000);
	GP_COMMAD_PA1(1);
	SSD2828_Write_Data1(0x29);
	delay_us(200000);
		

}
void SSD2828_Init(void)
{
	
		 macSPIx_RES_ENABLE();
		 delay_us(100);
		 macSPIx_RES_DISABLE();
		 delay_us(1000);
		 macSPIx_RES_ENABLE();
	   delay_us(5000);
		
		SSD2828_Write_Reg(0xb7,0x5000);
		SSD2828_Write_Reg(0xb8,0x0000);	
		SSD2828_Write_Reg(0xb9,0x0000);	
	
//		delay_us(100);
	
		SSD2828_Write_Reg(0xba,0x2F80);	
	
//		delay_us(100);
	
		SSD2828_Write_Reg(0xbb,0x0300);	
	
//		delay_us(100);
		
		SSD2828_Write_Reg(0xb9,0x0100);	//1=PLL disable
		
//		delay_us(1000);
		
		SSD2828_Write_Reg(0xde,0x0300);	//11=4LANE 10=3LANE 01=2LANE 00=1LANE
		
//		delay_us(100);
		
		SSD2828_Write_Reg(0xc9,0x0223);  //p1: HS-Data-zero  p2: HS-Data- prepare  --> 8031 issue
		LCD_CODE_Init();
		SSD2828_Write_Reg(0xb7,0x5000);  //Configuration Register
		SSD2828_Write_Reg(0xb8,0x0000);  //VC(Virtual ChannelID) Control Register
		SSD2828_Write_Reg(0xb9,0x0000);  //1=PLL disable
		SSD2828_Write_Reg(0xba,0x2f80);	 //PLL=(TX_CLK/MS)*NS 8228=480M 4428=240M  061E=120M 4214=240M 821E=360M 8219=300M 8225=444M 8224=432
																		 //D7-0=NS(0x01 : NS=1)   //0X28
																		 //D15-14=PLL��Χ 00=62.5-125 01=126-250 10=251-500 11=501-1000  DB12-8=MS(01:MS=1) //0X82
		SSD2828_Write_Reg(0xbb,0x0700);//LP Clock Divider LP clock = 400MHz / LPD / 8 = 480 / 8/ 8 = 7.5MHz
																	 //D5-0=LPD=0x1 �C Divide by 2
		SSD2828_Write_Reg(0xb9,0x0100);//1=PLL disable
		SSD2828_Write_Reg(0xc9,0x0223);//p1: HS-Data-zero  p2: HS-Data- prepare  --> 8031 issue  0x23
		delay_us(1000);
		SSD2828_Write_Reg(0xca,0x0123);//CLK Prepare //0x01 //Clk Zero   //0x23
		SSD2828_Write_Reg(0xcb,0x1005);//local_write_reg(addr=0xCB,data=0x0510)
																   //Clk Post  //0x10 //Clk Per    /0x05
		SSD2828_Write_Reg(0xcc,0x0510);//local_write_reg(addr=0xCC,data=0x100A)
																		//HS Trail    //Clk Trail
		delay_us(1000);		
		SSD2828_Write_Reg(0xD0,0x0000);
		delay_us(1000);	
//		delay_us(120);
		SSD2828_Write_Reg(0xb1,(SSD2828_LCD_VSPW<<8)|SSD2828_LCD_HSPW);//Vertical sync and horizontal sync active period 
		SSD2828_Write_Reg(0xb2,(SSD2828_LCD_VBPD<<8)|SSD2828_LCD_HBPD);//Vertical and horizontal back porch period  		
		SSD2828_Write_Reg(0xb3,(SSD2828_LCD_VFPD<<8)|SSD2828_LCD_HFPD);//Vertical and horizontal front porch period 		
//		SSD2828_Write_Command(SPI1,0XBA);
	  SSD2828_Write_Reg(0xb4,(SSD2828_LCD_XSIZE_TFT));//Horizontal active period 	
		SSD2828_Write_Reg(0xb5,(SSD2828_LCD_YSIZE_TFT));//Vertical active period	
		
		SSD2828_Write_Reg(0xb6, 0xe01B);	//Video mode and video pixel format //HS=H,VS=H,PCLK=L;	
		SSD2828_Write_Reg(0xDE, 0x0300);  //ͨ���� 11=4LANE 10=3LANE 01=2LANE 00=1LANE
		SSD2828_Write_Reg(0xD6, 0x0500);
		SSD2828_Write_Reg(0xB7, 0X4B02);
		delay_us(10000);			
		
		SSD2828_Write_Command(SPI1,0X2C);
		delay_us(5000);	
}

u16 SSD2828_ReadID(void)
{

		u8 temp = 0;
		u16 sum = 0;
		macSPIx_CS_ENABLE();
	  macSPIx_SDC_COMMAND_ENABLE();
		SPIx_RdWr_Byte(SPI1,0XB0);
		macSPIx_SDC_COMMAND_ENABLE();
		SPIx_RdWr_Byte(SPI1,0XFA);
		macSPIx_SDC_DATA_ENABLE();
		temp = SPIx_RdWr_Byte(SPI1,0XFF);
		sum = (temp<<8);
		temp = SPIx_RdWr_Byte(SPI1,0XFF);
		sum += temp;
		macSPIx_CS_DISABLE();
		return sum;
}
