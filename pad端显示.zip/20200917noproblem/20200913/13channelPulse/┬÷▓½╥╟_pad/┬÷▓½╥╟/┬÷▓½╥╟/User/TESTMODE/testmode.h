#ifndef __TESTMODE_H
#define __TESTMODE_H

#include "stm32f4xx.h"
#define FLASFTIME 50
#define TESTTIMEOUT 1000
extern u8 recvtimeout;
extern int16_t Timer3_Counters;
extern u8 TEST_DEBUG_CMD;

extern uint16_t gImage_send[200*90+2]__attribute__((at(0xD30208B8)));
extern uint16_t gImage_receive[200*90+2]__attribute__((at(0xD30208B8+0x8CA4)));
extern uint16_t gImage_start[125*46+2]__attribute__((at(0xD30208B8+2*0x8CA4)));
extern uint16_t gImage_next[125*46+2]__attribute__((at(0xD30208B8+2*0x8CA4+0x2CF0)));
extern uint16_t gImage_end[125*46+2]__attribute__((at(0xD30208B8+2*0x8CA4+2*0x2CF0)));
//extern uint16_t gImage_loading[520*127+2]__attribute__((at(0xD3051044+0x3984+4*0x35EC)));

extern u8 modeselect; //ģʽѡ��
extern u8 mode_pre_done;  //Ԥ����

u32 Get_CPU_ID(u32 *CpuID);
u32 Get_SD_ID();
void testmode_source_init(void);
void testmode_init(void);
void testmode_func(void);
void set_flashtimer(void);
void flash_led(void);

#endif

