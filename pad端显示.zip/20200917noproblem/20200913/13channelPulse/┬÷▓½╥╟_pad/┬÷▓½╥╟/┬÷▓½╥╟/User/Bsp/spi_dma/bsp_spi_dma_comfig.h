
#ifndef __BSP_SPI_DMA_COMFIG_H
#define __BSP_SPI_DMA_COMFIG_H

#include "stm32f4xx.h"
#include <stdio.h>

//SPI ���Ŷ���
/*******************************************************/
#define FLASH_SPI                               SPI1
#define FLASH_SPI_CLK                           RCC_APB2Periph_SPI1
#define RCC_APB_CLOCK_FUN                       RCC_APB2PeriphClockCmd

#define SPI_IT                                  SPI_I2S_IT_RXNE
#define DEBUG_SPI_IRQ                           SPI1_IRQn
#define DEBUG_SPI1_IRQHandler                   SPI1_IRQHandler


#define FLASH_SPI_CS_GPIO_PORT                 GPIOA
#define FLASH_SPI_CS_GPIO_CLK                 RCC_AHB1Periph_GPIOA
#define FLASH_SPI_CS_PIN                      GPIO_Pin_15
#define FLASH_SPI_CS_AF                       GPIO_AF_SPI1
#define FLASH_SPI_CS_SOURCE                   GPIO_PinSource15

#define FLASH_SPI_SCK_GPIO_PORT                 GPIOB
#define FLASH_SPI_SCK_GPIO_CLK                 RCC_AHB1Periph_GPIOB
#define FLASH_SPI_SCK_PIN                      GPIO_Pin_3
#define FLASH_SPI_SCK_AF                       GPIO_AF_SPI1
#define FLASH_SPI_SCK_SOURCE                   GPIO_PinSource3

#define FLASH_SPI_MISO_GPIO_PORT                 GPIOB
#define FLASH_SPI_MISO_GPIO_CLK                 RCC_AHB1Periph_GPIOB
#define FLASH_SPI_MISO_PIN                      GPIO_Pin_4
#define FLASH_SPI_MISO_AF                       GPIO_AF_SPI1
#define FLASH_SPI_MISO_SOURCE                   GPIO_PinSource4

#define FLASH_SPI_MOSI_GPIO_PORT                 GPIOA
#define FLASH_SPI_MOSI_GPIO_CLK                 RCC_AHB1Periph_GPIOA
#define FLASH_SPI_MOSI_PIN                      GPIO_Pin_7
#define FLASH_SPI_MOSI_AF                       GPIO_AF_SPI1
#define FLASH_SPI_MOSI_SOURCE                   GPIO_PinSource7
/************************************************************/

/*********************SPI�Ķ���******************************/
#define CS_HIGH_DISABLE()				GPIO_SetBits(FLASH_SPI_CS_GPIO_PORT,FLASH_SPI_CS_PIN)
#define CS_LOW_ENABLE()				  GPIO_ResetBits(FLASH_SPI_CS_GPIO_PORT,FLASH_SPI_CS_PIN)
//��Ƭѡ��״̬
#define CS_READOutStatus()      GPIO_ReadOutputDataBit(FLASH_SPI_CS_GPIO_PORT,FLASH_SPI_CS_PIN)

/*�ȴ���ʱʱ��*/
#define SPI_FLAG_TIMEOUT         ((uint32_t)0x1000)
#define SPI_LONG_TIMEOUT         ((uint32_t)(10 * SPI_FLAG_TIMEOUT))

/*��Ϣ���*/
#define FLASH_DEBUG_ON         0

#define FLASH_INFO(fmt,arg...)           printf("<<-FLASH-INFO->> "fmt"\n",##arg)
#define FLASH_ERROR(fmt,arg...)          printf("<<-FLASH-ERROR->> "fmt"\n",##arg)
#define FLASH_DEBUG(fmt,arg...)          do{\
                                          if(FLASH_DEBUG_ON)\
                                          printf("<<-FLASH-DEBUG->>[%s] [%d]"fmt"\n",__FILE__,__LINE__, ##arg);\
                                          }while(0)
/************************************************************/
																					
																					
/*******************************DMA���ֵĶ���****************/
#define DEBUG_SPI2_DR_BASE               (SPI1_BASE+0x0C)		
#define SENDBUFF_SIZE                   (1024*20+6)	//һ�η�������20480+֡ͷ֡β6		
#define RECEIVE_SIZE  					        800																					
#define RX_433BUF_SIZE									1024
#define RX_BTBUF_SIZE										1024																					
#define RX_WIFIBUF_SIZE									1024																					
																					
#define DEBUG_SPI2_DMA_CLK               RCC_AHB1Periph_DMA2																						
#define DEBUG_SPI2_TX_DMA_CHANNEL           DMA_Channel_3
#define DEBUG_SPI2_TX_DMA_STREAM            DMA2_Stream5
#define DEBUG_SPI2_RX_DMA_CHANNEL           DMA_Channel_3
#define DEBUG_SPI2_RX_DMA_STREAM            DMA2_Stream2

/* �����־ */
#define SPI_TX_DMA_IT_HT                DMA_IT_HTIF5   //����һ��
#define SPI_TX_DMA_IT_TC                DMA_IT_TCIF5  //�������

#define SPI_RX_DMA_IT_HT                DMA_IT_HTIF2   //����һ��
#define SPI_RX_DMA_IT_TC                DMA_IT_TCIF2   //�������
#define SPI_RX_DMA_IT_TE                DMA_IT_TEIF2   //�������
#define SPI_RX_DMA_IT_DME                DMA_IT_DMEIF2   //�������
//�ж�
#define DEBUG_SPI2_TX_IRQn                DMA2_Stream5_IRQn
#define DEBUG_SPI2_RX_IRQn                DMA2_Stream2_IRQn

// �ⲿ�жϺ���
#define DEBUG_SPI2_RX_DMA_IRQHandler    DMA2_Stream2_IRQHandler
#define DEBUG_SPI2_TX_DMA_IRQHandler    DMA2_Stream5_IRQHandler

/*************************************************************/

//�ⲿ�ж����Ŷ���
/*******************************************************/
//#define KEY1_INT_GPIO_PORT                GPIOA
//#define KEY1_INT_GPIO_CLK                 RCC_AHB1Periph_GPIOA
//#define KEY1_INT_GPIO_PIN                 GPIO_Pin_0
//#define KEY1_INT_EXTI_PORTSOURCE          EXTI_PortSourceGPIOA
//#define KEY1_INT_EXTI_PINSOURCE           EXTI_PinSource0
//#define KEY1_INT_EXTI_LINE                EXTI_Line0
//#define KEY1_INT_EXTI_IRQ                 EXTI0_IRQn

//#define KEY1_IRQHandler                   EXTI0_IRQHandler

//#define KEY2_INT_GPIO_PORT                GPIOC
//#define KEY2_INT_GPIO_CLK                 RCC_AHB1Periph_GPIOC
//#define KEY2_INT_GPIO_PIN                 GPIO_Pin_13
//#define KEY2_INT_EXTI_PORTSOURCE          EXTI_PortSourceGPIOC
//#define KEY2_INT_EXTI_PINSOURCE           EXTI_PinSource13
//#define KEY2_INT_EXTI_LINE                EXTI_Line13
//#define KEY2_INT_EXTI_IRQ                 EXTI15_10_IRQn

//#define KEY2_IRQHandler                   EXTI15_10_IRQHandler

#define KEY3_INT_GPIO_PORT                GPIOB
#define KEY3_INT_GPIO_CLK                 RCC_AHB1Periph_GPIOB
#define KEY3_INT_GPIO_PIN                 GPIO_Pin_14
#define KEY3_INT_EXTI_PORTSOURCE          EXTI_PortSourceGPIOB
#define KEY3_INT_EXTI_PINSOURCE           EXTI_PinSource14
#define KEY3_INT_EXTI_LINE                EXTI_Line14
#define KEY3_INT_EXTI_IRQ                 EXTI15_10_IRQn

//#define KEY3_IRQHandler                   EXTI15_10_IRQHandler  //����3��4��ͬһ���ⲿ�ж�

#define KEY4_INT_GPIO_PORT                GPIOH
#define KEY4_INT_GPIO_CLK                 RCC_AHB1Periph_GPIOH
#define KEY4_INT_GPIO_PIN                 GPIO_Pin_11
#define KEY4_INT_EXTI_PORTSOURCE          EXTI_PortSourceGPIOH
#define KEY4_INT_EXTI_PINSOURCE           EXTI_PinSource11
#define KEY4_INT_EXTI_LINE                EXTI_Line11
#define KEY4_INT_EXTI_IRQ                 EXTI15_10_IRQn

#define KEY3_4_IRQHandler                   EXTI15_10_IRQHandler



#define SPI_DMA_ALL_direction(direction) (((direction) == (uint8_t)'4')||\
																					((direction) == (uint8_t)'W')||\
																					((direction) == (uint8_t)'B')\
                                         ))
																				 
/*�ȴ���ʱʱ��*/
#define SPIT_DMA_TIMEOUT         ((uint32_t)0x1000)
#define SPIT_LONG_TIMEOUT         ((uint32_t)(10 * SPIT_DMA_TIMEOUT))	

//***************************����******************************//
#define  BUG_USART_ENABLE  1     //���Թ��̵�һЩ������ʾ��� �Ƿ��ӡ����

extern uint8_t TX_Buff[SENDBUFF_SIZE];
extern uint8_t RX_Buff[RECEIVE_SIZE];
extern  uint8_t  DMA_SPI_TX_ITStatus;
extern  uint8_t  DMA_SPI_RX_ITStatus; 
extern	char RXDATA_433[RX_433BUF_SIZE];
extern	char RXDATA_B[RX_BTBUF_SIZE];
extern	char RXDATA_W[RX_WIFIBUF_SIZE];
extern	char 	RXDATA_433_STATUS;
extern	char 	RXDATA_B_STATUS;	
extern	char 	RXDATA_W_STATUS;	
extern uint8_t W_download_Status;
extern uint8_t  KEY_1_Status;  //1:WIFI�ϴ����� ��־�ⲿ�ж��з�������
extern uint8_t  KEY_4_Status;  //1:��Ƶ����     ��־�ⲿ�ж��з�������
extern uint8_t USART2_RX_BUF[SENDBUFF_SIZE];
extern uint8_t USART2_RX_lenth;
extern uint8_t USART2_RX_Status;
extern uint8_t USART2_Status;


extern uint8_t linsi_status;  		/* ��ʱ״̬��־ 0������ */

/*******************************************************/

/*-----------------Wifiʹ�ò���-------------------------------*/
#define Wifi_Buf_Size		800
extern uint8_t W_download_Status;
extern uint8_t wifi_up_wav_file_status;
extern uint8_t wifi_dp_wav_file_status;
extern uint32_t count_num;//�����õ�
extern uint32_t count_num1;//�����õ�
/* WIFI���ظ������� */
//#define WIFI_SAVE_DONE_HIGH()				  GPIO_SetBits(GPIOA,GPIO_Pin_0)           //IO�������
//#define WIFI_SAVE_DONE_LOW()				  GPIO_ResetBits(GPIOA,GPIO_Pin_0)         //IO�������
#define WIFI_SAVE_DONE_HIGH()				  GPIO_SetBits(GPIOH,GPIO_Pin_11)           //IO�������
#define WIFI_SAVE_DONE_LOW()				  GPIO_ResetBits(GPIOH,GPIO_Pin_11)         //IO�������


/* WIFI�ϴ��������� */
//#define WIFI_UP_PIN_OUT()       GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1)        //����IO״̬
#define WIFI_UP_PIN_OUT()       GPIO_ReadInputDataBit(GPIOI,GPIO_Pin_1)        //����IO״̬

void music_data_pretreatment1(uint8_t DATA_direction,uint16_t *buffer0,uint8_t *buffer1,uint8_t *DATA_END,uint16_t bufsize);
void SPI_Write_buf(char *str1,char *str2,char *str3);
uint16_t str_find_DATAEND1(uint8_t *RX_Buff,uint8_t *DATA_END);
FunctionalState SPI_DMA_GetRxDDATAStatus(uint8_t DATA_direction);
void SPI_DMA_Clear_RxDDATAStatusBit(uint8_t DATA_direction);
//-------------֡ͷ֡β---------------------
#define Cmd_Head_W "$W"
#define Cmd_End_W  "$#"

#define Cmd_Head_4 "$4"
#define Cmd_End_4  "$#"

#define Cmd_Head_B "$B"
#define Cmd_End_B  "$#"
//-----------SPI����------------------------
#define ERROR1   "error:1"    //WIFI �ϴ��ļ�ʱ�� ������ ͨ��spi����cpld  
#define ERROR2   "error:2"    //WIFI �����ļ�ʱ�� д���� ͨ��spi����cpld  
#define ERROR3   "error:3"




/*-----------------BTʹ�ò���-------------------------------*/
extern uint8_t bt_wav_play_status;	//����������Ƶ����־
extern uint8_t Isread;						/* DMA����/������ɱ�־ */
extern uint8_t buf_flag;					/* ���ݻ�����ѡ���־ */


/*-----------------SPI-DMAʹ�ò���-------------------------------*/
void  spi_dma_Config(void);	//���ú���
void DMA_Write_buf(uint32_t SizeLen); 	//DMA���ͺ���
void SPI_DMA_WRITE_READ_BUF(void);
char DATA_process(uint8_t * RX_Buff_ADDR);	/* DMA���ݽ���+֡ͷ֡βУ�� */
uint8_t DATA_Config(uint8_t * data_ADR ,uint16_t data_length);                                         

#endif /* __BSP_SPI_FLASH_H */

