//#ifndef __CALCULATION_H
//#define	__CALCULATION_H
//#include "stm32f4xx.h"

//void read_File();

//void sigProcess_1();
//void sigProcess_2();
//void sigProcess_3();
//void sigProcess_4();

//#endif /* CALCULATION */