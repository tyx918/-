#include "./drawTrail/drawTrail.h"
#include "./lcd/bsp_lcd.h"
#include "bsp_GT9271.h"//����
#include "math.h"
/***************************************
ʹ��˵����

ң�أ�
	1���ȳ�ʼ����
		Rocker_Init()
	2����ʱ����
		if(AllowProcess) My_Rocker()
	3����Ҫ��ң��ָ��ʱ
		Remote_Cmd()
***************************************/

u8 AllowProcess = 0;  // �Ƿ���������

/*
* �����ֳ����洢��ǰ������Ļ��Ϣ,����һ����Ϣ�Ƶ��ڶ�������
*/
static void Protect_Site(uint16_t uRow, uint16_t uCol, uint16_t uWidth, uint16_t uHeigh)
{
	for(uint16_t xpos=uRow;xpos<uRow+uWidth;xpos++)
		for(uint16_t ypos=uCol;ypos<uCol+uHeigh;ypos++)
			*(uint16_t *)(BUFFER_OFFSET + LCD_FRAME_BUFFER + ypos * 2 * LCD_PIXEL_WIDTH + xpos * 2) = My_Lcd_Get_Point(xpos,ypos);
	printf("Rocker Protect_Site OK\r\n");
}

/*
* �ָ��ֳ������洢����Ļ��Ϣ��ԭ
*/
static void Restore_Site(uint16_t uRow, uint16_t uCol, uint16_t uWidth, uint16_t uHeigh)
{
	for(uint16_t xpos=uRow;xpos<uRow+uWidth;xpos++)
		for(uint16_t ypos=uCol;ypos<uCol+uHeigh;ypos++)
			My_Lcd_Draw_Point(xpos,ypos,*(uint16_t *)(BUFFER_OFFSET + LCD_FRAME_BUFFER + ypos * 2 * LCD_PIXEL_WIDTH + xpos * 2));
}





/*��ʼ��*/
void Rocker_Init()
{
////	Get_BMP_565_16("0:/STM32/ROCKER/����.bmp",Image_Map);
//	Get_BMP_565_16("0:/STM32/ROCKER/������.bmp",Image_Wheel);
}



/*STA=1: ��������
* STA=0: �رտ��� 
*/
void Rocker(u8 STA)
{
	if(STA==1)
	{
//		move_Image_Asm_565(CHASSIS_X,CHASSIS_Y,CHASSIS_W,CHASSIS_H,(uint16_t *)Image_Map);
		Protect_Site(CHASSIS_X,CHASSIS_Y,CHASSIS_W,CHASSIS_H);
//		move_Image_Asm_565(ROCKER_X,ROCKER_Y,ROCKER_W,ROCKER_H,(uint16_t *)Image_Wheel);
		//LCD_DrawFullRect(ROCKER_X, ROCKER_Y, ROCKER_W, ROCKER_H);
		AllowProcess = 1;
	}
	else
	{
		AllowProcess = 0;
	}
}



/*��������ͼ��ָ�*/
void Process(int x_pre, int y_pre, int x_now, int y_now)
{
	if(x_now!=x_pre || y_now!=y_pre)
	{
		//LCD_DrawFullRect(x_now, y_now, ROCKER_W, ROCKER_H);
		 Draw_ColorRect(x_now, y_now, ROCKER_W, ROCKER_H,LCD_COLOR565_BLACK);
//		move_Image_Asm_565(x_now,y_now,ROCKER_W,ROCKER_H,(uint16_t *)Image_Wheel);
	}
	
//	//���� x1,y1,x2-x1,h; x1,y2+h,w,y1-y2;
//	if(y_now<=y_pre && x_now>=x_pre)
//	{
//		Restore_Site(x_pre, y_pre, x_now-x_pre, ROCKER_H);
//		Restore_Site(x_pre, y_now+ROCKER_H, ROCKER_W, y_pre-y_now);
//	}
//	
//	//���� x1,y1,x2-x1,h; x1,y1,w,y2-y1;	
//	else if(y_now>=y_pre && x_now>=x_pre)
//	{
//		Restore_Site(x_pre, y_pre, x_now-x_pre, ROCKER_H);
//		Restore_Site(x_pre, y_pre, ROCKER_W, y_now-y_pre);
//	}
//	
//	//���� x1,y1,w,y2-y1; x2+w,y1,x1-x2,h;
//	else if(y_now>=y_pre && x_now<=x_pre)
//	{
//		Restore_Site(x_pre, y_pre, ROCKER_W, y_now-y_pre);
//		Restore_Site(x_now+ROCKER_W, y_pre, x_pre-x_now, ROCKER_H);
//	}

//	//���� x1,y2+h,w,y1-y2; x2+w,y1,x1-x2,h;
//	else if(y_now<=y_pre && x_now<=x_pre)
//	{
//		Restore_Site(x_pre, y_now+ROCKER_H, ROCKER_W, y_pre-y_now);
//		Restore_Site(x_now+ROCKER_W, y_pre, x_pre-x_now, ROCKER_H);
//	}
}



/*��ⴥ���Ƿ�Ϊָ������*/
static u8 My_Detect(uint16_t x_0, uint16_t y_0, uint16_t x_1, uint16_t y_1)
{
	static uint16_t TP_x = 0;
	static uint16_t TP_y = 0;
	static u8 press_down = 0;	
	
	if(TPData.Pressed[0]==1)    //�ж��Ƿ�ס������
	{
		TP_x = TPData.pre_x[0];
		TP_y = TPData.pre_y[0];
		if((TP_x>=x_0)&&(TP_x<=x_1)&&(TP_y>=y_0)&&(TP_y<=y_1))  //�жϰ���λ���Ƿ��ھ�����
		{
			press_down=1;
			return 1;
		}
	}
	if(TPData.TouchNum==0&&press_down==1)
	{
		if((TP_x>=x_0)&&(TP_x<=x_1)&&(TP_y>=y_0)&&(TP_y<=y_1))  //�жϰ���λ���Ƿ��ھ�����
		{
			press_down=0;
			return 2;
		}
	}
	return 0;
}



/*����*/
int Level_X = 0; //X�᷽������
int Level_Y = 0; //Y�᷽������
void Assess_Level(int16_t offset_x, int16_t offset_y)
{
	float gap = CHASSIS_W / 2.0;
	Level_X = (int)(abs(offset_x) / gap * GEAR_NUM);
	if(offset_x<0) Level_X = -Level_X;

	gap = CHASSIS_H / 2.0;
	Level_Y = (int)(abs(offset_y) / gap * GEAR_NUM);
	if(offset_y<0) Level_Y = -Level_Y;
}

/*��ʱ����*/
void My_Rocker()
{
		static int x_pre = CHASSIS_XW_MID-DELTA_W, y_pre = CHASSIS_YH_MID-DELTA_H;
		static int x_now = CHASSIS_XW_MID-DELTA_W, y_now = CHASSIS_YH_MID-DELTA_H;
		
		if(My_Detect(CHASSIS_X, CHASSIS_Y, CHASSIS_X+CHASSIS_W, CHASSIS_Y+CHASSIS_H)==1)
		{
			x_now = TPData.pre_x[0]-DELTA_W;
			y_now = TPData.pre_y[0]-DELTA_H;
			
//			if(abs(y_now-y_pre)>150|| abs(x_now-x_pre)>150) //ǰ�����μ��̫�����Ч
//			{
//				return;
//			}
			
			if(abs(x_now-x_pre)>0 || abs(y_now-y_pre)>0)
			{
				Process(x_pre, y_pre, x_now, y_now);//��ͼ��ָ�
				x_pre = x_now;
				y_pre = y_now;
				
//				printf("%d    %d\r\n", x_now, y_now);
//				printf("%d    %d\r\n", x_now-CHASSIS_XW_MID, y_now-CHASSIS_YH_MID);
				
				Assess_Level(x_now-CHASSIS_XW_MID+25, y_now-CHASSIS_YH_MID);
			}
		}

		static int Level_X_last = 0, Level_Y_last = 0;
		if(Level_X_last!=Level_X || Level_Y_last!=Level_Y)
		{
//			printf("Level_X:%d, Level_Y:%d\r\n",Level_X, Level_Y);
			Level_X_last = Level_X;
			Level_Y_last = Level_Y;
			
//			move_Image_Asm_565( Arrow_V_X+48,Arrow_V_Y,48,48,&gImage_GUIStock[48*48*(abs(Level_X)+2)] );
//			move_Image_Asm_565( Arrow_H_X,Arrow_H_Y+48,48,48,&gImage_GUIStock[48*48*(abs(Level_Y)+2)] );
			
			Remote_Cmd();  //����ң��ָ��
		}
}



/*��ң��ָ��*/
void Remote_Cmd()
{
//	char Cmd[20] = {0};
//	memset(Cmd,'\0',sizeof(Cmd));

//	sprintf(Cmd, "V:%d;%d;\r\n", Level_X, Level_Y);
//	printf("����ң��ָ�� %s\r\n", Cmd);
//	
//	send433Cmd(Cmd);
}

















